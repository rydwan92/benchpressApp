import * as React from 'react';
import { PaperProvider } from 'react-native-paper';
import MainNavigation from './components/navigation/MainNavigation';
import DataInitializer from './store/DataInitializer';

if (typeof document !== 'undefined') {
  document.body.style.overflow = 'auto';
  document.documentElement.style.overflow = 'auto'; // Scrollowanie strony
}

export default function App() {
  return (
    <PaperProvider>
      <DataInitializer>
        <MainNavigation />
      </DataInitializer>
    </PaperProvider>
  );
}