import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import CompetitionInfoForm from './registration/CompetitionInfoForm';
import CompetitionSummary from './registration/CompetitionSummary';
import CategoryBrowser from './registration/CategoryBrowser';
import { colors, font } from '../theme/theme';

export default function MainNavigation() {
  const [activeTab, setActiveTab] = useState('info');

  const renderContent = () => {
    switch (activeTab) {
      case 'info':
        return <CompetitionInfoForm />;
      case 'summary':
        return <CompetitionSummary />;
      case 'categories':
        return <CategoryBrowser />;
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.navbar}>
        <TouchableOpacity
          style={[styles.navItem, activeTab === 'info' && styles.activeNavItem]}
          onPress={() => setActiveTab('info')}
        >
          <Text style={[styles.navText, activeTab === 'info' && styles.activeNavText]}>
            Info
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.navItem, activeTab === 'summary' && styles.activeNavItem]}
          onPress={() => setActiveTab('summary')}
        >
          <Text style={[styles.navText, activeTab === 'summary' && styles.activeNavText]}>
            Podsumowanie
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.navItem, activeTab === 'categories' && styles.activeNavItem]}
          onPress={() => setActiveTab('categories')}
        >
          <Text style={[styles.navText, activeTab === 'categories' && styles.activeNavText]}>
            Kategorie
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.content}>
        {renderContent()}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
  },
  navbar: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2c3e50', // głęboki odcień
    paddingVertical: 16,
    paddingHorizontal: 12,
  },
  navItem: {
    marginHorizontal: 10,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 30,
    backgroundColor: '#34495e', // odcień dla nieaktywnego przycisku
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOpacity: 0.35,
        shadowOffset: { width: 0, height: 3 },
        shadowRadius: 5,
      },
      android: {
        elevation: 6,
      },
    }),
  },
  activeNavItem: {
    backgroundColor: '#e74c3c', // jasna czerwień dla aktywnego
    transform: [{ scale: 1.07 }],
  },
  navText: {
    color: '#ecf0f1',
    fontSize: font.sizeNormal,
    fontWeight: '600',
  },
  activeNavText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    padding: 16,
  },
});