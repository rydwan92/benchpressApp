import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, font, spacing, borderRadius } from '../../theme/theme';

// Original styles definition - we will modify this
const styles = StyleSheet.create({
  timerContainer: {
    width: '90%',
    maxWidth: 400,
    paddingVertical: spacing.lg, // 24
    paddingHorizontal: spacing.lg, // CHANGED from spacing.xl (32) to spacing.lg (24)
    backgroundColor: colors.surface,
    borderRadius: borderRadius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 4,
    borderColor: colors.border,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
  },
  timerActive: {
    backgroundColor: colors.error, // Czerwone tło gdy aktywny
    borderColor: colors.errorDark || '#C00000',
  },
  timerInactive: { // Kiedy timer nie jest aktywny, ale czas > 0 (np. "GOTOWY?")
    backgroundColor: colors.surface, // Domyślne tło
    borderColor: colors.primary, // Niebieska ramka
  },
  timerText: {
    fontFamily: font.familyMono || font.family,
    fontSize: 72, 
    fontWeight: font.weights.bold,
    color: colors.text, 
    lineHeight: 72 * 1.1, 
  },
  timerLabel: {
    fontSize: font.sizes['xl'], 
    fontWeight: font.weights.semibold,
    color: colors.textSecondary, 
    marginTop: spacing.xs,
    textTransform: 'uppercase',
  },
  timerActiveText: { // Dla tekstu na czerwonym/żółtym tle
    color: colors.textLight,
  },
  timerActiveLabel: { // Dla etykiety na czerwonym/żółtym tle
    color: colors.textLight + 'dd',
  },
  timerTimeUp: { // Kiedy czas minął (timeLeft <= 0 i !isActive)
    backgroundColor: colors.warning, // Żółte tło
    borderColor: colors.warningDark || '#B28900', 
  },
});

const FinalAthleteViewTimerDisplay = ({ isActive, timeLeft }) => {
  // Logowanie propsów otrzymanych przez komponent
  console.log(`${Date.now()} [AthleteViewTimerDisplay] Rendering. isActive: ${isActive}, timeLeft: ${timeLeft}`);

  const displayTime = (typeof timeLeft === 'number' && !isNaN(timeLeft)) ? timeLeft : 0;
  const formattedTime = `${String(Math.floor(displayTime / 60)).padStart(2, '0')}:${String(displayTime % 60).padStart(2, '0')}`;
  const isTimeUp = displayTime <= 0 && !isActive; 

  return (
    <View 
      style={[
        styles.timerContainer, 
        isActive 
          ? styles.timerActive 
          : (isTimeUp ? styles.timerTimeUp : styles.timerInactive)
      ]}
    >
      <Text 
        style={[
          styles.timerText, 
          (isActive || isTimeUp) 
            ? styles.timerActiveText 
            : { color: colors.primary } // Niebieski tekst dla "GOTOWY?"
        ]}
      >
        {formattedTime}
      </Text>
      <Text 
        style={[
          styles.timerLabel, 
          (isActive || isTimeUp) 
            ? styles.timerActiveLabel
            : { color: colors.textSecondary } // Szary tekst dla "GOTOWY?"
        ]}
      >
        {isActive ? 'CZAS LECI' : (isTimeUp ? 'CZAS MINĄŁ' : 'GOTOWY?')}
      </Text>
    </View>
  );
};

export default FinalAthleteViewTimerDisplay;