import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme'; // Added shadows

const AttemptDisplay = ({ number, weight, status, isActive }) => {
    const getStatusIcon = (currentStatus, currentWeight) => {
        const iconSize = 48; // Increased icon size
        const hasWeight = currentWeight && currentWeight !== '-';

        if (currentStatus === 'passed') return <AntDesign name="checkcircle" size={iconSize} color={colors.successStrong || colors.white} />;
        if (currentStatus === 'failed') return <AntDesign name="closecircle" size={iconSize} color={colors.errorStrong || colors.white} />;
        if (hasWeight) return <AntDesign name="clockcircleo" size={iconSize} color={isActive ? colors.primary : colors.textSecondary} />; // Pending with weight
        return <View style={{width: iconSize, height: iconSize}} />; // Placeholder for no weight/status
    };

    const containerStyles = [
        styles.attemptBox,
        isActive && styles.attemptBoxActive,
        status === 'passed' && styles.attemptBoxPassed,
        status === 'failed' && styles.attemptBoxFailed,
    ];

    const weightTextStyles = [
        styles.attemptWeight,
        (status === 'passed' || status === 'failed') && styles.attemptWeightResult,
        isActive && !(status === 'passed' || status === 'failed') && styles.attemptWeightActivePending,
    ];
    
    const attemptNumberTextStyles = [
        styles.attemptNumber,
        (status === 'passed' || status === 'failed') && styles.attemptTextResult,
        isActive && !(status === 'passed' || status === 'failed') && styles.attemptTextActivePending,
    ];


    return (
        <View style={containerStyles}>
            <Text style={attemptNumberTextStyles}>PODEJŚCIE {number}</Text>
            <Text style={weightTextStyles}>{weight ? `${weight} kg` : '-'}</Text>
            <View style={styles.attemptStatus}>
                {getStatusIcon(status, weight)}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    attemptBox: {
        backgroundColor: colors.surface, // Neutral background
        borderRadius: borderRadius.lg, // Larger border radius
        paddingVertical: spacing.lg, // Increased padding
        paddingHorizontal: spacing.xl,
        marginBottom: spacing.md,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%', // Full width within its container
        borderWidth: 3, // Thicker border
        borderColor: colors.border, // Default border color
        ...shadows.medium, // Add shadow
    },
    attemptBoxActive: {
        borderColor: colors.primary, // Bright blue border for active
        backgroundColor: colors.primary + '1A', // Very light blue background
        ...shadows.large, // More prominent shadow for active
    },
    attemptBoxPassed: {
        backgroundColor: colors.success, // Green background for passed
        borderColor: colors.successDark || '#00701a', // Darker green border
    },
    attemptBoxFailed: {
        backgroundColor: colors.error, // Red background for failed
        borderColor: colors.errorDark || '#9e0000', // Darker red border
    },
    attemptNumber: {
        fontSize: font.sizes.xl, // Larger font
        fontWeight: font.weights.semibold,
        color: colors.textSecondary,
        flex: 0.35, // Adjust flex for better spacing
    },
    attemptWeight: {
        fontSize: font.sizes['4xl'], // Much larger font for weight
        fontWeight: font.weights.bold,
        color: colors.text, // Default text color
        flex: 0.3,
        textAlign: 'center',
    },
    attemptStatus: {
        flex: 0.35,
        alignItems: 'flex-end',
    },
    // Styles for text when attempt is passed/failed (on colored background)
    attemptWeightResult: {
        color: colors.textLight, // White text on colored background
    },
    attemptTextResult: {
        color: colors.textLight + 'dd', // Slightly transparent white for attempt number
    },
    // Styles for text when attempt is active and pending
    attemptWeightActivePending: {
        color: colors.primary, // Blue text for weight when active and pending
    },
    attemptTextActivePending: {
        color: colors.primaryDark || colors.primary, // Darker blue for attempt number
    }
});

export default AttemptDisplay;