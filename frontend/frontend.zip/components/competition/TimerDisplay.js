import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, font, spacing } from '../../theme/theme';

const TimerDisplay = ({ isActive, timeLeft }) => {
    const formatTime = (seconds) => {
        if (typeof seconds !== 'number' || isNaN(seconds) || seconds < 0) {
            // console.warn(`[TimerDisplay formatTime] Invalid seconds value: ${seconds}. Returning '00:00'.`);
            return '00:00';
        }
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    };

    return (
        <View style={styles.timerContainer}>
            <Text style={[
                styles.timerText,
                isActive && typeof timeLeft === 'number' && !isNaN(timeLeft) && timeLeft <= 10 && timeLeft > 0 && styles.timerWarning,
                typeof timeLeft === 'number' && !isNaN(timeLeft) && timeLeft === 0 && styles.timerFinished
            ]}>
                {formatTime(timeLeft)}
            </Text>
        </View>
    );
};

const styles = StyleSheet.create({
    timerContainer: { alignItems: 'center', marginBottom: spacing.lg },
    timerText: { fontSize: font.sizes['5xl'], fontWeight: font.weights.bold, color: colors.primary },
    timerWarning: { color: colors.warning },
    timerFinished: { color: colors.error },
});

export default TimerDisplay;