import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import {colors, font} from '../../theme/theme'; // Upewnij się, że ścieżka do pliku z motywem jest poprawna

export default function Footer() {
  return (
    <View style={styles.footer}>
      <Text style={styles.footerText}>© 2025 Created by Michał R.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  footer: {
    backgroundColor: colors.secondary, // taki sam background jak nawigacja
    padding: 16,
    width: '100%',
    alignItems: 'center',
  },
  footerText: {
    color: '#fff',
    fontSize: font.sizeNormal,
    fontFamily: font.family,
  },
});