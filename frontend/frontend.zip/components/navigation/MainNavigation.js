import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import RegistrationScreen from '../../screens/RegistrationScreen';
// import kolejne ekrany...

const Placeholder = ({ name }) => (
  <></>
);

const Stack = createStackNavigator();

export default function MainNavigation() {
    return (
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Rejestracja" component={RegistrationScreen} />
            <Stack.Screen name="Zawody" component={() => <Placeholder name="Zawody" />} />
            <Stack.Screen name="Wyniki" component={() => <Placeholder name="Wyniki" />} />
            <Stack.Screen name="Raport" component={() => <Placeholder name="Raport" />} />
            <Stack.Screen name="Instrukcja" component={() => <Placeholder name="Instrukcja" />} />
          </Stack.Navigator>
        </NavigationContainer>
      );
}