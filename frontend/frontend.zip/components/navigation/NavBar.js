import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useNavigationState } from '@react-navigation/native';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme';

export default function NavBar({ navigation }) {
  // Pobierz nazwę bieżącej trasy
  const routes = useNavigationState(state => state.routes);
  const currentRoute = routes[useNavigationState(state => state.index)].name;

  // Lista przycisków nawigacyjnych
  const navButtons = [
    { title: 'Zarejestruj zawodników', route: 'Rejestracja' },
    { title: 'Prowadź zawody!', route: 'Zawody' },
    { title: 'Wyniki', route: 'Wyniki' },
    { title: 'Raport', route: 'Raport' },
    { title: 'Instrukcja', route: 'Instrukcja' },
  ];

  return (
    <View style={styles.nav}>
      {navButtons.map(btn => (
        <TouchableOpacity
          key={btn.route}
          style={[
            styles.button,
            currentRoute === btn.route && styles.activeButton
          ]}
          onPress={() => navigation.navigate(btn.route)}
        >
          <Text style={[
            styles.buttonText,
            currentRoute === btn.route && styles.activeButtonText
          ]}>
            {btn.title}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  nav: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.secondary,
    paddingVertical: spacing.md,
  },
  button: {
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.full,
    backgroundColor: colors.primary,
  },
  activeButton: {
    backgroundColor: colors.accent,
  },
  buttonText: {
    color: colors.textLight,
    fontSize: font.sizes.base,
    fontWeight: font.weights.medium,
  },
});