import React, { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { useCompetitionStore } from '../../store/useCompetitionStore';
import { colors, font, spacing, borderRadius, componentStyles } from '../../theme/theme';
import { commonStyles } from '../../styles/common';
import { saveAppData } from '../../utils/api';

export default function AthleteRegistrationForm() {
  const kategorie = useCompetitionStore(state => state.kategorie);
  const addZawodnik = useCompetitionStore(state => state.addZawodnik);

  const [imie, setImie] = useState('');
  const [nazwisko, setNazwisko] = useState('');
  const [klub, setKlub] = useState('');
  const [plec, setPlec] = useState('');
  const [kategoria, setKategoria] = useState('');
  const [waga, setWaga] = useState('');
  const [wiek, setWiek] = useState('');

  const [notif, setNotif] = useState(null);
  const notifTimeout = useRef(null);

  // Reset formularza
  const resetForm = () => {
    setImie('');
    setNazwisko('');
    setKlub('');
    setPlec('');
    setKategoria('');
    setWaga('');
    setWiek('');
  };

  // Powiadomienia
  function showNotif(msg, type) {
    setNotif({ msg, type });
    if (notifTimeout.current) clearTimeout(notifTimeout.current);
    notifTimeout.current = setTimeout(() => setNotif(null), 3000);
  }

  // Funkcja synchronizująca – wysyła cały stan do backendu
  const syncData = async () => {
    try {
      const state = useCompetitionStore.getState();
      await saveAppData({
        zawody: state.zawody,
        kategorie: state.kategorie,
        zawodnicy: state.zawodnicy,
      });
      showNotif('Dane zaktualizowane!', 'success');
    } catch (error) {
      console.error('Błąd synchronizacji:', error);
      showNotif('Błąd synchronizacji!', 'error');
    }
  };

  // Dodawanie zawodnika
  const handleAdd = async () => {
    if (!imie.trim() || !nazwisko.trim() || !plec || !kategoria || !waga || !wiek) {
      showNotif('Uzupełnij wszystkie wymagane pola!', 'error');
      return;
    }
    addZawodnik({ imie, nazwisko, klub, plec, kategoria, waga, wiek });
    await syncData();
    showNotif('Dodano zawodnika!', 'success');
    resetForm();
  };

  // Kategorie i wagi do wyboru
  const wagiDlaKategorii = kategorie.find(k => k.nazwa === kategoria)?.wagi || [];

  return (
    <View>
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Imię</Text>
        <TextInput
          style={styles.input}
          placeholder="Podaj imię zawodnika"
          value={imie}
          onChangeText={setImie}
          placeholderTextColor={colors.textSecondary}
        />
      </View>
      
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Nazwisko</Text>
        <TextInput
          style={styles.input}
          placeholder="Podaj nazwisko zawodnika"
          value={nazwisko}
          onChangeText={setNazwisko}
          placeholderTextColor={colors.textSecondary}
        />
      </View>
      
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Klub</Text>
        <TextInput
          style={styles.input}
          placeholder="Podaj nazwę klubu"
          value={klub}
          onChangeText={setKlub}
          placeholderTextColor={colors.textSecondary}
        />
      </View>
      
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Wiek</Text>
        <TextInput
          style={styles.input}
          placeholder="Podaj wiek zawodnika"
          value={wiek}
          onChangeText={setWiek}
          keyboardType="numeric"
          placeholderTextColor={colors.textSecondary}
        />
      </View>
      
      {/* Pozostała część formularza */}
      <View style={styles.radioRow}>
        <Text style={styles.label}>Płeć</Text>
        <View style={styles.radioContainer}>
          <TouchableOpacity
            style={[styles.radioBtn, plec === 'K' && styles.radioBtnActive]}
            onPress={() => setPlec('K')}
          >
            <Text style={[styles.radioText, plec === 'K' && styles.radioTextActive]}>Kobieta</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.radioBtn, plec === 'M' && styles.radioBtnActive]}
            onPress={() => setPlec('M')}
          >
            <Text style={[styles.radioText, plec === 'M' && styles.radioTextActive]}>Mężczyzna</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Pozostała część kodu... */}
      
      {notif && (
        <View style={[styles.notification, notif.type === 'success' ? styles.notificationSuccess : styles.notificationError]}>
          <Text style={styles.notificationText}>{notif.msg}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  inputGroup: {
    marginBottom: spacing.md,
  },
  label: {
    fontSize: font.sizes.sm,
    fontWeight: font.weights.medium,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  input: {
    ...componentStyles.input,
    marginBottom: 0,
  },
  radioRow: {
    marginBottom: spacing.md,
  },
  radioContainer: {
    flexDirection: 'row',
    gap: spacing.md,
    marginTop: spacing.xs,
  },
  radioBtn: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.card,
  },
  radioBtnActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  radioText: {
    color: colors.text,
    fontWeight: font.weights.medium,
  },
  radioTextActive: {
    color: colors.textLight,
  },
  selectBox: {
    marginBottom: spacing.md,
  },
  selectLabel: {
    fontSize: font.sizes.sm,
    fontWeight: font.weights.medium,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  selectList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
    marginTop: spacing.xs,
  },
  selectItem: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
  },
  selectItemActive: {
    backgroundColor: colors.primary,
  },
  selectItemText: {
    color: colors.text,
    fontWeight: font.weights.medium,
    fontSize: font.sizes.sm,
  },
  selectEmpty: {
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  btnRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: spacing.sm,
    marginTop: spacing.md,
  },
  btnAdd: {
    ...componentStyles.button.base,
    ...componentStyles.button.primary,
  },
  btnClear: {
    ...componentStyles.button.base,
    backgroundColor: colors.button.secondary,
  },
  btnText: {
    ...componentStyles.button.text,
  },
  notification: {
    ...componentStyles.notification.base,
  },
  notificationSuccess: {
    ...componentStyles.notification.success,
  },
  notificationError: {
    ...componentStyles.notification.error,
  },
  notificationText: {
    ...componentStyles.notification.text,
  },
});