import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Modal, TextInput, Animated } from 'react-native';
import { colors, font } from '../../theme/theme';
import { useCompetitionStore } from '../../store/useCompetitionStore';

export default function CategoryBrowser() {
  const kategorie = useCompetitionStore(state => state.kategorie);
  const zawodnicy = useCompetitionStore(state => state.zawodnicy);
  const removeZawodnik = useCompetitionStore(state => state.removeZawodnik);
  const updatePodejscie = useCompetitionStore(state => state.updatePodejscie);
  const updateZawodnik = useCompetitionStore(state => state.updateZawodnik);

  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedWeight, setSelectedWeight] = useState('');
  const [categoryModalVisible, setCategoryModalVisible] = useState(false);
  const [weightModalVisible, setWeightModalVisible] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [toDeleteIdx, setToDeleteIdx] = useState(null);
  const [notif, setNotif] = useState(null);
  const notifTimeout = useRef(null);
  const [editModal, setEditModal] = useState({ open: false, idx: null, data: {} });
  const [fadeAnims, setFadeAnims] = useState([]);

  React.useEffect(() => {
    if (kategorie.length === 0) return; // brak kategorii, nie działaj
    if (!selectedCategory) {
      setSelectedCategory(kategorie[0].nazwa);
      setSelectedWeight(kategorie[0].wagi[0] || '');
    } else {
      // Jeśli wybrana kategoria nie istnieje już w liście, ustaw domyślnie pierwszy element
      const exists = kategorie.some(k => k.nazwa === selectedCategory);
      if (!exists) {
        setSelectedCategory(kategorie[0].nazwa);
        setSelectedWeight(kategorie[0].wagi[0] || '');
      }
    }
  }, [kategorie]);

  React.useEffect(() => {
    const cat = kategorie.find(k => k.nazwa === selectedCategory);
    if (cat && !cat.wagi.includes(selectedWeight)) {
      setSelectedWeight(cat.wagi[0] || '');
    }
  }, [selectedCategory, kategorie]);

  const weights = kategorie.find(k => k.nazwa === selectedCategory)?.wagi || [];
  const filteredZawodnicy = zawodnicy
    .map((z, idx) => ({ ...z, idx }))
    .filter(z =>
      z.kategoria === selectedCategory && z.waga === selectedWeight
    );

  React.useEffect(() => {
    // Dodaj animację dla nowych zawodników
    setFadeAnims(filteredZawodnicy.map(() => new Animated.Value(0)));
    filteredZawodnicy.forEach((_, i) => {
      Animated.timing(
        fadeAnims[i] || new Animated.Value(0),
        { toValue: 1, duration: 500, useNativeDriver: true }
      ).start();
    });
    // eslint-disable-next-line
  }, [filteredZawodnicy.length]);

  function showNotif(msg, type) {
    setNotif({ msg, type });
    if (notifTimeout.current) clearTimeout(notifTimeout.current);
    notifTimeout.current = setTimeout(() => setNotif(null), 3000);
  }

  const handleDelete = (idx) => {
    setToDeleteIdx(idx);
    setModalVisible(true);
  };

  const confirmDelete = () => {
    removeZawodnik(toDeleteIdx);
    setModalVisible(false);
    setToDeleteIdx(null);
    showNotif('Zawodnik usunięty!', 'success');
  };

  return (
    <View style={styles.browserCard}>
      {/* Nagłówek – zmieniony na czarny kolor */}
      <Text style={styles.browserTitle}>Kategorie</Text>
      
      {/* Wiersz wyboru kategorii i wagi z pełną szerokością i bocznym odstępem */}
      <View style={styles.selectionRow}>
        <TouchableOpacity style={styles.inputFake} onPress={() => setCategoryModalVisible(true)}>
          <Text style={styles.inputFakeText}>Kategoria: {selectedCategory}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.inputFake} onPress={() => setWeightModalVisible(true)}>
          <Text style={styles.inputFakeText}>Waga: {selectedWeight}</Text>
        </TouchableOpacity>
      </View>

      {/* Modal wyboru kategorii */}
      <Modal visible={categoryModalVisible} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Wybierz kategorię</Text>
            {kategorie.map((cat, i) => (
              <TouchableOpacity key={i} style={styles.modalOption} onPress={() => { setSelectedCategory(cat.nazwa); setCategoryModalVisible(false); }}>
                <Text style={styles.modalOptionText}>{cat.nazwa}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={[styles.btn, { marginTop: 12 }]} onPress={() => setCategoryModalVisible(false)}>
              <Text style={styles.btnText}>Anuluj</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal wyboru wagi */}
      <Modal visible={weightModalVisible} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Wybierz wagę</Text>
            {weights.map((w, i) => (
              <TouchableOpacity key={i} style={styles.modalOption} onPress={() => { setSelectedWeight(w); setWeightModalVisible(false); }}>
                <Text style={styles.modalOptionText}>{w}</Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={[styles.btn, { marginTop: 12 }]} onPress={() => setWeightModalVisible(false)}>
              <Text style={styles.btnText}>Anuluj</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <ScrollView  style={styles.tableScroll}>
        <View style={styles.fullTable}>
          <View style={styles.tableHeader}>
            <Text style={styles.tableHeaderCell}>Imię</Text>
            <Text style={styles.tableHeaderCell}>Nazwisko</Text>
            <Text style={styles.tableHeaderCell}>Klub</Text>
            <Text style={styles.tableHeaderCell}>Podejście 1</Text>
            {/* Inne kolumny jeżeli potrzebne */}
          </View>
          {filteredZawodnicy.map((z, i) => (
            <View style={styles.tableRow} key={i}>
              <Text style={styles.tableCell}>{z.imie}</Text>
              <Text style={styles.tableCell}>{z.nazwisko}</Text>
              <Text style={styles.tableCell}>{z.klub}</Text>
              {[1, 2, 3].map(nr => (
                <TextInput
                  key={nr}
                  style={styles.tableCellInput}
                  value={z[`podejscie${nr}`] || ''}
                  onChangeText={val => updatePodejscie(z.idx, nr, val)}
                  placeholder={`Podejście ${nr}`}
                  keyboardType="numeric"
                />
              ))}
              <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(z.idx)}>
                <Text style={styles.deleteBtnText}>Usuń</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.editBtn} onPress={() => setEditModal({ open: true, idx: z.idx, data: { imie: z.imie, nazwisko: z.nazwisko, klub: z.klub } })}>
                <Text style={styles.editBtnText}>Edytuj</Text>
              </TouchableOpacity>
            </View>
          ))}
          {filteredZawodnicy.length === 0 && (
            <View style={styles.tableRow}>
              <Text style={styles.tableCell}>Brak zawodników</Text>
            </View>
          )}
        </View>
      </ScrollView>

      <ScrollView style={styles.athleteList}>
        {filteredZawodnicy.length === 0 && (
          <Text style={styles.empty}>Brak zawodników w tej kategorii i wadze</Text>
        )}
        {filteredZawodnicy.map((z, i) => (
          <Animated.View
            key={z.idx}
            style={[
              styles.athleteCard,
              { opacity: fadeAnims[i] || 1, transform: [{ scale: (fadeAnims[i] || { _value: 1 })._value }] }
            ]}
          >
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarText}>
                {z.imie?.[0]?.toUpperCase() || '?'}
                {z.nazwisko?.[0]?.toUpperCase() || ''}
              </Text>
            </View>
            <View style={styles.athleteInfo}>
              <Text style={styles.athleteName}>{z.imie} {z.nazwisko}</Text>
              <Text style={styles.athleteClub}>{z.klub}</Text>
            </View>
            <View style={styles.attemptBox}>
              <Text style={styles.attemptLabel}>P1</Text>
              <Text style={styles.attemptValue}>
                {z.podejscie1 ? `${z.podejscie1} kg` : <Text style={styles.attemptEmpty}>–</Text>}
              </Text>
            </View>
          </Animated.View>
        ))}
      </ScrollView>

      {/* Modal potwierdzenia usunięcia */}
      <Modal visible={modalVisible} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Czy na pewno usunąć zawodnika?</Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.btn} onPress={confirmDelete}>
                <Text style={styles.btnText}>Tak</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.btnCancel} onPress={() => setModalVisible(false)}>
                <Text style={styles.btnText}>Nie</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Modal edycji */}
      <Modal visible={editModal.open} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Edytuj zawodnika</Text>
            <TextInput
              style={styles.input}
              placeholder="Imię"
              value={editModal.data.imie}
              onChangeText={val => setEditModal(m => ({ ...m, data: { ...m.data, imie: val } }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Nazwisko"
              value={editModal.data.nazwisko}
              onChangeText={val => setEditModal(m => ({ ...m, data: { ...m.data, nazwisko: val } }))}
            />
            <TextInput
              style={styles.input}
              placeholder="Klub"
              value={editModal.data.klub}
              onChangeText={val => setEditModal(m => ({ ...m, data: { ...m.data, klub: val } }))}
            />
            <View style={styles.modalBtns}>
              <TouchableOpacity
                style={styles.btn}
                onPress={() => {
                  updateZawodnik(editModal.idx, editModal.data);
                  setEditModal({ open: false, idx: null, data: {} });
                }}
              >
                <Text style={styles.btnText}>Zapisz</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.btnCancel} onPress={() => setEditModal({ open: false, idx: null, data: {} })}>
                <Text style={styles.btnText}>Anuluj</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {notif && (
        <View style={[styles.notif, notif.type === 'success' ? styles.notifSuccess : styles.notifError]}>
          <Text style={styles.notifText}>{notif.msg}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  browserCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    // Zastosuj marginesy po bokach, np. 3% szerokości rodzica
    marginHorizontal: '3%',
    alignSelf: 'stretch',
    flex: 1,
  },
  browserTitle: {
    fontSize: font.sizeHeader + 2,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
    color: '#000', // Ustaw tekst na czarny
  },
  selectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    marginBottom: 16,
  },
  inputFake: {
    flex: 1,
    backgroundColor: '#e3f3fa',
    borderRadius: 8,
    padding: 10,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  inputFakeText: {
    fontSize: font.sizeNormal,
    fontWeight: 'bold',
    color: colors.text,
  },
  tableScroll: {
    marginTop: 12,
    width: '100%',
  },
  fullTable: {
    width: '100%',
    minWidth: '100%',
    alignSelf: 'stretch',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: colors.primary,
    paddingVertical: 10,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
  },
  tableHeaderCell: {
    flex: 1,
    textAlign: 'center',
    fontWeight: 'bold',
    color: '#fff',
  },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: colors.border,
    paddingVertical: 8,
  },
  tableCell: {
    flex: 1,
    textAlign: 'center',
    fontSize: font.sizeNormal,
  },
  tableCellInput: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 6,
    paddingVertical: 4,
    paddingHorizontal: 8,
    minWidth: 60,
    marginHorizontal: 2,
    backgroundColor: '#fff',
    fontSize: font.sizeNormal,
    color: colors.text,
    textAlign: 'center',
  },
  deleteBtn: {
    backgroundColor: '#e74c3c',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 14,
    marginLeft: 6,
  },
  deleteBtnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  editBtn: {
    backgroundColor: '#f7c948',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 14,
    marginLeft: 6,
  },
  editBtnText: {
    color: '#222',
    fontWeight: 'bold',
  },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 28,
    minWidth: 320,
    maxWidth: 400,
    alignItems: 'center',
    shadowColor: "#000",
    shadowOpacity: 0.12,
    shadowRadius: 18,
    elevation: 6,
  },
  modalTitle: {
    fontSize: font.sizeHeader + 2,
    fontWeight: 'bold',
    marginBottom: 18,
    color: colors.primary,
    textAlign: 'center',
  },
  modalOption: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderColor: colors.border,
    width: '100%',
  },
  modalOptionText: {
    fontSize: font.sizeNormal,
    color: colors.text,
    textAlign: 'center',
  },
  modalBtns: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 18,
  },
  btn: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 22,
    marginHorizontal: 4,
  },
  btnCancel: {
    backgroundColor: '#aaa',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 22,
    marginHorizontal: 4,
  },
  btnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: font.sizeNormal,
    textAlign: 'center',
  },
  notif: {
    marginTop: 16,
    padding: 12,
    borderRadius: 8,
  },
  notifSuccess: {
    backgroundColor: '#d4f8e8',
  },
  notifError: {
    backgroundColor: '#ffd6d6',
  },
  notifText: {
    color: colors.text,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  athleteList: {
    marginTop: 18,
    marginBottom: 8,
    width: '100%',
    minHeight: 80,
  },
  athleteCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 14,
    marginBottom: 14,
    padding: 16,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#e3f3fa',
    minHeight: 64,
  },
  avatarCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  avatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 20,
    fontFamily: font.family,
  },
  athleteInfo: {
    flex: 1,
    justifyContent: 'center',
    minWidth: 120,
  },
  athleteName: {
    fontSize: font.sizeNormal + 2,
    fontWeight: font.weightBold,
    color: colors.text,
    fontFamily: font.family,
    marginBottom: 2,
  },
  athleteClub: {
    fontSize: font.sizeNormal - 1,
    color: colors.textSecondary,
    fontFamily: font.family,
  },
  attemptBox: {
    alignItems: 'center',
    minWidth: 60,
    marginLeft: 12,
    backgroundColor: '#f7fafd',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  attemptLabel: {
    fontSize: font.sizeNormal - 2,
    color: colors.textSecondary,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  attemptValue: {
    fontSize: font.sizeNormal + 2,
    color: colors.primary,
    fontWeight: 'bold',
  },
  attemptEmpty: {
    color: colors.border,
    fontWeight: 'normal',
  },
  empty: {
    margin: 24,
    color: colors.textSecondary,
    fontFamily: font.family,
    textAlign: 'center',
    fontSize: font.sizeNormal,
  },
});