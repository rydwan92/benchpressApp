import React, { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, Modal, StyleSheet, ScrollView, Dimensions } from 'react-native';
import { useCompetitionStore } from '../../store/useCompetitionStore';
import { saveAppData } from '../../utils/api';
import { colors, font, spacing, borderRadius, shadows, componentStyles } from '../../theme/theme';
import { AntDesign } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

export default function CategoryWeightManager() {
  const kategorie = useCompetitionStore(state => state.kategorie);
  const addKategoria = useCompetitionStore(state => state.addKategoria);
  const addWaga = useCompetitionStore(state => state.addWaga);
  const removeKategoria = useCompetitionStore(state => state.removeKategoria);
  const removeWaga = useCompetitionStore(state => state.removeWaga);

  // Modal i formularz kategorii
  const [modalKategoria, setModalKategoria] = useState(false);
  const [nowaKategoria, setNowaKategoria] = useState('');

  // Modal i formularz wagi
  const [modalWaga, setModalWaga] = useState(false);
  const [wybranaKategoria, setWybranaKategoria] = useState('');
  const [nowaWaga, setNowaWaga] = useState('');

  // Powiadomienia
  const [notif, setNotif] = useState(null);
  const notifTimeout = useRef(null);
  const [confirmModal, setConfirmModal] = useState({ open: false, type: null, kategoria: null, waga: null });

  function showNotif(msg, type) {
    setNotif({ msg, type });
    if (notifTimeout.current) clearTimeout(notifTimeout.current);
    notifTimeout.current = setTimeout(() => setNotif(null), 3000);
  }

  // Funkcja synchronizująca – wysyła cały stan do backendu
  const syncData = async () => {
    try {
      const state = useCompetitionStore.getState();
      await saveAppData({
        zawody: state.zawody,
        kategorie: state.kategorie,
        zawodnicy: state.zawodnicy,
      });
      showNotif('Dane zaktualizowane!', 'success');
    } catch (error) {
      console.error('Błąd synchronizacji:', error);
      showNotif('Błąd synchronizacji!', 'error');
    }
  };

  const handleAddKategoria = async () => {
    if (!nowaKategoria.trim()) {
      showNotif('Podaj nazwę kategorii!', 'error');
      return;
    }
    if (kategorie.some(k => k.nazwa.toLowerCase() === nowaKategoria.trim().toLowerCase())) {
      showNotif('Taka kategoria już istnieje!', 'error');
      return;
    }
    addKategoria(nowaKategoria.trim());
    setNowaKategoria('');
    setModalKategoria(false);
    showNotif('Dodano kategorię!', 'success');
    await syncData();
  };

  const handleAddWaga = async () => {
    if (!wybranaKategoria || !nowaWaga.trim()) {
      showNotif('Wybierz kategorię i podaj wagę!', 'error');
      return;
    }
    const kat = kategorie.find(k => k.nazwa === wybranaKategoria);
    if (kat && kat.wagi.some(w => w.toLowerCase() === nowaWaga.trim().toLowerCase())) {
      showNotif('Taka waga już istnieje w tej kategorii!', 'error');
      return;
    }
    addWaga(wybranaKategoria, nowaWaga.trim());
    setNowaWaga('');
    setWybranaKategoria('');
    setModalWaga(false);
    showNotif('Dodano wagę!', 'success');
    await syncData();
  };

  const handleDeleteConfirm = async () => {
    if (confirmModal.type === 'kategoria') {
      removeKategoria(confirmModal.kategoria);
      showNotif('Usunięto kategorię!', 'success');
    } else if (confirmModal.type === 'waga') {
      removeWaga(confirmModal.kategoria, confirmModal.waga);
      showNotif('Usunięto wagę!', 'success');
    }
    setConfirmModal({ open: false, type: null, kategoria: null, waga: null });
    await syncData();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.componentTitle}>
        Zarządzanie kategoriami i wagami
      </Text>
      
      <View style={styles.actionRow}>
        <TouchableOpacity style={styles.actionBtn} onPress={() => setModalKategoria(true)}>
          <AntDesign name="plus" size={16} color={colors.textLight} style={styles.btnIcon} />
          <Text style={styles.actionBtnText}>Dodaj kategorię</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={() => setModalWaga(true)}>
          <AntDesign name="plus" size={16} color={colors.textLight} style={styles.btnIcon} />
          <Text style={styles.actionBtnText}>Dodaj wagę</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.scrollContainer}>
        <View style={styles.kategorieBox}>
          {kategorie.length === 0 ? (
            <View style={styles.emptyState}>
              <AntDesign name="folderopen" size={32} color={colors.textSecondary} />
              <Text style={styles.emptyText}>Brak kategorii - dodaj pierwszą kategorię</Text>
            </View>
          ) : (
            kategorie.map(k => (
              <View key={k.nazwa} style={styles.kategoriaTile}>
                <View style={styles.kategoriaHeader}>
                  <Text style={styles.kategoriaTitle}>{k.nazwa}</Text>
                  <TouchableOpacity 
                    style={styles.deleteButton}
                    onPress={() => setConfirmModal({ open: true, type: 'kategoria', kategoria: k.nazwa })}
                  >
                    <AntDesign name="closecircle" size={18} color={colors.error} />
                  </TouchableOpacity>
                </View>
                
                <View style={styles.wagiContainer}>
                  {k.wagi.length > 0 ? (
                    <View style={styles.wagiRow}>
                      {k.wagi.map(w => (
                        <View key={w} style={styles.wagaTile}>
                          <Text style={styles.wagaText}>{w}</Text>
                          <TouchableOpacity 
                            style={styles.wagaDeleteBtn}
                            onPress={() => setConfirmModal({ 
                              open: true, 
                              type: 'waga', 
                              kategoria: k.nazwa, 
                              waga: w 
                            })}
                          >
                            <AntDesign name="close" size={14} color={colors.error} />
                          </TouchableOpacity>
                        </View>
                      ))}
                    </View>
                  ) : (
                    <Text style={styles.wagiEmpty}>Brak wag - dodaj pierwszą wagę</Text>
                  )}
                </View>
              </View>
            ))
          )}
        </View>
      </ScrollView>
      
      {/* Modal dodawania kategorii */}
      <Modal visible={modalKategoria} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <View style={styles.modalIconHeader}>
              <AntDesign name="appstore1" size={28} color={colors.accent} />
            </View>
            
            <Text style={styles.modalTitle}>Nowa kategoria</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Nazwa kategorii"
              value={nowaKategoria}
              onChangeText={setNowaKategoria}
              autoFocus
              placeholderTextColor={colors.textSecondary}
            />
            
            <View style={styles.modalBtns}>
              <TouchableOpacity 
                style={[styles.modalBtn, styles.cancelBtn]} 
                onPress={() => setModalKategoria(false)}
              >
                <Text style={styles.btnText}>Anuluj</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.modalBtn, styles.confirmBtn]} 
                onPress={handleAddKategoria}
              >
                <AntDesign name="check" size={16} color={colors.textLight} style={styles.btnIcon} />
                <Text style={styles.btnText}>Dodaj</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      
      {/* Modal dodawania wagi */}
      <Modal visible={modalWaga} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <View style={styles.modalIconHeader}>
              <AntDesign name="tag" size={28} color={colors.accent} />
            </View>
            
            <Text style={styles.modalTitle}>Nowa waga</Text>
            
            <View style={styles.selectBox}>
              {kategorie.length === 0 ? (
                <Text style={styles.errorText}>Najpierw dodaj kategorię!</Text>
              ) : (
                <>
                  <Text style={styles.selectLabel}>Wybierz kategorię:</Text>
                  <ScrollView 
                    horizontal 
                    showsHorizontalScrollIndicator={false} 
                    style={styles.selectScroll}
                    contentContainerStyle={styles.selectScrollContent}
                  >
                    {kategorie.map(k => (
                      <TouchableOpacity
                        key={k.nazwa}
                        style={[
                          styles.selectItem, 
                          wybranaKategoria === k.nazwa && styles.selectItemActive
                        ]}
                        onPress={() => setWybranaKategoria(k.nazwa)}
                      >
                        <Text 
                          style={[
                            styles.selectItemText, 
                            wybranaKategoria === k.nazwa && styles.selectItemTextActive
                          ]}
                        >
                          {k.nazwa}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </>
              )}
            </View>
            
            <TextInput
              style={styles.input}
              placeholder="Nowa waga (np. 70kg)"
              value={nowaWaga}
              onChangeText={setNowaWaga}
              placeholderTextColor={colors.textSecondary}
            />
            
            <View style={styles.modalBtns}>
              <TouchableOpacity 
                style={[styles.modalBtn, styles.cancelBtn]} 
                onPress={() => setModalWaga(false)}
              >
                <Text style={styles.btnText}>Anuluj</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.modalBtn, styles.confirmBtn]} 
                onPress={handleAddWaga}
              >
                <AntDesign name="check" size={16} color={colors.textLight} style={styles.btnIcon} />
                <Text style={styles.btnText}>Dodaj</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      
      {/* Modal potwierdzenia usunięcia */}
      <Modal visible={confirmModal.open} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, styles.confirmModalCard]}>
            <View style={styles.modalIconHeader}>
              <AntDesign name="warning" size={32} color={colors.warning} />
            </View>
            
            <Text style={[styles.modalTitle, styles.confirmTitle]}>
              {confirmModal.type === 'kategoria'
                ? `Usunąć kategorię "${confirmModal.kategoria}"?`
                : `Usunąć wagę "${confirmModal.waga}"\nz kategorii "${confirmModal.kategoria}"?`}
            </Text>
            
            <View style={styles.modalBtns}>
              <TouchableOpacity 
                style={[styles.modalBtn, styles.cancelBtn]} 
                onPress={() => setConfirmModal({ open: false, type: null, kategoria: null, waga: null })}
              >
                <Text style={styles.btnText}>Anuluj</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.modalBtn, styles.deleteBtn]} 
                onPress={handleDeleteConfirm}
              >
                <AntDesign name="delete" size={16} color={colors.textLight} style={styles.btnIcon} />
                <Text style={styles.btnText}>Usuń</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      
      {/* Powiadomienie */}
      {notif && (
        <View style={[
          styles.notification, 
          notif.type === 'success' ? styles.notifSuccess : styles.notifError
        ]}>
          <AntDesign 
            name={notif.type === 'success' ? "checkcircleo" : "exclamationcircleo"} 
            size={18} 
            color={notif.type === 'success' ? colors.success : colors.error} 
            style={styles.notifIcon} 
          />
          <Text style={styles.notifText}>{notif.msg}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: spacing.md,
  },
  scrollContainer: {
    flex: 1,
  },
  componentTitle: {
    fontSize: font.sizes.xl,
    fontWeight: font.weights.bold,
    color: colors.text,
    marginBottom: spacing.md,
    textAlign: 'center',
  },
  actionRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  actionBtn: {
    backgroundColor: colors.accent,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    ...shadows.small,
  },
  actionBtnText: {
    color: colors.textLight,
    fontWeight: font.weights.medium,
    fontSize: font.sizes.sm,
  },
  btnIcon: {
    marginRight: spacing.xs,
  },
  
  // Stan pustego komponentu
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
    opacity: 0.7,
  },
  emptyText: {
    color: colors.textSecondary,
    marginTop: spacing.sm,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  
  // Kafelki kategorii
  kategorieBox: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  kategoriaTile: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    width: (width - spacing.md * 3) / 2, // Dwie kolumny z odstępem
    ...shadows.small,
    borderLeftWidth: 4,
    borderLeftColor: colors.accent,
  },
  kategoriaHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingBottom: spacing.sm,
  },
  kategoriaTitle: {
    fontSize: font.sizes.base,
    fontWeight: font.weights.bold,
    color: colors.text,
  },
  deleteButton: {
    padding: spacing.xs,
  },
  
  // Wagi w kategoriach
  wagiContainer: {
    minHeight: spacing.lg,
  },
  wagiRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
  },
  wagaTile: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    marginBottom: spacing.xs,
    flexDirection: 'row',
    alignItems: 'center',
  },
  wagaText: {
    color: colors.text,
    fontWeight: font.weights.medium,
    fontSize: font.sizes.sm,
  },
  wagaDeleteBtn: {
    marginLeft: spacing.xs,
    padding: spacing.xs,
  },
  wagiEmpty: {
    color: colors.textSecondary,
    fontSize: font.sizes.sm,
    fontStyle: 'italic',
  },
  
  // Style dla modali
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.xl,
    padding: spacing.lg,
    width: '90%',
    maxWidth: 370,
    ...shadows.large,
    alignItems: 'center',
  },
  confirmModalCard: {
    maxWidth: 320,
  },
  modalIconHeader: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
    ...shadows.small,
  },
  modalTitle: {
    fontSize: font.sizes.lg,
    fontWeight: font.weights.bold,
    color: colors.text,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  confirmTitle: {
    fontSize: font.sizes.base,
    lineHeight: font.sizes.lg,
  },
  
  // Pola formularza i wybór kategorii
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    width: '100%',
    padding: spacing.sm,
    backgroundColor: colors.surface,
    color: colors.text,
    fontSize: font.sizes.base,
    marginBottom: spacing.md,
  },
  selectBox: {
    width: '100%',
    marginBottom: spacing.md,
  },
  selectLabel: {
    fontSize: font.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  errorText: {
    color: colors.error,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  selectScroll: {
    maxHeight: 120,
    width: '100%',
  },
  selectScrollContent: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: spacing.xs,
    alignItems: 'center',
  },
  selectItem: {
    backgroundColor: colors.background,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.sm,
    marginRight: spacing.xs,
    marginBottom: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
  },
  selectItemActive: {
    backgroundColor: colors.accent,
    borderColor: colors.accent,
  },
  selectItemText: {
    color: colors.text,
    fontSize: font.sizes.sm,
  },
  selectItemTextActive: {
    color: colors.textLight,
    fontWeight: font.weights.medium,
  },
  
  // Przyciski w modalach
  modalBtns: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    gap: spacing.md,
  },
  modalBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    ...shadows.small,
  },
  confirmBtn: {
    backgroundColor: colors.accent,
  },
  cancelBtn: {
    backgroundColor: colors.button.secondary,
  },
  deleteBtn: {
    backgroundColor: colors.error,
  },
  btnText: {
    color: colors.textLight,
    fontWeight: font.weights.medium,
  },
  
  // Notyfikacje
  notification: {
    position: 'absolute',
    bottom: spacing.lg,
    left: '50%',
    transform: [{ translateX: -150 }],
    width: 300,
    padding: spacing.sm,
    borderRadius: borderRadius.lg,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    ...shadows.medium,
  },
  notifSuccess: {
    borderLeftWidth: 4,
    borderLeftColor: colors.success,
  },
  notifError: {
    borderLeftWidth: 4,
    borderLeftColor: colors.error,
  },
  notifIcon: {
    marginRight: spacing.sm,
  },
  notifText: {
    color: colors.text,
    fontWeight: font.weights.medium,
  },
});