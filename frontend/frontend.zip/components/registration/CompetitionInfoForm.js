import React, { useState, useRef } from 'react';
import {
  View, TextInput, Button, Text, TouchableOpacity, Image
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { useCompetitionStore } from '../../store/useCompetitionStore';
import { colors } from '../../theme/theme';
import styles from '../../styles/CompetitionInfoForm.styles';
import { saveAppData } from '../../utils/api';

export default function CompetitionInfoForm() {
  const zawody = useCompetitionStore(state => state.zawody);
  const setZawody = useCompetitionStore(state => state.setZawody);
  const setSedzia = useCompetitionStore(state => state.setSedzia);
  const setKlubAvatar = useCompetitionStore(state => state.setKlubAvatar);

  const [editing, setEditing] = useState(true);
  const [nazwa, setNazwa] = useState(zawody.nazwa || 'Benchpress Cup 2025');
  const [miejsce, setMiejsce] = useState(zawody.miejsce || '');
  const [data, setData] = useState(zawody.data || new Date().toISOString().slice(0, 10));
  const [sedzia, setSedziaLocal] = useState({
    imie: zawody.sedzia?.imie || '',
    nazwisko: zawody.sedzia?.nazwisko || '',
    avatar: zawody.sedzia?.avatar || null,
  });
  const [klubAvatar, setKlubAvatarLocal] = useState(zawody.klubAvatar || null);
  const [notif, setNotif] = useState(null);
  const notifTimeout = useRef(null);

  const handlePickAvatar = async (type) => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
      base64: true, // <-- dodaj to!
    });
    if (!result.canceled && result.assets?.length) {
      const asset = result.assets[0];
      const base64 = asset.base64
        ? `data:image/jpeg;base64,${asset.base64}`
        : null;
      if (type === 'klub') {
        setKlubAvatarLocal(base64);
      } else {
        setSedziaLocal(s => ({ ...s, avatar: base64 }));
      }
    }
  };

  const showNotif = (msg, type) => {
    setNotif({ msg, type });
    if (notifTimeout.current) clearTimeout(notifTimeout.current);
    notifTimeout.current = setTimeout(() => setNotif(null), 3000);
  };

  // Modyfikacja funkcji zapisu – aktualizujemy store i wysyłamy dane do backendu
  const handleSave = async () => {
    if (!nazwa.trim() || !miejsce.trim() || !sedzia.imie.trim() || !sedzia.nazwisko.trim()) {
      showNotif('Uzupełnij dane!', 'error');
      return;
    }
    // Aktualizacja store'u
    setZawody({ nazwa, miejsce, data, klubAvatar, sedzia: { ...sedzia } });
    setSedzia({ ...sedzia });
    setKlubAvatar(klubAvatar);
    // Wysyłamy aktualny stan do backendu
    try {
      const state = useCompetitionStore.getState();
      await saveAppData({
        zawody: state.zawody,
        kategorie: state.kategorie,
        zawodnicy: state.zawodnicy,
      });
      showNotif('Zapisano!', 'success');
      setEditing(false);
    } catch (error) {
      console.error('Błąd zapisu danych:', error);
      showNotif('Błąd zapisu danych!', 'error');
    }
  };

  const renderInfoDisplay = () => (
    <View style={styles.infoDisplay}>
      <Text style={styles.displayHeader}>{nazwa}</Text>
      <View style={styles.infoSides}>
        <View style={styles.infoSide}>
          <Text style={styles.infoLabel}>Klub</Text>
          {klubAvatar ? (
            <Image source={{ uri: klubAvatar }} style={styles.avatarImg} />
          ) : (
            <Text style={styles.infoText}>(brak)</Text>
          )}
        </View>
        <View style={styles.infoSide}>
          <Text style={styles.infoLabel}>Sędzia</Text>
          <Text style={styles.infoText}>{sedzia.imie} {sedzia.nazwisko}</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.editButton} onPress={() => setEditing(true)}>
        <Text style={styles.editButtonText}>zmień informacje o zawodach</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.infoCard}>
      {editing ? (
        <>
          {/* Wiersz z avatarami */}
          <View style={styles.infoRow}>
            <View style={styles.infoColLeft}>
              <TouchableOpacity style={styles.avatarBox} onPress={() => handlePickAvatar('klub')}>
                {klubAvatar ? (
                  <Image source={{ uri: klubAvatar }} style={styles.avatarImg} />
                ) : (
                  <Text style={styles.avatarPlaceholder}>Klub</Text>
                )}
              </TouchableOpacity>
            </View>
            <View style={styles.spacer} />
            <View style={styles.infoColRight}>
              <TouchableOpacity style={styles.avatarBox} onPress={() => handlePickAvatar('sedzia')}>
                {sedzia.avatar ? (
                  <Image source={{ uri: sedzia.avatar }} style={styles.avatarImg} />
                ) : (
                  <Text style={styles.avatarPlaceholder}>Sędzia</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
          {/* Wiersz z polami wejściowymi */}
          <View style={styles.infoRow}>
            <View style={styles.infoColLeft}>
              <TextInput
                style={styles.inputHalf}
                placeholder="Miejscowość"
                value={miejsce}
                onChangeText={setMiejsce}
              />
              <TextInput
                style={styles.inputHalf}
                placeholder="Data"
                value={data}
                onChangeText={setData}
              />
            </View>
            <View style={styles.spacer} />
            <View style={styles.infoColRight}>
              <TextInput
                style={styles.inputHalf}
                placeholder="Imię sędziego"
                value={sedzia.imie}
                onChangeText={v => setSedziaLocal(s => ({ ...s, imie: v }))}
              />
              <TextInput
                style={styles.inputHalf}
                placeholder="Nazwisko sędziego"
                value={sedzia.nazwisko}
                onChangeText={v => setSedziaLocal(s => ({ ...s, nazwisko: v }))}
              />
            </View>
          </View>
          {/* Wiersz z nazwą zawodów i przyciskiem zapisu */}
          <View style={styles.saveRow}>
            <TextInput
              style={styles.fullInput}
              placeholder="Nazwa zawodów"
              value={nazwa}
              onChangeText={setNazwa}
            />
            <Button title="Zapisz" color={colors.primary} onPress={handleSave} />
          </View>
        </>
      ) : (
        renderInfoDisplay()
      )}
      {notif && (
        <View style={[styles.notif, notif.type === 'success' ? styles.notifSuccess : styles.notifError]}>
          <Text style={styles.notifText}>{notif.msg}</Text>
        </View>
      )}
    </View>
  );
}