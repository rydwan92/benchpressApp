import React, { useState, useRef } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView } from 'react-native';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { useCompetitionStore } from '../../store/useCompetitionStore';
import { colors, font } from '../../theme/theme';
import { saveAppData } from '../../utils/api';

export default function CompetitionSummary() {
  const zawodnicy = useCompetitionStore(state => state.zawodnicy) || [];
  const [notif, setNotif] = useState(null);
  const notifTimeout = useRef(null);

  // Powiadomienia
  const showNotif = (msg, type) => {
    setNotif({ msg, type });
    if (notifTimeout.current) clearTimeout(notifTimeout.current);
    notifTimeout.current = setTimeout(() => setNotif(null), 3000);
  };

  // Funkcja synchronizująca – wysyła cały stan do backendu
  const syncData = async () => {
    try {
      const state = useCompetitionStore.getState();
      await saveAppData({
        zawody: state.zawody,
        kategorie: state.kategorie,
        zawodnicy: state.zawodnicy,
      });
      showNotif('Dane odświeżone!', 'success');
    } catch (error) {
      console.error('Błąd odświeżania danych:', error);
      showNotif('Błąd odświeżania!', 'error');
    }
  };

  const allAttempts = [];
  zawodnicy.forEach(z => {
    [z.podejscie1, z.podejscie2, z.podejscie3].forEach(attempt => {
      const weight = Number(attempt);
      if (weight > 0) {
        allAttempts.push({
          imie: z.imie,
          nazwisko: z.nazwisko,
          klub: z.klub,
          weight,
        });
      }
    });
  });
  const totalWeight = allAttempts.reduce((sum, attempt) => sum + attempt.weight, 0);
  const sortedAttempts = allAttempts.sort((a, b) => b.weight - a.weight);
  const top10 = sortedAttempts.slice(0, 10);

  const handleExport = async () => {
    const header = ['Imię', 'Nazwisko', 'Klub', 'Waga'];
    const rows = top10.map(attempt => [
      attempt.imie, attempt.nazwisko, attempt.klub, attempt.weight
    ]);
    const csv = [header, ...rows].map(r => r.join(';')).join('\n');
    const fileUri = FileSystem.cacheDirectory + 'top10_attempts.csv';
    await FileSystem.writeAsStringAsync(fileUri, csv, { encoding: FileSystem.EncodingType.UTF8 });
    await Sharing.shareAsync(fileUri, { mimeType: 'text/csv' });
  };

  return (
    <View style={styles.summaryBox}>
      <TouchableOpacity style={styles.refreshBtn} onPress={syncData}>
        <Text style={styles.refreshBtnText}>Odśwież dane</Text>
      </TouchableOpacity>
      <Text style={styles.headerText}>Top 10 najlepszych podejść:</Text>
      <Text style={styles.humorText}>
        Łącznie podniesiono {totalWeight} kg – wow, to ciężko!
      </Text>
      <ScrollView style={styles.attemptList}>
        {top10.length === 0 && <Text style={styles.noAttempts}>Brak podejść</Text>}
        {top10.map((at, i) => (
          <View key={i} style={styles.row}>
            <Text style={styles.rankCell}>{i + 1}.</Text>
            <Text style={styles.cell}>{at.imie} {at.nazwisko}</Text>
            <Text style={styles.cell}>{at.klub}</Text>
            <Text style={styles.cell}>{at.weight} kg</Text>
          </View>
        ))}
      </ScrollView>
      {notif && (
        <View style={[styles.notif, notif.type === 'success' ? styles.notifSuccess : styles.notifError]}>
          <Text style={styles.notifText}>{notif.msg}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  summaryBox: {
    backgroundColor: '#f4f8fc',
    borderRadius: 16,
    padding: 18,
    marginBottom: 18,
  },
  exportBtn: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignSelf: 'flex-end',
    marginBottom: 12,
  },
  exportBtnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  refreshBtn: {
    backgroundColor: '#555',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
    alignSelf: 'flex-end',
    marginBottom: 12,
  },
  refreshBtnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  headerText: {
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 8,
    textAlign: 'center',
  },
  humorText: {
    fontSize: 16,
    fontStyle: 'italic',
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 12,
  },
  attemptList: {
    maxHeight: 300,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderColor: '#d1d5db',
    paddingVertical: 6,
    alignItems: 'center',
  },
  rankCell: {
    flex: 0.1,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
    color: colors.text,
  },
  cell: {
    flex: 0.3,
    textAlign: 'center',
    fontSize: 16,
    color: colors.text,
  },
  noAttempts: {
    textAlign: 'center',
    color: colors.textSecondary,
    marginVertical: 16,
  },
  notif: {
    marginTop: 16,
    padding: 12,
    borderRadius: 8,
  },
  notifSuccess: {
    backgroundColor: '#d4f8e8',
  },
  notifError: {
    backgroundColor: '#ffd6d6',
  },
  notifText: {
    color: colors.text,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});