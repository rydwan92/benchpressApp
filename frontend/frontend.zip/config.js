export const CONFIG = {
    BACKEND_ADDRESS: 'http://localhost:5000'
  };