import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, Alert, ActivityIndicator, Platform } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { useCompetitionStore } from '../store/useCompetitionStore';
import NavBar from '../components/navigation/NavBar';
import Footer from '../components/navigation/Footer';
import OptionSelector from '../components/competition/OptionSelector';
import AthleteList from '../components/competition/AthleteList';
import CurrentAthleteManager from '../components/competition/CurrentAthleteManager';
import TimerDisplay from '../components/competition/TimerDisplay';
import { styles } from '../styles/CompetitionStyles/CompetitionScreen.styles.js';
import { saveAppData } from '../utils/api'; // Ensure this is correctly imported
import { colors } from '../theme/theme'; // For ActivityIndicator color

console.log('--- TEST LOG: CompetitionScreen PLIK ZAŁADOWANY ---');

const hasAthleteCompletedAttemptInRound = (athlete, roundNumber) => {
  return athlete && athlete[`podejscie${roundNumber}Status`] !== null;
};

const hasAthleteCompleted = (athlete) => {
  if (!athlete) return false;
  return (
    athlete.podejscie1Status !== null &&
    athlete.podejscie2Status !== null &&
    athlete.podejscie3Status !== null
  );
};

const getAthleteDeclaredWeightForRound = (athlete, roundNumber) => {
  if (!athlete) return Infinity; // Zawodnicy bez danych na końcu
  const weight = parseFloat(athlete[`podejscie${roundNumber}`]);
  return isNaN(weight) || weight <= 0 ? Infinity : weight; // Niezadeklarowany lub 0 na końcu
};

const MAX_TIMER_SECONDS = 60;

// DODAJ DEFINICJĘ KOMPONENTU TUTAJ:
const NextCompetitorButton = ({ onPress, disabled }) => {
  return (
    <TouchableOpacity
      style={[styles.secondaryActionButton, disabled && styles.actionButtonDisabled]} // Użyj odpowiedniego stylu dla przycisku drugorzędnego
      onPress={onPress}
      disabled={disabled}
    >
      <Text style={styles.secondaryActionButtonText}>Następny Zawodnik / Runda</Text>
    </TouchableOpacity>
  );
};

export default function CompetitionScreen() {
  console.log('--- TEST LOG: CompetitionScreen FUNKCJA WYWOŁANA ---');
  const navigation = useNavigation();
  const {
    zawody, kategorie, zawodnicy,
    activeCategory, activeWeight, activeAthleteOriginalIndex, activeAttemptNr,
    currentRound, // <--- POBIERZ currentRound
    timerActive, timerTimeLeft,
    updatePodejscieStatus, updatePodejscieWaga,
    setActiveGroup, setActiveAthlete, setActiveAttemptNr,
    setCurrentRound, // <--- POBIERZ setCurrentRound
    setTimerActive, setTimerTimeLeft,
    socket,
    setAttemptResultForAnimation
  } = useCompetitionStore(state => ({
      zawody: state.zawody,
      kategorie: state.kategorie,
      zawodnicy: state.zawodnicy,
      activeCategory: state.activeCategory,
      activeWeight: state.activeWeight,
      activeAthleteOriginalIndex: state.activeAthleteOriginalIndex,
      activeAttemptNr: state.activeAttemptNr,
      currentRound: state.currentRound,
      timerActive: state.timerActive,
      timerTimeLeft: state.timerTimeLeft,
      updatePodejscieStatus: state.updatePodejscieStatus,
      updatePodejscieWaga: state.updatePodejscieWaga,
      setActiveGroup: state.setActiveGroup,
      setActiveAthlete: state.setActiveAthlete,
      setActiveAttemptNr: state.setActiveAttemptNr,
      setCurrentRound: state.setCurrentRound,
      setTimerActive: state.setTimerActive,
      setTimerTimeLeft: state.setTimerTimeLeft,
      socket: state.socket,
      setAttemptResultForAnimation: state.setAttemptResultForAnimation
  }));

  const [isSaving, setIsSaving] = useState(false);
  const [headerKlubAvatarDimensions, setHeaderKlubAvatarDimensions] = useState(null);
  const [headerJudgeAvatarDimensions, setHeaderJudgeAvatarDimensions] = useState(null);

  const timerIntervalRef = useRef(null);

  // Stable store actions - ensure they use the latest store functions
  const stableSetTimerTimeLeft = useCallback((value) => setTimerTimeLeft(value), [setTimerTimeLeft]);
  const stableSetTimerActive = useCallback((value) => setTimerActive(value), [setTimerActive]);

  // Avatar loading useEffects (no changes, assuming they are correct)
  useEffect(() => {
    if (zawody.klubAvatar) {
      Image.getSize(zawody.klubAvatar, (width, height) => {
        const aspectRatio = width / height;
        const maxWidth = 150; const maxHeight = 90; let displayWidth = width; let displayHeight = height;
        if (displayWidth > maxWidth) { displayWidth = maxWidth; displayHeight = displayWidth / aspectRatio; }
        if (displayHeight > maxHeight) { displayHeight = maxHeight; displayWidth = displayHeight * aspectRatio; }
        setHeaderKlubAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, () => setHeaderKlubAvatarDimensions(null));
    } else { setHeaderKlubAvatarDimensions(null); }
  }, [zawody.klubAvatar]);

  useEffect(() => {
    if (zawody.sedzia?.avatar) {
      Image.getSize(zawody.sedzia.avatar, (width, height) => {
        const aspectRatio = width / height;
        const maxWidth = 150; const maxHeight = 90; let displayWidth = width; let displayHeight = height;
        if (displayWidth > maxWidth) { displayWidth = maxWidth; displayHeight = displayWidth / aspectRatio; }
        if (displayHeight > maxHeight) { displayHeight = maxHeight; displayWidth = displayHeight * aspectRatio; }
        setHeaderJudgeAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, () => setHeaderJudgeAvatarDimensions(null));
    } else { setHeaderJudgeAvatarDimensions(null); }
  }, [zawody.sedzia?.avatar]);

  // Data synchronization function
   const syncData = useCallback(async (immediateStateOverride = null) => {
    if (isSaving && !immediateStateOverride) { // Pozwól na sync jeśli jest override, nawet gdy isSaving
        console.warn('[CompetitionScreen] syncData: Save already in progress. Skipping.');
        return;
    }
    setIsSaving(true);
    console.log('[CompetitionScreen] syncData: Starting data save...');
    try {
      const currentStateFromStore = (({ socket, ...rest }) => rest)(useCompetitionStore.getState());
      const dataToSend = immediateStateOverride 
        ? { ...currentStateFromStore, ...immediateStateOverride } 
        : currentStateFromStore;

      console.log('[CompetitionScreen] syncData: Data to send:', dataToSend);
      await saveAppData(dataToSend);
      console.log('[CompetitionScreen] syncData: Data saved successfully.');
    } catch (error) {
        console.error('[CompetitionScreen] syncData: Error saving data:', error);
    } finally {
      setIsSaving(false);
      console.log('[CompetitionScreen] syncData: Save operation finished.');
    }
  }, [isSaving]);

  const handleSelectAthlete = useCallback(async (selectedAthleteOriginalIndex) => {
    console.log(`[CompetitionScreen] handleSelectAthlete called for index: ${selectedAthleteOriginalIndex}`);
    if (timerActive) {
      Alert.alert("Timer Aktywny", "Nie można zmienić zawodnika podczas aktywnego czasu.");
      return;
    }
    if (isSaving) {
        console.warn('[CompetitionScreen] handleSelectAthlete: Save in progress. Skipping.');
        return;
    }

    // Set the active athlete in the store. This action also sets activeAttemptNr = currentRound.
    setActiveAthlete(selectedAthleteOriginalIndex);

    // Get the current round from the store, which setActiveAthlete used to set activeAttemptNr.
    // This ensures that when an athlete is manually selected, they are set for the current competition round.
    const currentRoundFromStore = useCompetitionStore.getState().currentRound;
    const newActiveAttemptNr = currentRoundFromStore;

    console.log(`[CompetitionScreen] Manual selection: Syncing activeAthleteOriginalIndex: ${selectedAthleteOriginalIndex}, activeAttemptNr: ${newActiveAttemptNr}, currentRound: ${currentRoundFromStore}`);
    await syncData({
      activeAthleteOriginalIndex: selectedAthleteOriginalIndex,
      activeAttemptNr: newActiveAttemptNr, // This will be the current round
      currentRound: currentRoundFromStore  // Ensure currentRound itself is also synced
    });
  }, [setActiveAthlete, syncData, timerActive, isSaving]);

  // Timer finish handler - ensure it has correct dependencies
  const handleTimerFinish = useCallback(() => {
    console.log("[CompetitionScreen] LOG A: handleTimerFinish called");
    const currentStoreState = useCompetitionStore.getState();
    if (currentStoreState.activeAthleteOriginalIndex !== null && currentStoreState.activeAttemptNr) {
        const athlete = currentStoreState.zawodnicy[currentStoreState.activeAthleteOriginalIndex];
        if (athlete && !athlete[`podejscie${currentStoreState.activeAttemptNr}Status`]) {
            console.log(`[CompetitionScreen] Timer finished, marking attempt ${currentStoreState.activeAttemptNr} as failed for athlete ${currentStoreState.activeAthleteOriginalIndex}`);
            // Ensure handleAttemptStatusChange is stable or included in dependencies if it changes
            // For now, assuming updatePodejscieStatus and setAttemptResultForAnimation are stable or correctly handled by their own useCallbacks
            updatePodejscieStatus(currentStoreState.activeAthleteOriginalIndex, currentStoreState.activeAttemptNr, 'failed');
            setAttemptResultForAnimation(false);
            // stableSetTimerActive(false); // Timer is already stopped by the interval logic
            // syncData(); // This might be called by updatePodejscieStatus or handleAttemptStatusChange
        }
    }
  }, [updatePodejscieStatus, setAttemptResultForAnimation]); // Add other dependencies if they are used and can change


  // Main timer useEffect
  useEffect(() => {
    console.log(`[CompetitionScreen] LOG B: Main timer useEffect triggered. timerActive: ${timerActive}`);
    if (timerActive) {
      console.log("[CompetitionScreen] LOG C: timerActive is true. Setting up interval.");
      if (timerIntervalRef.current) {
        console.log("[CompetitionScreen] LOG D: Clearing pre-existing interval.");
        clearInterval(timerIntervalRef.current);
      }
      // const initialTime = useCompetitionStore.getState().timerTimeLeft; // Czas jest już ustawiony przed aktywacją timera
      // console.log(`[CompetitionScreen] LOG E: Starting timer interval. Initial time from store: ${initialTime}`);
      
      timerIntervalRef.current = setInterval(() => {
        const currentStoreTime = useCompetitionStore.getState().timerTimeLeft;
        console.log(`${Date.now()} [CompetitionScreen] LOG F: Interval tick. Current store time: ${currentStoreTime}`); 
        
        if (typeof currentStoreTime !== 'number' || isNaN(currentStoreTime)) {
            console.error("[CompetitionScreen] LOG F Error: currentStoreTime is not a valid number:", currentStoreTime);
            clearInterval(timerIntervalRef.current);
            timerIntervalRef.current = null;
            stableSetTimerActive(false);
            return;
        }

        let newTimeLeft;
        if (currentStoreTime <= 1) {
          console.log("[CompetitionScreen] LOG G: Time is <= 1. Clearing interval and stopping timer.");
          clearInterval(timerIntervalRef.current);
          timerIntervalRef.current = null;
          newTimeLeft = 0;
          stableSetTimerTimeLeft(newTimeLeft);
          stableSetTimerActive(false);
          handleTimerFinish(); 
          if (socket && socket.connected) {
            // Emitujemy stopTimer z finalnym czasem 0
            socket.emit('stopTimer', { finalTimeLeft: newTimeLeft, reason: 'finished' });
            console.log(`${Date.now()} [CompetitionScreen] Emitted stopTimer with finalTimeLeft: ${newTimeLeft}`);
          }
        } else {
          newTimeLeft = currentStoreTime - 1;
          stableSetTimerTimeLeft(newTimeLeft);
          if (socket && socket.connected) {
            console.log(`${Date.now()} [CompetitionScreen] Emitting timerTick: timeLeft=${newTimeLeft}`);
            socket.emit('timerTick', { timeLeft: newTimeLeft });
          }
        }
      }, 1000);
    } else {
      console.log("[CompetitionScreen] LOG I: timerActive is false. Clearing interval if it exists.");
      if (timerIntervalRef.current) {
        console.log('[CompetitionScreen] LOG J: Clearing timer interval because timerActive is false.');
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
    return () => {
      console.log('[CompetitionScreen] LOG K: useEffect cleanup. Clearing interval if it exists.');
      if (timerIntervalRef.current) {
        console.log('[CompetitionScreen] LOG L: useEffect cleanup - interval cleared.');
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    };
  }, [timerActive, stableSetTimerActive, stableSetTimerTimeLeft, socket, handleTimerFinish]);

  // Logika wyboru zawodników i zarządzania kolejnością
  const athletesInCurrentGroup = useMemo(() => {
    if (!activeCategory || !activeWeight || !zawodnicy) return [];
    return zawodnicy
      .map((z, index) => ({ ...z, originalIndex: index }))
      .filter(z => z.kategoria === activeCategory && z.waga === activeWeight);
  }, [zawodnicy, activeCategory, activeWeight]);

  const upcomingAthletesForCurrentRound = useMemo(() => {
    if (!activeCategory || !activeWeight || currentRound > 3) return [];

    return athletesInCurrentGroup
      .filter(athlete => !hasAthleteCompletedAttemptInRound(athlete, currentRound))
      .sort((a, b) => {
        const weightA = getAthleteDeclaredWeightForRound(a, currentRound);
        const weightB = getAthleteDeclaredWeightForRound(b, currentRound);
        if (weightA === weightB) {
          // Dodatkowe kryterium sortowania, np. po numerze startowym lub nazwisku, jeśli ciężary są równe
          // Na razie proste sortowanie po originalIndex dla stabilności
          return a.originalIndex - b.originalIndex;
        }
        return weightA - weightB;
      });
  }, [athletesInCurrentGroup, currentRound, activeCategory, activeWeight]);


  const currentAthlete = useMemo(() => {
    if (activeAthleteOriginalIndex === null || !zawodnicy) return null;
    return zawodnicy[activeAthleteOriginalIndex];
  }, [zawodnicy, activeAthleteOriginalIndex]);


  // Funkcja do wyboru następnego zawodnika w rundzie lub przejścia do następnej rundy
  const advanceToNextCompetitorOrRound = useCallback(async () => {
    console.log(`[CompetitionScreen] advanceToNextCompetitorOrRound called. Current round: ${currentRound}`);
    if (timerActive) {
      console.warn("[CompetitionScreen] Timer is active, cannot advance yet.");
      return;
    }

    const nextAthletesInRound = upcomingAthletesForCurrentRound;
    let newActiveAthleteIndex = null;
    let newActiveAttemptNr = 1; // Domyślnie

    if (nextAthletesInRound.length > 0) {
      const nextAthleteToCall = nextAthletesInRound[0];
      console.log(`[CompetitionScreen] Next athlete in round ${currentRound}: ${nextAthleteToCall.imie} ${nextAthleteToCall.nazwisko} (Index: ${nextAthleteToCall.originalIndex})`);
      setActiveAthlete(nextAthleteToCall.originalIndex); // To ustawi też activeAttemptNr na currentRound w store
      
      // Pobierz wartości, które ZOSTANĄ ustawione przez setActiveAthlete
      // Akcja setActiveAthlete w store ustawia activeAttemptNr na podstawie state.currentRound
      newActiveAthleteIndex = nextAthleteToCall.originalIndex;
      newActiveAttemptNr = useCompetitionStore.getState().currentRound; // Pobierz aktualną rundę, która będzie użyta do ustawienia activeAttemptNr

      console.log(`[CompetitionScreen] Store after setActiveAthlete: activeAthleteOriginalIndex=${useCompetitionStore.getState().activeAthleteOriginalIndex}, activeAttemptNr=${useCompetitionStore.getState().activeAttemptNr}`);
    } else {
      if (currentRound < 3) {
        const nextRoundVal = currentRound + 1;
        Alert.alert(
          "Koniec Rundy",
          `Wszyscy zawodnicy ukończyli podejście ${currentRound}.\nCzy chcesz przejść do podejścia ${nextRoundVal}?`,
          [
            { text: "Anuluj", style: "cancel" },
            { text: `Przejdź do podejścia ${nextRoundVal}`, onPress: async () => {
                console.log(`[CompetitionScreen] Advancing to round ${nextRoundVal}`);
                setCurrentRound(nextRoundVal);
                // Po zmianie rundy, activeAthleteOriginalIndex będzie null, activeAttemptNr będzie nextRoundVal
                // syncData poniżej obsłuży wysłanie tego stanu
                // Nie ma potrzeby wywoływania advanceToNextCompetitorOrRound rekursywnie tutaj,
                // useEffect [activeAthleteOriginalIndex, upcomingAthletesForCurrentRound, timerActive] powinien to obsłużyć.
              }
            }
          ]
        );
        // W przypadku alertu, syncData zostanie wywołane na końcu funkcji,
        // potencjalnie z newActiveAthleteIndex = null, jeśli użytkownik anuluje lub zanim wybierze nową rundę.
        // Jeśli użytkownik wybierze nową rundę, setCurrentRound ustawi stan, a useEffect go podchwyci.
      } else {
        Alert.alert("Koniec Zawodów", "Wszyscy zawodnicy ukończyli wszystkie 3 podejścia w tej grupie!");
        setActiveAthlete(null);
        newActiveAthleteIndex = null; // Upewnij się, że to jest wysyłane
      }
    }

    // Synchronizuj stan po zmianach, przekazując świeżo ustawione wartości
    // Jeśli setActiveAthlete(null) było wywołane, newActiveAthleteIndex będzie null.
    // Jeśli nowa runda została ustawiona, activeAttemptNr powinno odzwierciedlać nową rundę.
    // Jeśli zawodnik został wybrany, newActiveAthleteIndex i newActiveAttemptNr będą ustawione.
    // Jeśli po prostu kończymy rundę bez natychmiastowego przejścia, activeAthleteOriginalIndex może być null.
    const stateForSync = {};
    if (newActiveAthleteIndex !== null) {
        stateForSync.activeAthleteOriginalIndex = newActiveAthleteIndex;
        stateForSync.activeAttemptNr = newActiveAttemptNr;
    } else {
        stateForSync.activeAthleteOriginalIndex = null; // Jawne wysłanie null jeśli nie ma aktywnego zawodnika
        // activeAttemptNr może pozostać takie jakie jest w store lub być zresetowane do 1, jeśli grupa się zmienia
        // Akcja setActiveGroup resetuje activeAttemptNr do 1.
        // Tutaj, jeśli tylko czyścimy zawodnika, activeAttemptNr z ostatniego stanu jest OK.
    }
    // Zawsze wysyłaj aktualną rundę, jeśli się zmieniła (np. przez setCurrentRound)
    stateForSync.currentRound = useCompetitionStore.getState().currentRound;


    await syncData(stateForSync); 
  }, [currentRound, upcomingAthletesForCurrentRound, setActiveAthlete, setCurrentRound, syncData, timerActive, zawodnicy /* dodane zawodnicy, bo logika w else może od nich zależeć */]);

  // Efekt do automatycznego wywołania pierwszego zawodnika po zmianie rundy lub grupy
  useEffect(() => {
    // Jeśli nie ma aktywnego zawodnika, A są zawodnicy oczekujący w bieżącej rundzie,
    // ORAZ timer nie jest aktywny, wybierz pierwszego.
    if (activeAthleteOriginalIndex === null && upcomingAthletesForCurrentRound.length > 0 && !timerActive) {
      console.log("[CompetitionScreen] useEffect: No active athlete, attempting to select first in current round.");
      advanceToNextCompetitorOrRound();
    }
  }, [activeAthleteOriginalIndex, upcomingAthletesForCurrentRound, timerActive, advanceToNextCompetitorOrRound]);


  const handleAttemptStatusChange = useCallback(async (athleteOriginalIndex, attemptNo, status) => {
    if (isSaving) {
      console.warn('[CompetitionScreen] handleAttemptStatusChange: Save in progress. Skipping.');
      return;
    }
    console.log(`[CompetitionScreen] handleAttemptStatusChange: AthleteIdx: ${athleteOriginalIndex}, Attempt: ${attemptNo}, Status: ${status}`);
    setIsSaving(true);

    // Zaktualizuj status w store
    updatePodejscieStatus(athleteOriginalIndex, attemptNo, status);
    setAttemptResultForAnimation(status === 'passed'); // Ustaw animację

    // Zaktualizuj socket, jeśli jest dostępny
    if (socket && socket.connected) {
      socket.emit('attemptUpdated', {
        athleteOriginalIndex,
        attemptNo,
        status,
        // Możesz dodać więcej danych, jeśli są potrzebne po stronie AthleteView
      });
    }
    
    // Poczekaj chwilę na przetworzenie animacji/socketów przed przejściem dalej
    // To jest opcjonalne, ale może poprawić UX
    await new Promise(resolve => setTimeout(resolve, 150)); 


    // Upewnij się, że timer jest zatrzymany przed próbą przejścia dalej
    if (timerActive) {
      console.warn("[CompetitionScreen] handleAttemptStatusChange: Timer still active. Stopping it first.");
      stableSetTimerActive(false); // Zatrzymaj timer, jeśli był aktywny
      // Poczekaj chwilę, aby dać czas na przetworzenie zatrzymania timera i socketów
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    await advanceToNextCompetitorOrRound();
    // syncData() jest już wołane w advanceToNextCompetitorOrRound
    setIsSaving(false);
    console.log('[CompetitionScreen] handleAttemptStatusChange: Finished.');
  }, [isSaving, stableSetTimerActive, updatePodejscieStatus, setAttemptResultForAnimation, advanceToNextCompetitorOrRound, socket, timerActive]);

  // DODAJ TĘ FUNKCJĘ:
  const handleWeightChange = useCallback(async (athleteOriginalIndex, attemptNo, weight) => {
    if (isSaving) {
      console.warn('[CompetitionScreen] handleWeightChange: Save in progress. Skipping.');
      return;
    }
    console.log(`[CompetitionScreen] handleWeightChange: AthleteIdx: ${athleteOriginalIndex}, Attempt: ${attemptNo}, Weight: ${weight}`);
    setIsSaving(true);
    updatePodejscieWaga(athleteOriginalIndex, attemptNo, weight);

    if (socket && socket.connected) {
      socket.emit('weightUpdated', { // Możesz użyć innego eventu lub tego samego co status
        athleteOriginalIndex,
        attemptNo,
        weight,
      });
    }
    await syncData(); // Synchronizuj dane po zmianie wagi
    setIsSaving(false);
    console.log('[CompetitionScreen] handleWeightChange: Finished.');
  }, [isSaving, updatePodejscieWaga, syncData, socket]);


  // Timer Control Handlers
  const handleStartOrRestartAttempt = () => {
    if (!currentAthlete || isSaving || activeAttemptNr !== currentRound) {
        console.log(`[CompetitionScreen] Cannot start/restart: no current athlete, saving, or attempt number (${activeAttemptNr}) doesn't match current round (${currentRound}).`);
        if (activeAttemptNr !== currentRound) {
            Alert.alert("Uwaga", `Próbujesz uruchomić timer dla podejścia ${activeAttemptNr}, ale aktualna runda to ${currentRound}.`);
        }
        return;
    }
    // ... (reszta logiki handleStartOrRestartAttempt bez zmian, używa MAX_TIMER_SECONDS)
    // Upewnij się, że activeAttemptNr jest poprawnie ustawione przez setActiveAthlete
    console.log(`[CompetitionScreen] handleStartOrRestartAttempt for athlete index: ${activeAthleteOriginalIndex}, attempt: ${activeAttemptNr} (currentRound: ${currentRound})`);
    const newInitialTime = MAX_TIMER_SECONDS;
    stableSetTimerTimeLeft(newInitialTime);
    stableSetTimerActive(true);
    if (socket && socket.connected) {
      socket.emit('startTimer', { timeLeft: newInitialTime, athleteId: activeAthleteOriginalIndex, attemptNr: activeAttemptNr });
      console.log(`[CompetitionScreen] Emitted startTimer with timeLeft: ${newInitialTime}`);
    }
  };

  const handleResumeAttempt = () => {
    const currentTime = useCompetitionStore.getState().timerTimeLeft;
    if (!currentAthlete || timerActive || isSaving || currentTime <= 0 || currentTime >= MAX_TIMER_SECONDS) return;
    console.log(`[CompetitionScreen] handleResumeAttempt. Resuming from: ${currentTime}`);
    stableSetTimerActive(true); // Just activate, time is already set
    if (socket && socket.connected) {
      socket.emit('startTimer', { timeLeft: currentTime, athleteId: activeAthleteOriginalIndex, attemptNr: activeAttemptNr });
    }
  };

  const handleStopAttempt = () => {
    if (!timerActive || isSaving) return;
    const timeLeftWhenStopped = useCompetitionStore.getState().timerTimeLeft;
    console.log(`[CompetitionScreen] handleStopAttempt. Time left: ${timeLeftWhenStopped}`);
    stableSetTimerActive(false); // To wyczyści interwał przez useEffect
    if (socket && socket.connected) {
      // Ważne: wysyłamy stopTimer z aktualnym pozostałym czasem
      socket.emit('stopTimer', { finalTimeLeft: timeLeftWhenStopped });
      console.log(`[CompetitionScreen] Emitted stopTimer with finalTimeLeft: ${timeLeftWhenStopped}`);
    }
  };

  // UI Handlers (handleSelectCategory, handleSelectWeight)
  const handleSelectCategory = useCallback(async (category) => {
    setActiveGroup(category, null); // Resetuj wagę przy zmianie kategorii
    await syncData({ activeCategory: category, activeWeight: null }); // Synchronizuj ze zresetowaną wagą
  }, [setActiveGroup, syncData]);

  const handleSelectWeight = useCallback(async (weight) => {
    setActiveGroup(activeCategory, weight);
    await syncData({ activeCategory: activeCategory, activeWeight: weight }); // Synchronizuj z wybraną wagą
  }, [activeCategory, setActiveGroup, syncData]);

  // handleSelectAthlete jest teraz mniej potrzebne, bo system sam wybiera następnego.
  // Można je zostawić do ręcznego wyboru, ale trzeba by dostosować logikę rund.
  // Na razie upraszczamy i polegamy na automatycznym wyborze.
  // const handleSelectAthlete = (athleteOriginalIndex) => {
  //   setActiveAthlete(athleteOriginalIndex);
  // };
  

  // Memoized values for rendering
  const categoryOptions = useMemo(() => kategorie.map(k => ({ label: k.nazwa, value: k.nazwa })), [kategorie]);
  const activeCategoryObject = useMemo(() => kategorie.find(k => k.nazwa === activeCategory), [kategorie, activeCategory]);
  const completedWeights = useMemo(() => {
      const completed = new Set();
      if (!activeCategoryObject || !zawodnicy) return completed;
      activeCategoryObject.wagi.forEach(waga => {
          const athletesInGroup = zawodnicy.filter(z => z.kategoria === activeCategory && z.waga === waga);
          if (athletesInGroup.length > 0 && athletesInGroup.every(hasAthleteCompleted)) completed.add(waga);
      });
      return completed;
  }, [activeCategoryObject, zawodnicy, activeCategory]);
  const weightOptions = useMemo(() => {
    if (!activeCategoryObject) return [];
    return [...activeCategoryObject.wagi].sort((a, b) => Number(a) - Number(b)).map(w => ({
        label: String(w), value: w, isCompleted: completedWeights.has(w)
    }));
  }, [activeCategoryObject, completedWeights]);

  // DODAJ LUB PRZYWRÓĆ TĘ DEFINICJĘ:
  const displayAthletesInGroup = useMemo(() => {
    if (!athletesInCurrentGroup) return []; // Dodatkowe zabezpieczenie
    return [...athletesInCurrentGroup].sort((a, b) => { // Użyj kopii tablicy do sortowania
        const weightA = getAthleteDeclaredWeightForRound(a, currentRound);
        const weightB = getAthleteDeclaredWeightForRound(b, currentRound);
        if (weightA === weightB) {
          // Dodatkowe kryterium sortowania, np. po numerze startowym lub nazwisku, jeśli ciężary są równe
          // Na razie proste sortowanie po originalIndex dla stabilności
          return a.originalIndex - b.originalIndex;
        }
        return weightA - weightB;
    });
  }, [athletesInCurrentGroup, currentRound]);


  // Ta sekcja filteredAthletes i currentAthleteFilteredIndex jest OK (choć filteredAthletes może być teraz mniej potrzebne, jeśli displayAthletesInGroup spełnia swoją rolę)
  const filteredAthletes = useMemo(() => {
      if (!activeCategory || !activeWeight) return [];
      return zawodnicy
        .map((z, index) => ({ ...z, originalIndex: index, isCompleted: hasAthleteCompleted(z) })) // Zakładam, że hasAthleteCompleted istnieje i działa poprawnie
        .filter(z => z.kategoria === activeCategory && z.waga === activeWeight)
        .sort((a, b) => (Number(a.podejscie1) || 0) - (Number(b.podejscie1) || 0)); // Sortowanie dla filteredAthletes
  }, [zawodnicy, activeCategory, activeWeight]);

  const currentAthleteFilteredIndex = useMemo(() => {
      if (activeAthleteOriginalIndex === null) return null;
      return filteredAthletes.findIndex(z => z.originalIndex === activeAthleteOriginalIndex);
  }, [filteredAthletes, activeAthleteOriginalIndex]);

  // Determine which timer control button to show
  let TimerButtonComponent;
  if (timerActive) {
    TimerButtonComponent = (
      <TouchableOpacity
        style={[styles.mainActionButton, styles.stopButton, (!timerActive || isSaving) && styles.actionButtonDisabled]}
        onPress={handleStopAttempt}
        disabled={!timerActive || isSaving}
      >
        {isSaving ? <ActivityIndicator size="small" color={colors.textLight} /> : <Text style={styles.mainActionButtonText}>Zatrzymaj Czas</Text>}
      </TouchableOpacity>
    );
  } else { // Timer is not active
    if (timerTimeLeft > 0 && timerTimeLeft < MAX_TIMER_SECONDS) { // Paused state
      TimerButtonComponent = (
        <TouchableOpacity
          style={[styles.mainActionButton, styles.startButton, (!currentAthlete || isSaving) && styles.actionButtonDisabled]}
          onPress={handleResumeAttempt}
          disabled={!currentAthlete || isSaving}
        >
          {isSaving ? <ActivityIndicator size="small" color={colors.textLight} /> : <Text style={styles.mainActionButtonText}>Wznów Czas</Text>}
        </TouchableOpacity>
      );
    } else { // Ready to start or restart (timeLeft is 0 or MAX_TIMER_SECONDS)
      TimerButtonComponent = (
        <TouchableOpacity
          style={[styles.mainActionButton, styles.startButton, (!currentAthlete || isSaving) && styles.actionButtonDisabled]}
          onPress={handleStartOrRestartAttempt}
          disabled={!currentAthlete || isSaving}
        >
          {isSaving ? <ActivityIndicator size="small" color={colors.textLight} /> : <Text style={styles.mainActionButtonText}>Rozpocznij Czas</Text>}
        </TouchableOpacity>
      );
    }
  }


  return (
    <LinearGradient colors={[colors.gradient.start, colors.gradient.end]} style={styles.container}>
      <View style={styles.headerBackground}>
        <View style={styles.headerBar}>
          <View style={styles.headerSideContainer}>
            {zawody.klubAvatar && headerKlubAvatarDimensions ? (
              <Image
                source={{ uri: zawody.klubAvatar }}
                style={[styles.headerClubLogo, { width: headerKlubAvatarDimensions.width, height: headerKlubAvatarDimensions.height }]}
                resizeMode="contain"
              />
            ) : (
              <View style={[styles.headerClubLogo, { width: 40, height: 40, backgroundColor: colors.surface + '30' }]} /> // Placeholder
            )}
            <View style={styles.headerLocationDate}>
              <Text style={styles.headerLocationText} numberOfLines={1} ellipsizeMode="tail">{zawody.miejsce || 'Brak miejsca'}</Text>
              <Text style={styles.headerDateText}>{zawody.data || 'Brak daty'}</Text>
            </View>
          </View>
          <Text style={styles.headerLogo} numberOfLines={1} ellipsizeMode="tail">{zawody.nazwa || 'Nazwa Zawodów'}</Text>
          <View style={[styles.headerSideContainer, styles.headerRightAlign]}>
            <View style={styles.headerJudgeInfo}>
              <Text style={styles.headerJudgeName} numberOfLines={1} ellipsizeMode="tail">
                {zawody.sedzia?.imie || 'Sędzia'} {zawody.sedzia?.nazwisko || ''}
              </Text>
            </View>
            {zawody.sedzia?.avatar && headerJudgeAvatarDimensions ? (
              <Image
                source={{ uri: zawody.sedzia.avatar }}
                style={[styles.headerJudgeAvatar, { width: headerJudgeAvatarDimensions.width, height: headerJudgeAvatarDimensions.height }]}
                resizeMode="contain"
              />
            ) : (
              <View style={[styles.headerJudgeAvatar, { width: 40, height: 40, backgroundColor: colors.surface + '30' }]} /> // Placeholder
            )}
          </View>
        </View>
        <NavBar navigation={navigation} />
      </View>

      <ScrollView style={styles.contentContainer} contentContainerStyle={{ flexGrow: 1 }}>
        <View style={styles.mainContent}>
          <Text style={styles.mainTitle}>Zarządzaj przebiegiem zawodów (Runda {currentRound})</Text>
          <View style={styles.columnsContainer}>
            <View style={styles.leftColumn}>
              <View style={styles.card}>
                <Text style={styles.columnTitle}>Wybór grupy</Text>
                <OptionSelector 
                  label="Kategoria" 
                  options={categoryOptions} 
                  selectedValue={activeCategory} 
                  onSelect={handleSelectCategory}
                  placeholder="Wybierz kategorię" 
                />
                <OptionSelector 
                  label="Waga" 
                  options={weightOptions} 
                  selectedValue={activeWeight} 
                  onSelect={handleSelectWeight}
                  placeholder="Wybierz wagę" 
                />
                {activeCategory && activeWeight && (
                  <Text style={styles.infoText}>
                    Zawodnicy w grupie: {athletesInCurrentGroup.length}.
                    Oczekujący w rundzie {currentRound}: {upcomingAthletesForCurrentRound.length}
                  </Text>
                )}
              </View>
              <View style={styles.card}>
                <Text style={styles.columnTitle}>Lista Zawodników (Grupa: {activeCategory} / {activeWeight} kg) - Runda {currentRound}</Text>
                {isSaving && <ActivityIndicator size="small" color={colors.primary} />}
                <AthleteList
                  athletes={displayAthletesInGroup}
                  currentAthleteOriginalIndex={activeAthleteOriginalIndex}
                  currentRound={currentRound}
                  onSelectAthlete={handleSelectAthlete} // <-- UNCOMMENT AND USE THIS
                />
              </View>
            </View>
            <View style={styles.rightColumn}>
              <View style={styles.card}>
                <Text style={styles.columnTitle}>Podejścia zawodnika</Text>
                <CurrentAthleteManager
                  athlete={currentAthlete}
                  athleteOriginalIndex={activeAthleteOriginalIndex}
                  currentAttemptNr={activeAttemptNr}
                  onAttemptStatusChange={handleAttemptStatusChange}
                  onWeightChange={handleWeightChange}
                  isSaving={isSaving}
                  currentRoundForDisplay={currentRound}
                />
              </View>
               <View style={styles.card}>
                <Text style={styles.columnTitle}>Zarządzanie</Text>
                <TimerDisplay isActive={timerActive} timeLeft={timerTimeLeft} />
                <View style={styles.currentStatusInfo}>
                  <Text style={styles.currentStatusLabel}>Aktualnie na podeście:</Text>
                  {currentAthlete ? (
                    <Text style={styles.currentStatusText}>
                      {currentAthlete.imie} {currentAthlete.nazwisko} ({currentAthlete.klub || 'brak klubu'})
                      {'\n'}Podejście #{activeAttemptNr} ({currentAthlete[`podejscie${activeAttemptNr}`] || 'N/A'} kg)
                    </Text>
                  ) : (
                    <Text style={styles.currentStatusText}>Brak aktywnego zawodnika</Text>
                  )}
                </View>
                <View style={styles.mainActionButtons}>
                  {TimerButtonComponent}
                  <NextCompetitorButton 
                    onPress={advanceToNextCompetitorOrRound} 
                    disabled={isSaving || timerActive}
                  />
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
      <Footer />
    </LinearGradient>
  );
}
