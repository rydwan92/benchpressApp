import React from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { Text } from 'react-native-paper';
import AthleteInfo from '../components/AthleteInfo';
import AttemptTimer from '../components/AttemptTimer';
import AttemptAnimation from '../components/AttemptAnimation';
import CategoryWeightTable from '../components/CategoryWeightTable';

export default function DisplayScreen() {
  // Przykładowe dane (docelowo pobierane ze store lub props)
  const athlete = {
    firstName: 'Jan',
    lastName: 'Kowalski',
    club: 'Herkules',
    attempts: [
      { number: 1, weight: 125, passed: true },
      { number: 2, weight: null, passed: null },
      { number: 3, weight: null, passed: null }
    ]
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Nazwa Zawodów</Text>
      <AthleteInfo athlete={athlete} />
      <AttemptTimer initialSeconds={30} />
      <AttemptAnimation />
      <CategoryWeightTable />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#fff' },
  title: { fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginVertical: 16 }
});