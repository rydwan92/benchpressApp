import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import CompetitionInfoForm from '../components/registration/CompetitionInfoForm';
import CategoryWeightManager from '../components/registration/CategoryWeightManager';
import AthleteRegistrationForm from '../components/registration/AthleteRegistrationForm';
import CategoryBrowser from '../components/registration/CategoryBrowser';
import CompetitionSummary from '../components/registration/CompetitionSummary';
import NavBar from '../components/navigation/NavBar';
import Footer from '../components/navigation/Footer';
import { commonStyles } from '../styles/common';
import { colors, font, spacing, borderRadius, shadows } from '../theme/theme';
import { useCompetitionStore } from '../store/useCompetitionStore';
import { LinearGradient } from 'expo-linear-gradient';

export default function RegistrationScreen() {
  const navigation = useNavigation();
  const zawody = useCompetitionStore(state => state.zawody);
  const { width } = useWindowDimensions();

  // Stan dynamicznego widoku – na potrzeby przykładu domyślnie ustawiony "registration"
  const [activeView, setActiveView] = useState('registration');

  // Funkcja renderująca zawartość opakowaną w kontener - można później rozbudować o więcej widoków
  const renderDynamicContent = () => {
    switch (activeView) {
      case 'registration':
        return (
          <>
            {/* Kontener z informacjami o zawodach */}
            <View style={styles.fullWidthBox}>
              <CompetitionInfoForm />
            </View>
            {/* Tytuł rejestracji */}
            <Text style={styles.title}>Rejestracja zawodnika</Text>
            {/* Główna sekcja – dwie kolumny */}
            <View style={styles.mainRow}>
              {/* Lewa kolumna */}
              <View style={styles.displayColumn}>
                <View style={commonStyles.card}>
                  <CompetitionSummary />
                </View>
                <View style={commonStyles.card}>
                  <CategoryBrowser />
                </View>
              </View>
              {/* Prawa kolumna */}
              <View style={styles.inputColumn}>
                <View style={commonStyles.card}>
                  <CategoryWeightManager />
                </View>
                <View style={commonStyles.card}>
                  <Text style={styles.sectionTitle}>Zarejestruj zawodnika</Text>
                  <AthleteRegistrationForm />
                </View>
              </View>
            </View>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <LinearGradient
        colors={[colors.gradient.start, colors.gradient.end]}
        style={styles.headerBackground}
      >
        <View style={styles.headerBar}>
          <Text style={styles.headerLogo}>{zawody.nazwa || 'Benchpress Cup 2025'}</Text>
        </View>
        <NavBar navigation={navigation} />
      </LinearGradient>
      
      <View style={styles.mainContent}>
        <View style={styles.dynamicContainer}>
          {renderDynamicContent()}
        </View>
        <Footer />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  contentContainer: {
    flexGrow: 1,
  },
  headerBackground: {
    paddingTop: spacing.xl,
    paddingBottom: spacing.lg,
    ...shadows.medium,
  },
  headerBar: {
    width: '100%',
    alignItems: 'center',
    paddingVertical: spacing.md,
  },
  headerLogo: {
    fontSize: font.sizes['3xl'],
    fontWeight: font.weights.bold,
    color: colors.textLight,
    fontFamily: font.family,
    letterSpacing: 1,
  },
  mainContent: {
    flex: 1,
    backgroundColor: colors.background,
    borderTopLeftRadius: borderRadius['2xl'],
    borderTopRightRadius: borderRadius['2xl'],
    marginTop: -borderRadius.xl,
    paddingHorizontal: '5%',
    paddingTop: spacing.xl,
  },
  dynamicContainer: {
    width: '100%',
    marginBottom: spacing.xl,
  },
  fullWidthBox: {
    width: '100%',
    marginBottom: spacing.xl,
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    ...shadows.small,
  },
  title: {
    fontSize: font.sizes['3xl'],
    fontWeight: font.weights.bold,
    color: colors.text,
    fontFamily: font.family,
    marginBottom: spacing.xl,
    textAlign: 'center',
  },
  mainRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    width: '100%',
    gap: spacing.xl,
  },
  displayColumn: {
    flex: 1,
    gap: spacing.lg,
  },
  inputColumn: {
    flex: 1,
    gap: spacing.lg,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    ...shadows.small,
  },
  sectionTitle: {
    fontSize: font.sizes.xl,
    fontWeight: font.weights.semibold,
    color: colors.text,
    fontFamily: font.family,
    marginBottom: spacing.md,
    textAlign: 'center',
  },
  // Style dla przycisków
  button: {
    backgroundColor: colors.button.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadows.small,
  },
  buttonAccent: {
    backgroundColor: colors.button.accent,
  },
  buttonText: {
    color: colors.textLight,
    fontSize: font.sizes.base,
    fontWeight: font.weights.semibold,
  },
});