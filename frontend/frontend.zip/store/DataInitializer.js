import React, { useEffect } from 'react';
import { useCompetitionStore } from './useCompetitionStore';
import { loadAppData } from '../utils/api';

export default function DataInitializer({ children }) {
  const setInitialData = useCompetitionStore(state => state.setInitialData);

  useEffect(() => {
    async function fetchData() {
      const data = await loadAppData();
      if (data) {
        setInitialData(data);
      }
    }
    // Pobierz dane raz przy starcie
    fetchData();
    // Uruchom polling co 2000 ms = 2 sekundy
    const interval = setInterval(fetchData, 2000);
    return () => clearInterval(interval);
  }, []);

  return children;
}