// store/useAthleteStore.js
/*
import {create} from 'zustand';
import * as FileSystem from 'expo-file-system';

const DATA_FILE = FileSystem.documentDirectory + 'athletes.json';

export const useAthleteStore = create((set, get) => ({
  athletes: [],
  activeAthleteId: null,

  addAthlete: (athlete) => {
    const updated = [...get().athletes, athlete];
    set({ athletes: updated });
    saveToJson(updated);
  },

  updateAttempt: (athleteId, attemptNumber, passed) => {
    const updated = get().athletes.map((athlete) => {
      if (athlete.id !== athleteId) return athlete;
      const updatedAttempts = athlete.attempts.map((a) =>
        a.number === attemptNumber ? { ...a, passed } : a
      );
      return { ...athlete, attempts: updatedAttempts };
    });
    set({ athletes: updated });
    saveToJson(updated);
  },

  setActiveAthlete: (id) => set({ activeAthleteId: id }),

  loadAthletes: async () => {
    try {
      const content = await FileSystem.readAsStringAsync(DATA_FILE);
      set({ athletes: JSON.parse(content) });
    } catch {
      set({ athletes: [] });
    }
  }
}));

async function saveToJson(data) {
  await FileSystem.writeAsStringAsync(DATA_FILE, JSON.stringify(data));
}
*/