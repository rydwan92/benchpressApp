import { create } from 'zustand';

export const useCompetitionStore = create(set => ({
  zawody: {
    miejsce: '',
    data: new Date().toISOString().slice(0, 10),
    sedzia: {
      imie: '',
      nazwisko: '',
      avatar: null,
    },
    klubAvatar: null,
  },
  kategorie: [],
  zawodnicy: [],
  // --- Akcje ---
  setZawody: (zawody) => set(state => ({ zawody: { ...state.zawody, ...zawody } })),
  setSedzia: (sedzia) => set(state => ({ zawody: { ...state.zawody, sedzia: { ...state.zawody.sedzia, ...sedzia } } })),
  setKlubAvatar: (avatar) => set(state => ({ zawody: { ...state.zawody, klubAvatar: avatar } })),
  addKategoria: (nazwa) => set(state => ({
    kategorie: [...state.kategorie, { nazwa, wagi: [] }]
  })),
  addWaga: (kategoriaNazwa, waga) => set(state => ({
    kategorie: state.kategorie.map(k =>
      k.nazwa === kategoriaNazwa ? { ...k, wagi: [...k.wagi, waga] } : k
    )
  })),
  addZawodnik: (zawodnik) => set(state => ({
    zawodnicy: [
      ...state.zawodnicy,
      {
        ...zawodnik,
        podejscie1: zawodnik.podejscie1 || '',
        podejscie2: zawodnik.podejscie2 || '',
        podejscie3: zawodnik.podejscie3 || '',
      }
    ]
  })),
  removeZawodnik: (index) => set(state => ({
    zawodnicy: state.zawodnicy.filter((_, i) => i !== index)
  })),
  updatePodejscie: (idx, nr, value) => set(state => ({
    zawodnicy: state.zawodnicy.map((z, i) =>
      i === idx ? { ...z, [`podejscie${nr}`]: value } : z
    )
  })),
  removeKategoria: (nazwa) => set(state => ({
    kategorie: state.kategorie.filter(k => k.nazwa !== nazwa)
  })),
  removeWaga: (kategoriaNazwa, waga) => set(state => ({
    kategorie: state.kategorie.map(k =>
      k.nazwa === kategoriaNazwa
        ? { ...k, wagi: k.wagi.filter(w => w !== waga) }
        : k
    )
  })),
  // ...dodaj kolejne akcje wg potrzeb...
    // Dodana akcja setInitialData:
    setInitialData: (data) => set({
      zawody: data.zawody || {},
      kategorie: data.kategorie || [],
      zawodnicy: data.zawodnicy || [],
    }),
}));

// UWAGA: Usuń wszelkie JSX (np. <View>...</View>) z tego pliku!
// Store Zustand nie może zawierać kodu JSX ani komponentów React.