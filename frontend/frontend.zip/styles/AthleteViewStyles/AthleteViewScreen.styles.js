import { StyleSheet, Dimensions } from 'react-native';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme'; 

const { width, height } = Dimensions.get('window');

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.backgroundDark, // Dark background for projector
    },
    groupHeader: { // For when showing group list, not single athlete
        backgroundColor: colors.secondary, // Darker blue
        paddingVertical: spacing.lg,
        paddingHorizontal: spacing.xl,
        ...shadows.large,
        marginBottom: spacing.lg, // Only if mainContent doesn't overlap
    },
    groupHeaderTitle: {
        fontSize: font.sizes['5xl'],
        fontWeight: font.weights.extrabold,
        color: colors.textMainTitle,
        textAlign: 'center',
        fontFamily: font.familyDisplay || font.family,
        letterSpacing: 1,
        textShadowColor: 'rgba(0, 0, 0, 0.3)',
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 2,
        marginBottom: spacing.sm,
    },
    groupHeaderSubtitle: {
        fontSize: font.sizes['3xl'],
        fontWeight: font.weights.bold,
        color: colors.acc + 'f0',
        textAlign: 'center',
        marginTop: spacing.xs,
        backgroundColor: colors.accent,
        paddingVertical: spacing.sm,
        paddingHorizontal: spacing.lg,
        borderRadius: borderRadius.md,
        alignSelf: 'center',
        minWidth: '60%',
        maxWidth: '90%',
        borderWidth: 1,
        borderColor: colors.textMainTitle + '50',
    },
    mainContent: { // This will contain either athlete details or group list
        flex: 1,
        paddingHorizontal: spacing.lg, // Consistent padding
        paddingTop: spacing.lg,
        paddingBottom: spacing.md, // Space for footer or next up bar
    },
    // Styles for Single Athlete View
    athleteDetailContainer: { // New container for single athlete view
        flex: 1,
        width: '100%',
        alignItems: 'center',
    },
    athleteInfoCard: {
        backgroundColor: colors.surface,
        borderRadius: borderRadius.lg,
        padding: spacing.lg,
        marginBottom: spacing.lg,
        ...shadows.medium,
        alignItems: 'center',
    },
    athleteName: {
        fontSize: font.sizes['3xl'], // np. 30
        fontWeight: font.weights.bold,
        color: colors.text, // Domyślny kolor, zostanie nadpisany w komponencie
        textAlign: 'center',
        marginBottom: spacing.xs,
    },
    athleteNameHighlight: { // Nowy styl dla imienia i nazwiska
        color: colors.gradient.start, // Kolor z gradientu RegistrationScreen
    },
    athleteClub: {
        fontSize: font.sizes.md, // np. 16
        color: colors.textSecondary,
        textAlign: 'center',
        marginBottom: spacing.sm,
    },
    athleteCategory: {
        fontSize: font.sizes.md, // np. 16
        color: colors.textSecondary, // Domyślny kolor dla etykiet "Kat:", "Waga:"
        textAlign: 'center',
    },
    categoryValueHighlight: { // Nowy styl dla wartości kategorii
        color: colors.primary,
        fontWeight: font.weights.semibold,
    },
    weightValueHighlight: { // Nowy styl dla wartości wagi
        color: colors.primary,
        fontWeight: font.weights.semibold,
    },
    sectionTitle: {
        fontSize: font.sizes['3xl'],
        fontWeight: font.weights.bold,
        color: colors.textLight + 'ee', // Bright text for section titles
        marginBottom: spacing.md, // Reduced margin for tighter layout
        textAlign: 'center',
        width: '100%',
        marginTop: spacing.sm, // Add some top margin
    },
    attemptsContainer: {
        width: '100%', // Full width for attempts section
        maxWidth: 700, // Max width for attempts for readability
        marginBottom: spacing.lg,
        alignItems: 'center',
    },
    timerSection: {
        width: '100%',
        alignItems: 'center',
        marginBottom: spacing.lg, // Space before "Next Up" or footer
        marginTop: spacing.md,
    },
    // Styles for "Next Up" athlete
    nextUpContainer: {
        backgroundColor: colors.surface + '10', // Very subtle background
        paddingVertical: spacing.md,
        paddingHorizontal: spacing.lg,
        borderRadius: borderRadius.lg,
        borderTopWidth: 1,
        borderTopColor: colors.primary + '40',
        width: '100%',
        maxWidth: 600, // Max width for this info bar
        alignSelf: 'center', // Center it if mainContent alignItems is 'center'
        marginTop: 'auto', // Push to bottom if athleteDetailContainer is flex:1
        marginBottom: spacing.sm,
    },
    nextUpTitle: {
        fontSize: font.sizes.lg,
        fontWeight: font.weights.semibold,
        color: colors.textLight + 'aa',
        textAlign: 'center',
        marginBottom: spacing.xs,
        textTransform: 'uppercase',
    },
    nextUpAthleteName: {
        fontSize: font.sizes['2xl'],
        fontWeight: font.weights.bold,
        color: colors.textLight,
        textAlign: 'center',
    },
    nextUpAthleteInfo: {
        fontSize: font.sizes.md,
        color: colors.textLight + 'cc',
        textAlign: 'center',
    },
    // Placeholder for group list or initial view
    placeholderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: spacing.xl,
    },
    placeholderText: {
        fontSize: font.sizes['3xl'],
        color: colors.textSecondaryOnDark || colors.textLight + 'aa', // Adjusted for dark bg
        fontStyle: 'italic',
        textAlign: 'center',
        lineHeight: font.sizes['3xl'] * 1.4,
    },
    // Group View Container (when no single athlete is selected)
    groupViewContainer: {
        width: '100%',
        flex: 1,
    },
    // Animation Overlay
    animationOverlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.85)', // Darker overlay
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000,
    },
});