import { StyleSheet } from 'react-native';
import { commonStyles } from './common';
import { colors, font } from '../theme/theme';

const additionalStyles = StyleSheet.create({
  container: {
    padding: 16,
  },
  kategorieBox: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    marginBottom: 16,
  },
  kategoriaTile: {
    backgroundColor: '#e3f3fa',
    borderRadius: 16,
    padding: 20,
    minWidth: 180,
    marginRight: 12,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 3,
  },
  kategoriaHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  kategoriaTitle: {
    fontWeight: 'bold',
    fontSize: 17,
    color: colors.primary,
  },
  kategoriaDelete: {
    color: '#e74c3c',
    marginLeft: 10,
    fontWeight: 'bold',
  },
  wagiRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 6,
  },
  wagaTile: {
    backgroundColor: '#f7fafd',
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 18,
    marginRight: 6,
    marginBottom: 6,
    flexDirection: 'row',
    alignItems: 'center',
  },
  wagaText: {
    color: colors.text,
    fontWeight: 'bold',
  },
  wagaDelete: {
    color: '#e74c3c',
    marginLeft: 8,
    fontWeight: 'bold',
  },
  // ---------- Modal styles added ----------
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    minWidth: 320,
    maxWidth: 400,
    // Ustawienie alignItems na 'stretch' umożliwi lepsze rozmieszczenie elementów
    alignItems: 'stretch',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  modalTitle: {
    fontSize: font.sizeHeader,
    fontWeight: 'bold',
    marginBottom: 16,
    color: colors.primary,
    textAlign: 'center',
  },
  // Nowe style dla pola wyboru kategorii w modalu dodawania wagi
  selectBox: {
    marginBottom: 12,
  },
  select: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 10,
    backgroundColor: '#f4f4f4',
  },
  selectList: {
    marginTop: 8,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 8,
  },
  modalBtns: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    width: '100%',
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
    backgroundColor: '#fff',
    fontSize: font.sizeNormal,
    color: colors.text,
  },
  btnCancel: {
    backgroundColor: '#aaa',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 18,
  },
});

export const styles = { ...commonStyles, ...additionalStyles };