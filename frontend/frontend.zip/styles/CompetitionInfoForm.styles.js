import { StyleSheet } from 'react-native';
import { colors, font } from '../theme/theme';

export default StyleSheet.create({
  infoCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    marginVertical: 16,
  },
  // Główna rządka opakowująca dwie nowe kolumny
  infoRow: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  // Kolumna lewa – przyklejona do lewej, szerokość 48%
  infoColLeft: {
    width: '25%',
    alignItems: 'center',
    
  },
  spacer: {
    width: '50%', // Spacja między kolumnami – możesz zwiększyć/zmniejszyć wg potrzeb
  },
  // Kolumna prawa – przyklejona do prawej, szerokość 48%
  infoColRight: {
    width: '25%',
    alignItems: 'center',
    
  },
  // Dotychczasowy styl dla pozostałych kolumn (np. avatar’y)
  infoCol: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 8,
  },
  // Nowy styl dla pól wejściowych w nowej układance
  inputHalf: {
    width: '100%',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 5,        // Zmniejszone z oryginalnych 10
    marginBottom: 8,
    backgroundColor: '#fff',
    // Możesz zmniejszyć fontSize – przykładowo na 80% oryginalnego
    fontSize: font.sizeNormal * 0.8,
    color: colors.text,
  },
  // Pozostałe style pozostają bez zmian
  avatarBox: {
    width: 96, // było 64
    height: 96, // było 64
    borderRadius: 48, // połowa width/height
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    overflow: 'hidden', // WAŻNE: przycina obrazek do okręgu
  },
  avatarImg: {
    width: 96, // było 64
    height: 96, // było 64
    borderRadius: 48, // połowa width/height
    resizeMode: 'contain', // dopasowanie i przycięcie
  },
  avatarPlaceholder: {
    color: colors.primary,
    fontWeight: 'bold',
  },
  saveRow: {
    flexDirection: 'row',
    alignItems: 'center', // wyrównanie w pionie
    justifyContent: 'center',
    marginTop: 12,
  },
  fullInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 10,
    marginRight: 12,
    backgroundColor: '#fff',
    fontSize: font.sizeNormal,
    color: colors.text,
  },
    fullTable: {
    flex: 1,
    width: '100%',
    minWidth: '100%',
    alignSelf: 'stretch',
  },
  notif: {
    marginTop: 16,
    padding: 12,
    borderRadius: 8,
  },
  notifSuccess: {
    backgroundColor: '#d4f8e8',
  },
  notifError: {
    backgroundColor: '#ffd6d6',
  },
  notifText: {
    color: colors.text,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  /* Style dla widoku zapisanego formularza */
  infoDisplay: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  infoSides: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 12,
    marginBottom: 16,
  },
  infoSideLeft: {
    flex: 1,
    alignItems: 'flex-start',
  },
  infoSideRight: {
    flex: 1,
    alignItems: 'flex-end',
  },
  infoLabel: {
    fontSize: font.sizeNormal,
    fontWeight: 'bold',
    marginBottom: 4,
    color: colors.text,
  },
  infoText: {
    fontSize: font.sizeNormal,
    color: colors.text,
  },
  editButton: {
    marginTop: 16,
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: colors.primary,
    borderRadius: 20,
  },
  editButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: font.sizeNormal,
  },
});