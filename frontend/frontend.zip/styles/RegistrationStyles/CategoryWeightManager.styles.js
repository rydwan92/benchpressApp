import { StyleSheet, Dimensions, Platform } from 'react-native';
import { colors, font, spacing, borderRadius, shadows, componentStyles } from '../../theme/theme';

const containerPadding = spacing.md;
const gapSize = spacing.md;

// Usunięto obliczenia szerokości kafelka oparte na screenWidth

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.surface,
    padding: containerPadding,
    borderRadius: borderRadius.lg, // Dodane zaokrąglenie krawędzi
    overflow: 'hidden', // Dodane, aby przyciąć zawartość do zaokrąglonych krawędzi
  },
  scrollContainer: {
    flex: 1,
  },
  componentTitle: {
    fontSize: font.sizes.xl,
    fontWeight: font.weights.bold,
    color: colors.text,
    marginTop: spacing.lg, 
    marginBottom: spacing.lg, 
    textAlign: 'center',
  },
  actionRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: spacing.lg,
    paddingHorizontal: spacing.md,
  },
  actionBtn: {
    backgroundColor: colors.accent,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    marginHorizontal: spacing.sm,
    transition: 'transform 0.2s ease-in-out, background-color 0.2s ease-in-out', 
    ...shadows.small, 
  },
  actionBtnHover: { 
    transform: [{ scale: 1.05 }], 
    ...shadows.medium,
  },
  actionBtnText: {
    ...componentStyles.button.text,
    color: colors.textLight,
  },
  btnIcon: {
    marginRight: spacing.xs,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
    opacity: 0.7,
  },
  emptyText: {
    color: colors.textSecondary,
    marginTop: spacing.sm,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  kategorieBox: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: gapSize, 
    justifyContent: 'center',
    width: '100%', // Aby kategorieBox zajął dostępną szerokość w ScrollView
  },
  kategoriaTile: {
    backgroundColor: colors.card,
    borderRadius: borderRadius.lg,
    padding: spacing.md,
    ...shadows.small,
    marginBottom: spacing.md,
    // Szerokość kafelka będzie ustawiana dynamicznie przez komponent
  },
  kategoriaTileHover: { 
    ...shadows.medium, 
  },
  kategoriaHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  kategoriaTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flexShrink: 1,
    marginRight: spacing.sm,
  },
  kategoriaTitle: {
    fontSize: font.sizes.lg,
    fontWeight: font.weights.bold,
    color: colors.primary,
    marginRight: spacing.xs, 
    flexShrink: 1,
  },
  wagiCounter: {
    backgroundColor: colors.primary, // ZMIANA: Tło na primary (niebieski)
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    minWidth: 36,
    height: 28,
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    borderWidth: 1,
    borderColor: colors.primary, // ZMIANA: Ramka również na primary
    marginLeft: spacing.xs,
  },
  wagiCounterIcon: { 
    marginRight: spacing.xs,
    fontSize: font.sizes.sm, 
    color: colors.textLight, 
  },
  wagiCounterText: {
    color: colors.textLight,
    fontSize: font.sizes.sm,
    fontWeight: font.weights.bold,
  },
  wagaDeleteBtn: {
    padding: spacing.xs,
    transition: 'transform 0.1s ease-in-out', 
  },
  deleteBtnHover: { 
    transform: [{ scale: 1.2 }], 
  },
  wagiContainer: {
  },
  wagiRow: {
    flexDirection: 'row',
    flexWrap: 'wrap', 
    gap: spacing.sm, 
    marginTop: spacing.sm, 
  },
  wagaTile: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md, 
    ...shadows.xs,
    borderWidth: 1, 
    borderColor: colors.border, 
  },
  wagaText: {
    fontSize: font.sizes.sm,
    color: colors.info, 
    marginRight: spacing.xs,
    fontWeight: font.weights.bold,
  },
  wagiEmpty: {
    fontSize: font.sizes.sm,
    color: colors.textSecondary,
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: spacing.sm,
  },
  deletingKategoria: { 
    opacity: 0.5,
  },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.md,
  },
  modalCard: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    width: '100%',
    maxWidth: 450, 
    ...shadows.large,
    alignItems: 'center', 
  },
  confirmModalCard: {
  },
  modalIconHeader: {
    marginBottom: spacing.md,
  },
  modalTitle: {
    fontSize: font.sizes.xl,
    fontWeight: font.weights.bold,
    color: colors.text,
    textAlign: 'center',
    marginBottom: spacing.md,
  },
  confirmTitle: {
    marginBottom: spacing.lg, 
  },
  confirmSubtitle: {
    fontSize: font.sizes.sm,
    fontWeight: font.weights.normal,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.xs,
  },
  modalBtns: {
    flexDirection: 'row',
    justifyContent: 'space-around', 
    marginTop: spacing.lg,
    width: '100%', 
  },
  modalBtn: {
    ...componentStyles.button.base, 
    flex: 1, 
    marginHorizontal: spacing.sm, 
    maxWidth: 180, 
  },
  cancelBtn: {
    backgroundColor: colors.textSecondary, 
  },
  confirmBtn: {
    backgroundColor: colors.accent, 
  },
  deleteBtn: {
    backgroundColor: colors.error, 
  },
  input: { 
     ...componentStyles.input,
     width: '100%', 
  },
  selectBox: {
    width: '100%',
    marginBottom: spacing.md,
  },
  selectLabel: {
    fontSize: font.sizes.sm,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  selectItemsContainer: { 
    flexDirection: 'row',   
    flexWrap: 'wrap',       
    gap: spacing.sm,        
    maxHeight: 150, 
    overflow: 'hidden', 
  },
  selectItem: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.full, 
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.background,
  },
  selectItemActive: {
    backgroundColor: colors.accent, 
    borderColor: colors.accent,   
  },
  selectItemText: {
    color: colors.text,
    fontSize: font.sizes.sm,
  },
  selectItemTextActive: {
    color: colors.textLight, 
    fontWeight: font.weights.medium,
  },
  errorText: {
    color: colors.error,
    fontSize: font.sizes.sm,
    textAlign: 'center',
  },
  notification: {
    position: 'absolute',
    bottom: Platform.OS === 'web' ? spacing.lg : 80, 
    left: spacing.md,
    right: spacing.md,
    ...componentStyles.notification.base,
    flexDirection: 'row',
    alignItems: 'center',
    zIndex: 10,
    ...shadows.medium,
  },
  notifSuccess: {
    ...componentStyles.notification.success,
  },
  notifError: {
    ...componentStyles.notification.error,
  },
  notifIcon: {
    marginRight: spacing.sm,
  },
  notifText: {
    ...componentStyles.notification.text,
    flex: 1, 
    textAlign: 'left', 
  },
});