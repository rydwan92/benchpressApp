import { CONFIG } from '../config.js';

const BASE_URL = `${CONFIG.BACKEND_ADDRESS}/api/appdata`;

export async function loadAppData() {
  try {
    const response = await fetch(BASE_URL);
    if (!response.ok) {
      throw new Error(`Error loading data: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error in loadAppData:', error);
    return null;
  }
}

export async function saveAppData(data) {
  try {
    const response = await fetch(BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!response.ok) {
      throw new Error(`Error saving data: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error in saveAppData:', error);
    return null;
  }
}