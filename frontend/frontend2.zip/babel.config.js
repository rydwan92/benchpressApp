module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      // Inne pluginy, jeśli masz...
      'react-native-reanimated/plugin', // WAŻNE: To musi być ostatni plugin!
    ],
  };
};