import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius } from '../../theme/theme';

const AttemptDisplay = ({ number, weight, status, isActive }) => {
    const getStatusIcon = (currentStatus) => {
        if (currentStatus === 'passed') return <AntDesign name="checkcircle" size={32} color={colors.success} />;
        if (currentStatus === 'failed') return <AntDesign name="closecircle" size={32} color={colors.error} />;
        return <AntDesign name="clockcircleo" size={32} color={colors.textSecondary} />; // Oczekujące lub brak
    };

    return (
        <View style={[styles.attemptBox, isActive && styles.attemptBoxActive]}>
            <Text style={styles.attemptNumber}>Podejście {number}</Text>
            <Text style={styles.attemptWeight}>{weight ? `${weight} kg` : '-'}</Text>
            <View style={styles.attemptStatus}>
                {getStatusIcon(status)}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    attemptBox: {
        backgroundColor: colors.surfaceVariant,
        borderRadius: borderRadius.md,
        paddingVertical: spacing.md,
        paddingHorizontal: spacing.lg,
        marginBottom: spacing.md,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%',
        borderWidth: 2,
        borderColor: 'transparent',
    },
    attemptBoxActive: {
        borderColor: colors.primary,
        backgroundColor: colors.primary + '15',
    },
    attemptNumber: {
        fontSize: font.sizes.lg,
        color: colors.textSecondary,
        flex: 0.3,
    },
    attemptWeight: {
        fontSize: font.sizes['2xl'],
        fontWeight: font.weights.bold,
        color: colors.text,
        flex: 0.4,
        textAlign: 'center',
    },
    attemptStatus: {
        flex: 0.3,
        alignItems: 'flex-end',
    },
});

export default AttemptDisplay;