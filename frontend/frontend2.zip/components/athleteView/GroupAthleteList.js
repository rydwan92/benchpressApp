import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme';

const GroupAthleteList = ({ athletes, currentAthleteOriginalIndex }) => {
    const getStatusIcon = (status, weight) => {
        const iconSize = 28; // Zwiększony rozmiar ikon
        const iconStyle = styles.attemptStatusIcon;

        if ((status === 'passed' || status === 'failed') && (!weight || weight === '-')) {
            return <View style={[styles.attemptStatusIconPlaceholder, { width: iconSize, height: iconSize }]} />;
        }

        if (status === 'passed') return <AntDesign name="checkcircle" size={iconSize} color={colors.white} style={iconStyle} />;
        if (status === 'failed') return <AntDesign name="closecircle" size={iconSize} color={colors.white} style={iconStyle} />;
        if (weight && weight !== '-') return <AntDesign name="clockcircleo" size={iconSize} color={colors.textSecondary} style={iconStyle} />;
        return <View style={[styles.attemptStatusIconPlaceholder, { width: iconSize, height: iconSize }]} />;
    };

    const getAttemptCellStyle = (status) => {
        if (status === 'passed') return styles.attemptCellPassed;
        if (status === 'failed') return styles.attemptCellFailed;
        return styles.attemptCellDeclared;
    };

    const getAttemptWeightStyle = (status) => {
        if (status === 'passed' || status === 'failed') return styles.attemptWeightResultText;
        return styles.attemptWeightDeclaredText;
    };


    return (
        <ScrollView 
            style={styles.groupListScroll} 
            contentContainerStyle={styles.scrollContentContainer}
            showsVerticalScrollIndicator={false} // Ukryj pasek przewijania, jeśli lista ma się mieścić
        >
            {athletes.length === 0 && (
                <View style={styles.emptyListContainer}>
                    <Text style={styles.emptyListText}>Brak zawodników w tej grupie.</Text>
                </View>
            )}
            {athletes.map((athlete, idx) => (
                <View
                    key={athlete.originalIndex}
                    style={[
                        styles.groupListItem,
                        athlete.originalIndex === currentAthleteOriginalIndex && styles.groupListItemActive,
                    ]}
                >
                    <View style={styles.athleteRankContainer}>
                        <Text style={styles.athleteRank}>{idx + 1}.</Text>
                    </View>

                    <View style={styles.athleteInfoContainer}>
                        <Text style={styles.athleteName} numberOfLines={1}>
                            {athlete.imie} {athlete.nazwisko}
                        </Text>
                        <Text style={styles.athleteClub} numberOfLines={1}>
                            {athlete.klub || 'Brak klubu'}
                        </Text>
                    </View>

                    <View style={styles.attemptsRow}>
                        {[1, 2, 3].map(nr => {
                            const weightValue = athlete[`podejscie${nr}`];
                            const statusValue = athlete[`podejscie${nr}Status`];
                            return (
                                <View key={nr} style={[styles.attemptCellBase, getAttemptCellStyle(statusValue)]}>
                                    <Text style={[styles.attemptWeightBase, getAttemptWeightStyle(statusValue)]}>
                                        {weightValue || '-'}
                                    </Text>
                                    {getStatusIcon(statusValue, weightValue)}
                                </View>
                            );
                        })}
                    </View>
                    <View style={styles.completedIndicator}>
                        {athlete.isCompleted && (
                            <AntDesign name="checksquare" size={28} color={colors.successStrong || colors.success} />
                        )}
                    </View>
                </View>
            ))}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    groupListScroll: {
        flex: 1,
        width: '100%',
    },
    scrollContentContainer: {
        paddingBottom: spacing.md, 
    },
    emptyListContainer: {
        marginTop: spacing.xl,
        alignItems: 'center',
    },
    emptyListText: {
        fontSize: font.sizes.xl, // Większy tekst
        color: colors.textSecondary,
        fontStyle: 'italic',
    },
    groupListItem: {
        backgroundColor: colors.surface,
        borderRadius: borderRadius.md, // Mniejsze zaokrąglenie dla bardziej zwartego wyglądu
        paddingVertical: spacing.sm, // Zmniejszony padding pionowy
        paddingHorizontal: spacing.md,
        marginBottom: spacing.sm, // Zmniejszony margines dolny
        flexDirection: 'row',
        alignItems: 'center',
        ...shadows.medium,
        borderLeftWidth: 6, // Grubszy pasek akcentu
        borderLeftColor: colors.primaryLight,
    },
    groupListItemActive: {
        borderColor: colors.primary,
        backgroundColor: colors.primary + '20', // Jaśniejszy odcień dla aktywnego
        borderLeftColor: colors.primary,
    },
    athleteRankContainer: {
        width: 45, // Trochę więcej miejsca na numer
        alignItems: 'center',
        marginRight: spacing.sm,
    },
    athleteRank: {
        fontSize: font.sizes.xl, // Większy numer
        fontWeight: font.weights.bold,
        color: colors.primary,
    },
    athleteInfoContainer: {
        flex: 1,
        marginRight: spacing.sm, // Mniejszy margines, aby dać więcej miejsca podejściom
    },
    athleteName: {
        fontSize: font.sizes['2xl'], // Znacznie większe imię i nazwisko
        fontWeight: font.weights.bold,
        color: colors.text,
        marginBottom: 2, // Minimalny odstęp
    },
    athleteClub: {
        fontSize: font.sizes.lg, // Większy klub
        color: colors.textSecondary,
    },
    attemptsRow: {
        flexDirection: 'row',
        alignItems: 'stretch', // Aby komórki miały tę samą wysokość
    },
    attemptCellBase: { // Wspólne style dla komórek podejść
        width: 100, // Zwiększona szerokość komórki
        minHeight: 60, // Minimalna wysokość dla lepszej widoczności
        alignItems: 'center',
        justifyContent: 'center', // Wyśrodkowanie zawartości
        paddingVertical: spacing.xs,
        paddingHorizontal: spacing.xxs,
        marginHorizontal: spacing.xs, // Niewielki odstęp między komórkami
        borderRadius: borderRadius.md, // Zaokrąglenie komórek
        ...shadows.smallInner // Subtelny wewnętrzny cień lub efekt
    },
    attemptCellDeclared: {
        backgroundColor: colors.surfaceVariant, // Neutralne tło dla zadeklarowanych
    },
    attemptCellPassed: {
        backgroundColor: colors.success, // Zielone tło dla zaliczonych
    },
    attemptCellFailed: {
        backgroundColor: colors.error, // Czerwone tło dla spalonych
    },
    attemptWeightBase: {
        fontSize: font.sizes['2xl'], // Duży, czytelny ciężar
        fontWeight: font.weights.bold, // Pogrubiony ciężar
        marginBottom: spacing.xxs,
    },
    attemptWeightDeclaredText: {
        color: colors.text, // Ciemny tekst na neutralnym tle
    },
    attemptWeightResultText: {
        color: colors.white, // Biały tekst na kolorowym tle (zaliczony/spalony)
    },
    attemptStatusIcon: {
        // Ikony będą miały kolor biały na tle passed/failed
    },
    attemptStatusIconPlaceholder: {
        // Już ustawione dynamicznie
    },
    completedIndicator: {
        marginLeft: spacing.md,
        padding: spacing.xs,
        alignItems: 'center',
        justifyContent: 'center',
        width: 40, // DODANO: Stała szerokość dla wskaźnika
    }
});

export default GroupAthleteList;