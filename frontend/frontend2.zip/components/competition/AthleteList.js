import React, { useState } from 'react'; // Dodaj useState
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform } from 'react-native'; // Dodaj Platform
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius } from '../../theme/theme';

const AthleteList = ({ athletes, currentAthleteFilteredIndex, onSelectAthlete }) => {
    const [hoveredAthlete, setHoveredAthlete] = useState(null); // Stan do śledzenia najechanego zawodnika

    return (
        <View style={styles.athleteListContainer}>
            <Text style={styles.subHeader}>Zawodnicy w tej grupie:</Text>
            {athletes.length === 0 ? (
                <Text style={styles.emptyText}>Brak zawodników w tej kategorii/wadze.</Text>
            ) : (
                <ScrollView style={styles.athleteScroll}>
                    {athletes.map((athlete, index) => (
                        <TouchableOpacity
                            key={athlete.originalIndex}
                            style={[
                                styles.athleteListItem,
                                index === currentAthleteFilteredIndex && styles.athleteListItemActive,
                                athlete.isCompleted && !(index === currentAthleteFilteredIndex) && styles.athleteListItemCompleted, // Nie stosuj completed jeśli aktywny
                                Platform.OS === 'web' && hoveredAthlete === athlete.originalIndex && styles.athleteListItemHover,
                                // Jeśli jest najechany, styl hover powinien nadpisać styl completed
                                Platform.OS === 'web' && hoveredAthlete === athlete.originalIndex && athlete.isCompleted && styles.athleteListItemHover
                            ]}
                            onPress={() => onSelectAthlete(athlete.originalIndex)}
                            {...(Platform.OS === 'web' && {
                                onMouseEnter: () => setHoveredAthlete(athlete.originalIndex),
                                onMouseLeave: () => setHoveredAthlete(null),
                            })}
                        >
                            <View style={styles.athleteListItemContent}>
                                <Text style={[
                                    styles.athleteListText,
                                    (Platform.OS === 'web' && hoveredAthlete === athlete.originalIndex) && styles.athleteListTextHover, // Zmiana koloru tekstu na hover
                                    athlete.isCompleted && !(index === currentAthleteFilteredIndex || (Platform.OS === 'web' && hoveredAthlete === athlete.originalIndex)) && styles.athleteListTextCompleted
                                ]}>
                                    {index + 1}. {athlete.imie} {athlete.nazwisko} ({athlete.klub || 'brak klubu'})
                                    <Text style={styles.athleteListAttempt1}> [{athlete.podejscie1 || 'N/A'} kg]</Text>
                                </Text>
                                {athlete.isCompleted && !(Platform.OS === 'web' && hoveredAthlete === athlete.originalIndex) && ( // Nie pokazuj ikony check jeśli jest hover
                                    <AntDesign name="checkcircle" size={18} color={colors.success} style={styles.completedIcon} />
                                )}
                            </View>
                        </TouchableOpacity>
                    ))}
                </ScrollView>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    athleteListContainer: { marginTop: spacing.md },
    subHeader: { fontSize: font.sizes.md, fontWeight: font.weights.semibold, color: colors.textSecondary, marginBottom: spacing.sm },
    emptyText: { color: colors.textSecondary, fontStyle: 'italic', textAlign: 'center', marginTop: spacing.md },
    athleteScroll: { maxHeight: 200, borderWidth: 1, borderColor: colors.borderLight, borderRadius: borderRadius.md },
    athleteListItem: {
        paddingVertical: spacing.sm,
        paddingHorizontal: spacing.md,
        borderBottomWidth: 1,
        borderBottomColor: colors.borderLight,
        backgroundColor: colors.surface,
        transition: 'transform 0.1s ease-out, background-color 0.1s ease-out', // Dodano transition
    },
    athleteListItemActive: {
        backgroundColor: colors.primary + '20', // Jaśniejsze tło dla aktywnego
        borderLeftWidth: 4,
        borderLeftColor: colors.primary,
        paddingLeft: spacing.md - 4, // Dostosuj padding, aby tekst się nie przesuwał
    },
    athleteListItemHover: { // Nowy styl dla hover
        backgroundColor: colors.primary + '15', // Lekko inne tło niż active
        transform: [{ translateX: 2 }], // Lekkie przesunięcie w prawo
        // Można też dodać np. borderLeftColor: colors.primary + '80',
    },
    athleteListText: { fontSize: font.sizes.sm, color: colors.text, flex: 1, marginRight: spacing.sm },
    athleteListTextHover: { // Styl tekstu dla hover, jeśli potrzebny inny niż domyślny
        // color: colors.primary, // Na przykład, jeśli chcesz zmienić kolor tekstu na hover
    },
    athleteListAttempt1: { fontSize: font.sizes.xs, color: colors.textSecondary },
    athleteListItemCompleted: {
        backgroundColor: colors.surfaceVariant + '99', // Tło dla ukończonych
        opacity: 0.7, // Lekka przezroczystość dla ukończonych
    },
    athleteListItemContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flex: 1 },
    athleteListTextCompleted: {
        // color: colors.textSecondary, // Opcjonalnie: inny kolor tekstu dla ukończonych
    },
    completedIcon: { marginLeft: spacing.sm },
});

export default AthleteList;