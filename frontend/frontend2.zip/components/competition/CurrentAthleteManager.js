import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, Platform } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius } from '../../theme/theme';

const CurrentAthleteManager = ({ athlete, athleteOriginalIndex, currentAttemptNr, onAttemptStatusChange, onWeightChange, isSaving }) => {
    if (!athlete) {
        return <Text style={styles.emptyText}>Wybierz zawodnika z listy.</Text>;
    }

    const getStatusIcon = (status) => {
        if (status === 'passed') return <AntDesign name="checkcircle" size={24} color={colors.success} />;
        if (status === 'failed') return <AntDesign name="closecircle" size={24} color={colors.error} />;
        return <AntDesign name="clockcircleo" size={24} color={colors.textSecondary} />;
    };

    const handleWeightInput = (nr, text) => {
        const numericValue = text.replace(/[^0-9]/g, '');
        onWeightChange(athleteOriginalIndex, nr, numericValue);
    };

    return (
        <View style={styles.currentAthleteContainer}>
            <Text style={styles.currentAthleteName}>{athlete.imie} {athlete.nazwisko}</Text>
            <Text style={styles.currentAthleteClub}>{athlete.klub || 'brak klubu'}</Text>
            <View style={styles.attemptsContainer}>
                {[1, 2, 3].map((nr) => {
                    const weight = athlete[`podejscie${nr}`];
                    const status = athlete[`podejscie${nr}Status`];
                    const isCurrent = currentAttemptNr === nr;
                    const isEditable = !status && nr >= currentAttemptNr; // Allow editing current and future unattempted

                    return (
                        <View key={nr} style={[styles.attemptBox, isCurrent && !status && styles.attemptBoxActive]}>
                            <Text style={styles.attemptLabel}>Podejście {nr}</Text>
                            {isEditable ? (
                                <TextInput
                                    style={styles.attemptWeightInput}
                                    value={String(weight || '')}
                                    onChangeText={(text) => handleWeightInput(nr, text)}
                                    keyboardType="numeric"
                                    placeholder="kg"
                                    editable={!isSaving}
                                />
                            ) : (
                                <Text style={styles.attemptWeight}>{weight ? `${weight} kg` : '-'}</Text>
                            )}
                            <View style={styles.attemptStatusIcon}>{getStatusIcon(status)}</View>
                            {isCurrent && !status && ( // Show actions only for current, non-statused attempt
                                <View style={styles.attemptActions}>
                                    <TouchableOpacity
                                        style={[styles.actionButton, styles.passButton, isSaving && styles.actionButtonDisabled]}
                                        onPress={() => !isSaving && onAttemptStatusChange(athleteOriginalIndex, nr, 'passed')}
                                        disabled={isSaving}
                                    >
                                        {isSaving ? <ActivityIndicator size="small" color={colors.textLight} /> : <Text style={styles.actionButtonText}>Zalicz</Text>}
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        style={[styles.actionButton, styles.failButton, isSaving && styles.actionButtonDisabled]}
                                        onPress={() => !isSaving && onAttemptStatusChange(athleteOriginalIndex, nr, 'failed')}
                                        disabled={isSaving}
                                    >
                                        {isSaving ? <ActivityIndicator size="small" color={colors.textLight} /> : <Text style={styles.actionButtonText}>Spal</Text>}
                                    </TouchableOpacity>
                                </View>
                            )}
                        </View>
                    );
                })}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    emptyText: { color: colors.textSecondary, fontStyle: 'italic', textAlign: 'center', marginTop: spacing.md },
    currentAthleteContainer: { alignItems: 'center' },
    currentAthleteName: { fontSize: font.sizes.lg, fontWeight: font.weights.bold, color: colors.primary, marginBottom: spacing.xs },
    currentAthleteClub: { fontSize: font.sizes.sm, color: colors.textSecondary, marginBottom: spacing.md },
    attemptsContainer: { width: '100%', gap: spacing.sm },
    attemptBox: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: colors.background, padding: spacing.sm, borderRadius: borderRadius.md, borderWidth: 1, borderColor: colors.border },
    attemptBoxActive: { borderColor: colors.primary, borderWidth: 2, backgroundColor: colors.surface }, // Highlight active attempt more
    attemptLabel: { fontSize: font.sizes.sm, color: colors.textSecondary, width: '25%' },
    attemptWeight: { fontSize: font.sizes.md, fontWeight: font.weights.semibold, color: colors.text, width: '20%', textAlign: 'center' },
    attemptWeightInput: { fontSize: font.sizes.md, fontWeight: font.weights.semibold, color: colors.text, width: '20%', textAlign: 'center', borderBottomWidth: 1, borderColor: colors.primary, paddingVertical: Platform.OS === 'ios' ? spacing.xs : 0 },
    attemptStatusIcon: { width: '15%', alignItems: 'center' },
    attemptActions: { flexDirection: 'row', gap: spacing.xs, width: '40%', justifyContent: 'flex-end' },
    actionButton: { paddingVertical: spacing.xs, paddingHorizontal: spacing.sm, borderRadius: borderRadius.sm, alignItems: 'center', justifyContent: 'center', minWidth: 60 },
    actionButtonDisabled: { backgroundColor: colors.border, opacity: 0.7 },
    passButton: { backgroundColor: colors.success },
    failButton: { backgroundColor: colors.error },
    actionButtonText: { color: colors.textLight, fontSize: font.sizes.xs, fontWeight: font.weights.medium },
});

export default CurrentAthleteManager;