import React, { useState } from 'react'; // Dodaj useState
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator, Platform } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius } from '../../theme/theme';

const OptionSelector = ({ label, options, selectedValue, onSelect, placeholder = "Wybierz...", loading = false }) => {
    const [hoveredOption, setHoveredOption] = useState(null); // Stan do śledzenia najechanego elementu

    return (
        <View style={styles.selectorContainer}>
            <Text style={styles.selectorLabel}>{label}:</Text>
            {loading ? (
                <ActivityIndicator size="small" color={colors.primary} style={styles.selectorLoading} />
            ) : options.length === 0 ? (
                <Text style={styles.selectorEmpty}>Brak opcji</Text>
            ) : (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.selectorScroll}>
                    <TouchableOpacity
                        key="placeholder"
                        style={[
                            styles.selectorOption,
                            !selectedValue && styles.selectorOptionActive,
                            Platform.OS === 'web' && hoveredOption === 'placeholder' && styles.selectorOptionHover
                        ]}
                        onPress={() => onSelect(null)}
                        disabled={loading}
                        {...(Platform.OS === 'web' && {
                            onMouseEnter: () => setHoveredOption('placeholder'),
                            onMouseLeave: () => setHoveredOption(null),
                        })}
                    >
                        <Text style={[
                            styles.selectorOptionText,
                            (!selectedValue || (Platform.OS === 'web' && hoveredOption === 'placeholder')) && styles.selectorOptionTextActive
                        ]}>
                            {placeholder}
                        </Text>
                    </TouchableOpacity>
                    {options.map((option) => (
                        <TouchableOpacity
                            key={option.value}
                            style={[
                                styles.selectorOption,
                                selectedValue === option.value && styles.selectorOptionActive,
                                option.isCompleted && ! (selectedValue === option.value) && styles.selectorOptionCompleted, // Nie stosuj stylu completed jeśli jest aktywny
                                Platform.OS === 'web' && hoveredOption === option.value && styles.selectorOptionHover,
                                // Jeśli jest najechany, styl hover powinien nadpisać styl completed
                                Platform.OS === 'web' && hoveredOption === option.value && option.isCompleted && styles.selectorOptionHover // Upewnij się, że hover nadpisuje completed
                            ]}
                            onPress={() => onSelect(option.value)}
                            disabled={loading}
                            {...(Platform.OS === 'web' && {
                                onMouseEnter: () => setHoveredOption(option.value),
                                onMouseLeave: () => setHoveredOption(null),
                            })}
                        >
                            <Text style={[
                                styles.selectorOptionText,
                                (selectedValue === option.value || (Platform.OS === 'web' && hoveredOption === option.value)) && styles.selectorOptionTextActive,
                                option.isCompleted && !(selectedValue === option.value || (Platform.OS === 'web' && hoveredOption === option.value)) && styles.selectorOptionTextCompleted
                            ]}>
                                {option.label}
                            </Text>
                            {option.isCompleted && !(Platform.OS === 'web' && hoveredOption === option.value) && ( // Nie pokazuj ikony check jeśli jest hover
                                 <AntDesign name="check" size={12} color={(selectedValue === option.value) ? colors.textLight : colors.success} style={styles.selectorCompletedIcon} />
                            )}
                        </TouchableOpacity>
                    ))}
                </ScrollView>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    selectorContainer: { marginBottom: spacing.md },
    selectorLabel: { fontSize: font.sizes.sm, fontWeight: font.weights.medium, color: colors.textSecondary, marginBottom: spacing.xs },
    selectorScroll: { flexDirection: 'row' },
    selectorOption: {
        paddingVertical: spacing.xs, paddingHorizontal: spacing.md,
        backgroundColor: colors.surfaceVariant, borderRadius: borderRadius.full,
        marginRight: spacing.sm, borderWidth: 1, borderColor: colors.border,
        flexDirection: 'row', alignItems: 'center',
        transition: 'transform 0.15s ease, background-color 0.15s ease, border-color 0.15s ease', // Dodano transition
    },
    selectorOptionActive: { backgroundColor: colors.primary, borderColor: colors.primary },
    selectorOptionHover: { // Nowy styl dla hover
        backgroundColor: colors.primary,
        borderColor: colors.primary,
        transform: [{ scale: 1.05 }],
    },
    selectorOptionText: { color: colors.text, fontWeight: font.weights.medium, fontSize: font.sizes.sm },
    selectorOptionTextActive: { color: colors.textLight },
    selectorLoading: { alignSelf: 'flex-start', marginLeft: spacing.md },
    selectorEmpty: { color: colors.textSecondary, fontStyle: 'italic', marginLeft: spacing.md },
    selectorOptionCompleted: {
        backgroundColor: colors.surfaceVariant + '99', 
        borderColor: colors.success + '80', 
    },
    selectorOptionTextCompleted: {
        color: colors.textSecondary, 
    },
    selectorCompletedIcon: {
        marginLeft: spacing.xs,
    },
});

export default OptionSelector;