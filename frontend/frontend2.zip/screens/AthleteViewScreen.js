import React, { useEffect, useState, useRef, useMemo, useLayoutEffect } from 'react';
import { View, Text } from 'react-native';
// import { LinearGradient } from 'expo-linear-gradient'; // Można rozważyć dla nagłówka
import { useCompetitionStore } from '../store/useCompetitionStore';
import AttemptResultAnimation from '../components/competition/AttemptResultAnimation';
import AttemptDisplay from '../components/athleteView/AttemptDisplay';
import AthleteViewTimerDisplay from '../components/athleteView/AthleteViewTimerDisplay';
import GroupAthleteList from '../components/athleteView/GroupAthleteList';
import { styles } from '../styles/AthleteViewStyles/AthleteViewScreen.styles'; // Poprawiona ścieżka, jeśli była z błędem
import { font, spacing } from '../theme/theme'; //

const hasAthleteCompleted = (athlete) => {
  return !!(athlete.podejscie1Status && athlete.podejscie2Status && athlete.podejscie3Status);
};

export default function AthleteViewScreen() {
    const {
        zawody, zawodnicy, activeCategory, activeWeight,
        activeAthleteOriginalIndex, activeAttemptNr,
        timerActive,
        timerTimeLeft,
        socket,
        setTimerActive: storeSetTimerActive,
        setTimerTimeLeft: storeSetTimerTimeLeft,
        attemptResultForAnimation,
        clearAttemptResultForAnimation
    } = useCompetitionStore(state => ({
        zawody: state.zawody,
        zawodnicy: state.zawodnicy,
        activeCategory: state.activeCategory,
        activeWeight: state.activeWeight,
        activeAthleteOriginalIndex: state.activeAthleteOriginalIndex,
        activeAttemptNr: state.activeAttemptNr,
        timerActive: state.timerActive,
        timerTimeLeft: state.timerTimeLeft,
        socket: state.socket,
        setTimerActive: state.setTimerActive,
        setTimerTimeLeft: state.setTimerTimeLeft,
        attemptResultForAnimation: state.attemptResultForAnimation,
        clearAttemptResultForAnimation: state.clearAttemptResultForAnimation,
    }));

    const [displayTime, setDisplayTime] = useState(timerTimeLeft);
    const localIntervalRef = useRef(null);

    const [showAnimationOverlay, setShowAnimationOverlay] = useState(false);
    const [animationSuccess, setAnimationSuccess] = useState(false);
    const animationTimeoutRef = useRef(null);

    useEffect(() => {
        setDisplayTime(timerTimeLeft);
        if (timerActive) {
            if (localIntervalRef.current) clearInterval(localIntervalRef.current);
            localIntervalRef.current = setInterval(() => {
                setDisplayTime(prevDisplayTime => {
                    if (prevDisplayTime <= 1) {
                        clearInterval(localIntervalRef.current);
                        localIntervalRef.current = null;
                        return 0;
                    }
                    return prevDisplayTime - 1;
                });
            }, 1000);
        } else {
            if (localIntervalRef.current) {
                clearInterval(localIntervalRef.current);
                localIntervalRef.current = null;
            }
        }
        return () => {
            if (localIntervalRef.current) clearInterval(localIntervalRef.current);
        };
    }, [timerActive, timerTimeLeft]);

    useEffect(() => {
        if (!socket) return;
        const handleTimerStarted = (data) => {
            console.log('[AthleteViewScreen] Received timerStarted socket event', data);
            storeSetTimerActive(true);
            storeSetTimerTimeLeft(data.timeLeft || 60);
        };
        const handleTimerStopped = (data) => {
            console.log('[AthleteViewScreen] Received timerStopped socket event', data);
            storeSetTimerActive(false);
            if (data && data.finalTimeLeft !== undefined) {
                storeSetTimerTimeLeft(data.finalTimeLeft);
            }
        };
        socket.on('timerStarted', handleTimerStarted);
        socket.on('timerStopped', handleTimerStopped);
        return () => {
            socket.off('timerStarted', handleTimerStarted);
            socket.off('timerStopped', handleTimerStopped);
        };
    }, [socket, storeSetTimerActive, storeSetTimerTimeLeft]);

    useEffect(() => {
        if (attemptResultForAnimation && typeof attemptResultForAnimation.success === 'boolean') {
            console.log('[AthleteViewScreen] Animation triggered:', attemptResultForAnimation);
            setAnimationSuccess(attemptResultForAnimation.success);
            setShowAnimationOverlay(true);
            if (animationTimeoutRef.current) clearTimeout(animationTimeoutRef.current);
            animationTimeoutRef.current = setTimeout(() => {
                setShowAnimationOverlay(false);
                clearAttemptResultForAnimation();
                console.log('[AthleteViewScreen] Animation overlay hidden.');
            }, 2000); // Czas trwania animacji
        }
        return () => {
            if (animationTimeoutRef.current) clearTimeout(animationTimeoutRef.current);
        };
    }, [attemptResultForAnimation, clearAttemptResultForAnimation]);


    const currentAthlete = useMemo(() => {
        if (activeAthleteOriginalIndex === null || !zawodnicy || zawodnicy.length === 0) return null;
        return zawodnicy[activeAthleteOriginalIndex];
    }, [zawodnicy, activeAthleteOriginalIndex]);

    const groupAthletes = useMemo(() => {
        if (!activeCategory || !activeWeight || !zawodnicy) return [];
        return zawodnicy
            .map((z, index) => ({ ...z, originalIndex: index, isCompleted: hasAthleteCompleted(z) }))
            .filter(z => z.kategoria === activeCategory && z.waga === activeWeight)
            .sort((a, b) => { // Sortowanie: najpierw nieukończeni, potem po podejściu 1 rosnąco
                if (a.isCompleted !== b.isCompleted) {
                    return a.isCompleted ? 1 : -1; // Nieukończeni na górze
                }
                const weightA = Number(a.podejscie1) || Infinity; // Niezadeklarowane na końcu
                const weightB = Number(b.podejscie1) || Infinity; // Niezadeklarowane na końcu
                return weightA - weightB;
            });
    }, [zawodnicy, activeCategory, activeWeight]);

    const renderStartTime = useRef(null);
    useLayoutEffect(() => { renderStartTime.current = performance.now(); });
    useEffect(() => {
        if (renderStartTime.current) {
            const renderEndTime = performance.now();
            // console.log(`AthleteViewScreen render time: ${renderEndTime - renderStartTime.current} ms`);
            renderStartTime.current = null;
        }
    });

    const renderGroupHeader = () => {
        if (activeCategory && activeWeight && activeAthleteOriginalIndex === null) {
            return (
                <View style={styles.groupHeader}>
                    <Text style={styles.groupHeaderTitle}>{activeCategory}</Text>
                    <Text style={styles.groupHeaderSubtitle}>Kategoria Wagowa: {activeWeight}</Text>
                </View>
            );
        }
        return null;
    };

    return (
        <View style={styles.container}>
            {renderGroupHeader()}

            <View style={styles.mainContent}>
                {activeAthleteOriginalIndex !== null && currentAthlete ? (
                    <>
                        <View style={styles.athleteInfoCard}>
                            <Text style={styles.athleteName}>{currentAthlete.imie} {currentAthlete.nazwisko}</Text>
                            <Text style={styles.athleteClub}>{currentAthlete.klub || 'Brak klubu'}</Text>
                            <Text style={styles.athleteCategory}>
                                Kat: {currentAthlete.kategoria} / Waga: {currentAthlete.waga} kg
                            </Text>
                        </View>
                        <View style={styles.attemptsContainer}>
                            <Text style={styles.sectionTitle}>Podejścia</Text>
                            {[1, 2, 3].map((nr) => (
                                <AttemptDisplay
                                    key={nr}
                                    number={nr}
                                    weight={currentAthlete[`podejscie${nr}`]}
                                    status={currentAthlete[`podejscie${nr}Status`]}
                                    isActive={activeAttemptNr === nr}
                                />
                            ))}
                        </View>
                        <View style={styles.timerSection}>
                             <Text style={styles.sectionTitle}>Czas</Text>
                             <AthleteViewTimerDisplay isActive={timerActive} timeLeft={displayTime} />
                        </View>
                    </>
                ) : activeCategory && activeWeight ? ( // Widok listy zawodników w grupie
                     <View style={styles.groupViewContainer}>
                         {/* Tytuł "Lista zawodników w grupie" jest teraz częścią nagłówka lub niepotrzebny */}
                         <GroupAthleteList
                            athletes={groupAthletes}
                            currentAthleteOriginalIndex={activeAthleteOriginalIndex} // Przekazujemy, choć może nie być używane w tym widoku
                         />
                    </View>
                ) : ( // Widok początkowy / placeholder
                    <View style={styles.placeholderContainer}>
                        <Text style={styles.placeholderText}>Wybierz kategorię i wagę w panelu sędziego, aby zobaczyć listę zawodników.</Text>
                        <Text style={[styles.placeholderText, {fontSize: font.sizes['5xl'], marginTop: spacing.lg}]}>🏆</Text>
                    </View>
                )}
            </View>

            {showAnimationOverlay && (
                <View style={styles.animationOverlay}>
                    <AttemptResultAnimation success={animationSuccess} />
                </View>
            )}
        </View>
    );
}