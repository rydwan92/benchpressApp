import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, useWindowDimensions, ActivityIndicator, Platform } from 'react-native'; // Removed StyleSheet, TextInput
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { useCompetitionStore } from '../store/useCompetitionStore';
import { saveAppData } from '../utils/api';
import NavBar from '../components/navigation/NavBar';
import Footer from '../components/navigation/Footer';
import { colors, font, spacing, borderRadius } from '../theme/theme'; // Removed shadows, componentStyles as they are in .styles.js
// import { AntDesign } from '@expo/vector-icons'; // No longer directly used here

// Import new components
import OptionSelector from '../components/competition/OptionSelector';
import AthleteList from '../components/competition/AthleteList';
import CurrentAthleteManager from '../components/competition/CurrentAthleteManager';
import TimerDisplay from '../components/competition/TimerDisplay';

// Import styles
import { styles } from '../styles/CompetitionStyles/CompetitionScreen.styles.js';

// --- Funkcja pomocnicza do sprawdzania ukończenia zawodnika ---
const hasAthleteCompleted = (athlete) => {
  // Sprawdza, czy wszystkie trzy statusy podejść są ustawione (nie są null)
  return !!(athlete.podejscie1Status && athlete.podejscie2Status && athlete.podejscie3Status);
};
// --- KONIEC ZMIANY ---

// --- Komponenty pomocnicze (OptionSelector, AthleteList, CurrentAthleteManager, Timer) ---
// USUŃ LOKALNE DEFINICJE KOMPONENTÓW OptionSelector, AthleteList, CurrentAthleteManager, TimerDisplay (dawniej Timer)
// PONIŻSZE LINIE POWINNY ZOSTAĆ USUNIĘTE, PONIEWAŻ KOMPONENTY SĄ JUŻ IMPORTOWANE

// const OptionSelector = ({ label, options, selectedValue, onSelect, placeholder = "Wybierz...", loading = false }) => ( ... );
// const AthleteList = ({ athletes, currentAthleteFilteredIndex, onSelectAthlete }) => ( ... );
// const CurrentAthleteManager = ({ athlete, athleteOriginalIndex, currentAttemptNr, onAttemptStatusChange, onWeightChange, isSaving }) => { ... };
// const Timer = ({ isActive, timeLeft }) => { ... }; // Zmieniono nazwę na TimerDisplay podczas importu


// --- Główny komponent ekranu ---

export default function CompetitionScreen() {
  const navigation = useNavigation();
  // Pobieranie stanu i akcji ze store'u
  const {
    zawody, kategorie, zawodnicy,
    activeCategory, activeWeight, activeAthleteOriginalIndex, activeAttemptNr, timerActive, timerTimeLeft,
    updatePodejscieStatus, updatePodejscieWaga, // Usunięto setInitialData, jeśli nie jest tu potrzebne
    setActiveGroup, setActiveAthlete, setActiveAttemptNr, setTimerActive, setTimerTimeLeft,
    socket,
    setAttemptResultForAnimation // Dodano, jeśli jeszcze nie było
  } = useCompetitionStore(state => ({
      zawody: state.zawody,
      kategorie: state.kategorie,
      zawodnicy: state.zawodnicy,
      activeCategory: state.activeCategory,
      activeWeight: state.activeWeight,
      activeAthleteOriginalIndex: state.activeAthleteOriginalIndex,
      activeAttemptNr: state.activeAttemptNr,
      timerActive: state.timerActive,
      timerTimeLeft: state.timerTimeLeft,
      updatePodejscieStatus: state.updatePodejscieStatus,
      updatePodejscieWaga: state.updatePodejscieWaga,
      // setInitialData: state.setInitialData, // Upewnij się, czy jest potrzebne
      setActiveGroup: state.setActiveGroup,
      setActiveAthlete: state.setActiveAthlete,
      setActiveAttemptNr: state.setActiveAttemptNr,
      setTimerActive: state.setTimerActive,
      setTimerTimeLeft: state.setTimerTimeLeft,
      socket: state.socket,
      setAttemptResultForAnimation: state.setAttemptResultForAnimation // Dodaj, jeśli nie ma
  }));

  const { width } = useWindowDimensions();
  const [isSaving, setIsSaving] = useState(false);
  const [headerKlubAvatarDimensions, setHeaderKlubAvatarDimensions] = useState(null);
  const [headerJudgeAvatarDimensions, setHeaderJudgeAvatarDimensions] = useState(null); // Initialize as null

  // Efekty ładowania avatarów (bez zmian)
  useEffect(() => {
    if (zawody.klubAvatar) {
      Image.getSize(zawody.klubAvatar, (width, height) => {
        const aspectRatio = width / height;
        const maxWidth = 150; // Matched RegScreen
        const maxHeight = 90;  // Matched RegScreen
        let displayWidth = width;
        let displayHeight = height;
        if (displayWidth > maxWidth) {
          displayWidth = maxWidth;
          displayHeight = displayWidth / aspectRatio;
        }
        if (displayHeight > maxHeight) {
          displayHeight = maxHeight;
          displayWidth = displayHeight * aspectRatio;
        }
        setHeaderKlubAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, (error) => { console.error('Błąd rozmiaru logo klubu:', error); setHeaderKlubAvatarDimensions(null); });
    } else { setHeaderKlubAvatarDimensions(null); }
  }, [zawody.klubAvatar]);

  useEffect(() => {
    if (zawody.sedzia?.avatar) {
      Image.getSize(zawody.sedzia.avatar, (width, height) => {
        const aspectRatio = width / height;
        const maxWidth = 150; // Matched RegScreen
        const maxHeight = 90;  // Matched RegScreen
        let displayWidth = width;
        let displayHeight = height;
        if (displayWidth > maxWidth) {
          displayWidth = maxWidth;
          displayHeight = displayWidth / aspectRatio;
        }
        if (displayHeight > maxHeight) {
          displayHeight = maxHeight;
          displayWidth = displayHeight * aspectRatio;
        }
        setHeaderJudgeAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, (error) => { console.error('Błąd rozmiaru avatara sędziego:', error); setHeaderJudgeAvatarDimensions(null); });
    } else { setHeaderJudgeAvatarDimensions(null); }
  }, [zawody.sedzia?.avatar]);

  // --- Logika timera ---
  const timerIntervalRef = useRef(null);
  const stableSetTimerTimeLeft = useCallback(setTimerTimeLeft, [setTimerTimeLeft]);
  const stableSetTimerActive = useCallback(setTimerActive, [setTimerActive]);

  // Definicja handleTimerFinish w zasięgu komponentu
  const handleTimerFinish = useCallback((attemptStatusChangeFn) => {
    console.log("[CompetitionScreen] Czas minął!");
    const state = useCompetitionStore.getState();
    // stableSetTimerTimeLeft(0); // Ustaw czas na 0 w store, gdy timer dobiegnie końca
    // stableSetTimerActive(false); // To już jest robione w interwale

    if (state.activeAthleteOriginalIndex !== null && state.activeAttemptNr) {
        const athlete = state.zawodnicy[state.activeAthleteOriginalIndex];
        if (athlete && !athlete[`podejscie${state.activeAttemptNr}Status`]) {
            attemptStatusChangeFn(state.activeAthleteOriginalIndex, state.activeAttemptNr, 'failed');
        }
    }
  }, [zawodnicy]); // Added zawodnicy dependency

  const stableHandleTimerFinish = useCallback(() => handleTimerFinish(handleAttemptStatusChange), [handleTimerFinish, handleAttemptStatusChange]);

  useEffect(() => {
    console.log(`[Timer useEffect] Running. timerActive: ${timerActive}, timerTimeLeft from store: ${timerTimeLeft}`);
    if (timerActive) {
      console.log(`[Timer useEffect] Starting interval...`);
      timerIntervalRef.current = setInterval(() => {
        // Pobierz aktualny czas bezpośrednio ze store, aby uniknąć problemów z closure
        const currentTimeLeftInStore = useCompetitionStore.getState().timerTimeLeft;
        console.log(`[Timer Interval Tick] currentTimeLeftInStore: ${currentTimeLeftInStore}`);

        if (currentTimeLeftInStore <= 1) {
          console.log(`[Timer Interval Tick] Time <= 1, clearing interval and stopping timer.`);
          clearInterval(timerIntervalRef.current);
          timerIntervalRef.current = null;
          
          stableSetTimerTimeLeft(0); // Upewnij się, że czas w store to 0
          stableSetTimerActive(false); // Ustaw timer jako nieaktywny w store
          
          stableHandleTimerFinish(); 
          
          if (socket && socket.connected) {
            console.log('[Timer Interval Tick] Emitting stopTimer event.');
            socket.emit('stopTimer', { finalTimeLeft: 0 }); // Wyślij końcowy czas
          }
          // Nie zwracaj nic, setTimerTimeLeft(0) już zaktualizowało store
        } else {
          stableSetTimerTimeLeft(currentTimeLeftInStore - 1); // Aktualizuj store co sekundę
        }
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        console.log(`[Timer useEffect] Clearing interval because timerActive is false.`);
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
        // Kiedy timer jest zatrzymywany z zewnątrz (np. przez przycisk stop),
        // timerTimeLeft w store powinno już mieć poprawną wartość.
        // Nie ma potrzeby dodatkowego ustawiania tutaj, chyba że chcemy wymusić jakąś wartość.
      }
    }

    return () => {
      if (timerIntervalRef.current) {
        console.log(`[Timer useEffect Cleanup] Clearing interval.`);
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    };
  }, [timerActive, stableSetTimerTimeLeft, stableSetTimerActive, stableHandleTimerFinish, socket]);


  // --- Logika pomocnicza (categoryOptions, weightOptions, filteredAthletes, etc.) ---
  const categoryOptions = useMemo(() => kategorie.map(k => ({ label: k.nazwa, value: k.nazwa })), [kategorie]);

  const activeCategoryObject = useMemo(() => {
      return kategorie.find(k => k.nazwa === activeCategory);
  }, [kategorie, activeCategory]);

  const completedWeights = useMemo(() => {
      const completed = new Set();
      if (!activeCategoryObject || !zawodnicy) {
          return completed;
      }
      activeCategoryObject.wagi.forEach(waga => {
          const athletesInGroup = zawodnicy.filter(z => z.kategoria === activeCategory && z.waga === waga);
          if (athletesInGroup.length > 0 && athletesInGroup.every(hasAthleteCompleted)) {
              completed.add(waga);
          }
      });
      return completed;
  }, [activeCategoryObject, zawodnicy, activeCategory]);

  const weightOptions = useMemo(() => {
    if (!activeCategoryObject) return [];
    const sortedWagi = [...activeCategoryObject.wagi].sort((a, b) => Number(a) - Number(b));
    return sortedWagi.map(w => ({
        label: String(w),
        value: w,
        isCompleted: completedWeights.has(w)
    }));
  }, [activeCategoryObject, completedWeights]);

  const filteredAthletes = useMemo(() => {
      if (!activeCategory || !activeWeight) return [];
      return zawodnicy
        .map((z, index) => ({
          ...z,
          originalIndex: index,
          isCompleted: hasAthleteCompleted(z)
        }))
        .filter(z => z.kategoria === activeCategory && z.waga === activeWeight)
        .sort((a, b) => {
            const weightA = Number(a.podejscie1) || 0;
            const weightB = Number(b.podejscie1) || 0;
            if (a.isCompleted !== b.isCompleted) {
              return a.isCompleted ? 1 : -1;
            }
            return weightA - weightB;
        });
  }, [zawodnicy, activeCategory, activeWeight]);

  const currentAthleteFilteredIndex = useMemo(() => {
      if (activeAthleteOriginalIndex === null) return null;
      return filteredAthletes.findIndex(z => z.originalIndex === activeAthleteOriginalIndex);
  }, [filteredAthletes, activeAthleteOriginalIndex]);

  const currentAthlete = currentAthleteFilteredIndex !== null && currentAthleteFilteredIndex > -1
    ? filteredAthletes[currentAthleteFilteredIndex]
    : null;

  // Funkcja synchronizująca dane z backendem (pozostaje do innych akcji)
  const syncData = useCallback(async (partialData = null) => {
    if (isSaving) {
        console.warn('[syncData] Save already in progress. Skipping.');
        return;
    }
    setIsSaving(true);
    try {
      const currentState = useCompetitionStore.getState();
      const { socket: currentSocket, ...stateToSend } = currentState;
      const dataToSend = partialData ? { ...stateToSend, ...partialData } : stateToSend;
      await saveAppData(dataToSend);
    } catch (error) {
      if (error instanceof TypeError && error.message.includes('cyclic object value')) {
          console.error('[CompetitionScreen] Błąd synchronizacji danych: Wykryto cykliczny obiekt!', error);
      } else {
          console.error('[CompetitionScreen] Błąd synchronizacji danych:', error);
      }
    } finally {
      setIsSaving(false);
    }
  }, [isSaving]);

  // --- Obsługa Akcji ---

  const handleSelectCategory = (category) => {
    console.log(`[CompetitionScreen] handleSelectCategory: ${category}`);
    setActiveGroup(category, null);
    syncData(); // Synchronizuj po zmianie grupy
  };

  const handleSelectWeight = (weight) => {
    console.log(`[CompetitionScreen] handleSelectWeight: ${weight}`);
    setActiveGroup(activeCategory, weight);
    syncData(); // Synchronizuj po zmianie grupy
  };

  const handleSelectAthlete = (originalIndex) => {
    console.log(`[CompetitionScreen] handleSelectAthlete: index=${originalIndex}`);
    setActiveAthlete(originalIndex);
    syncData(); // Synchronizuj po zmianie zawodnika
  };

  // Obsługa zmiany statusu podejścia
  const handleAttemptStatusChange = useCallback(async (athleteOriginalIndexToUpdate, attemptNrToUpdate, status) => {
    if (isSaving) return;
    
    const currentTimerState = useCompetitionStore.getState();
    const wasTimerActive = currentTimerState.timerActive;
    // const finalTimeLeft = currentTimerState.timerTimeLeft; // Not directly used here after stopping

    stableSetTimerActive(false);
    updatePodejscieStatus(athleteOriginalIndexToUpdate, attemptNrToUpdate, status);
    setAttemptResultForAnimation(status === 'passed');

    let nextAttemptNr = attemptNrToUpdate;
    if (attemptNrToUpdate < 3) {
        nextAttemptNr = attemptNrToUpdate + 1;
        setActiveAttemptNr(nextAttemptNr); // Set next attempt for the same athlete
    } else {
        // Athlete completed all attempts, logic to move to next athlete or clear selection might be here
        // For now, just keep the 3rd attempt active or reset
        // setActiveAttemptNr(1); // Or null, or handle next athlete
    }

    if (wasTimerActive && socket && socket.connected) {
        socket.emit('stopTimer', { finalTimeLeft: currentTimerState.timerTimeLeft }); // Send the time when stopped
    }
    await syncData();
  }, [isSaving, stableSetTimerActive, updatePodejscieStatus, setActiveAttemptNr, syncData, socket, setAttemptResultForAnimation]);

  // Obsługa zmiany wagi w inpucie
  const handleWeightChange = async (athleteOriginalIndexToUpdate, attemptNrToUpdate, weight) => {
    updatePodejscieWaga(athleteOriginalIndexToUpdate, attemptNrToUpdate, weight);
    await syncData({ zawodnicy: useCompetitionStore.getState().zawodnicy });
  };

  const handleStartAttempt = () => {
    if (!currentAthlete || timerActive || isSaving) return;
    console.log(`[CompetitionScreen] handleStartAttempt for athlete index: ${activeAthleteOriginalIndex}, attempt: ${activeAttemptNr}`);
    stableSetTimerTimeLeft(60); // Ustaw czas na 60 sekund w store
    stableSetTimerActive(true); // Aktywuj timer w store
    if (socket && socket.connected) {
        console.log('[CompetitionScreen] Emitting startTimer event');
        socket.emit('startTimer', { duration: 60, athleteId: activeAthleteOriginalIndex, attemptNr: activeAttemptNr });
    } else if (!socket || !socket.connected) {
        console.warn('[CompetitionScreen] Cannot start timer, socket is not connected.');
    }
  };

  const handleStopAttempt = () => {
    if (!timerActive || isSaving) return;
    console.log(`[CompetitionScreen] handleStopAttempt`);
    const finalTimeLeft = useCompetitionStore.getState().timerTimeLeft; // Pobierz aktualny czas przed zatrzymaniem
    stableSetTimerActive(false); // Zatrzymaj timer (aktualizuje store)
    // stableSetTimerTimeLeft(finalTimeLeft); // This might be redundant if interval clears correctly

    if (socket && socket.connected) {
      console.log('[CompetitionScreen] Emitting stopTimer event with finalTimeLeft:', finalTimeLeft);
      socket.emit('stopTimer', { finalTimeLeft });
    } else if (!socket || !socket.connected) {
        console.warn('[CompetitionScreen] Cannot stop timer, socket is not connected.');
    }
  };

  // --- Renderowanie ---

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      {/* Nagłówek */}
      <LinearGradient colors={[colors.gradient.start, colors.gradient.end]} style={styles.headerBackground}>
          <View style={styles.headerBar}>
              <View style={styles.headerSideContainer}>
                  {zawody.klubAvatar && headerKlubAvatarDimensions ? <Image source={{ uri: zawody.klubAvatar }} style={[styles.headerClubLogo, headerKlubAvatarDimensions]} /> : null}
                  <View style={styles.headerLocationDate}>
                      <Text style={styles.headerLocationText}>{zawody.miejsce}</Text>
                      <Text style={styles.headerDateText}>{zawody.data}</Text>
                  </View>
              </View>
              <Text style={styles.headerLogo}>{zawody.nazwa || 'Benchpress Cup'}</Text>
              <View style={[styles.headerSideContainer, styles.headerRightAlign]}>
                  <View style={styles.headerJudgeInfo}>
                    <Text style={styles.headerJudgeName}>{`${zawody.sedzia?.imie || ''} ${zawody.sedzia?.nazwisko || ''}`}</Text>
                  </View>
                  {zawody.sedzia?.avatar && headerJudgeAvatarDimensions ? <Image source={{ uri: zawody.sedzia.avatar }} style={[styles.headerJudgeAvatar, headerJudgeAvatarDimensions]} /> : null}
              </View>
          </View>
        <NavBar navigation={navigation} />
      </LinearGradient>

      {/* Główna zawartość */}
      <View style={styles.mainContent}>
        <Text style={styles.mainTitle}>Zarządzaj przebiegiem zawodów</Text>
        <View style={styles.columnsContainer}>

          {/* Lewa Kolumna: Wybór i Podejścia */}
          <View style={styles.leftColumn}>
            {/* Karta Wyboru */}
            <View style={styles.card}>
              <Text style={styles.columnTitle}>Wybór grupy</Text>
              <OptionSelector
                label="Kategoria"
                options={categoryOptions}
                selectedValue={activeCategory}
                onSelect={handleSelectCategory}
                placeholder="Wybierz kategorię"
              />
              <OptionSelector
                label="Waga"
                options={weightOptions}
                selectedValue={activeWeight}
                onSelect={handleSelectWeight}
                placeholder="Wybierz wagę"
              />
              {activeCategory && activeWeight && (
                <AthleteList
                  athletes={filteredAthletes}
                  currentAthleteFilteredIndex={currentAthleteFilteredIndex}
                  onSelectAthlete={handleSelectAthlete}
                />
              )}
            </View>

            {/* Karta Podejść */}
            <View style={styles.card}>
              <Text style={styles.columnTitle}>Podejścia zawodnika</Text>
              <CurrentAthleteManager
                athlete={currentAthlete}
                athleteOriginalIndex={activeAthleteOriginalIndex}
                currentAttemptNr={activeAttemptNr}
                onAttemptStatusChange={handleAttemptStatusChange}
                onWeightChange={handleWeightChange}
                isSaving={isSaving}
              />
            </View>
          </View>

          {/* Prawa Kolumna: Zarządzanie */}
          <View style={styles.rightColumn}>
            <View style={styles.card}>
              <Text style={styles.columnTitle}>Zarządzanie</Text>

              {/* Timer */}
              <TimerDisplay
                isActive={timerActive}
                timeLeft={timerTimeLeft}
              />

              {/* Info o aktualnym zawodniku i podejściu */}
              <View style={styles.currentStatusInfo}>
                <Text style={styles.currentStatusLabel}>Aktualnie:</Text>
                {currentAthlete ? (
                  <>
                    <Text style={styles.currentStatusText}>
                      {currentAthlete.imie} {currentAthlete.nazwisko} ({currentAthlete.klub || 'brak klubu'})
                    </Text>
                    <Text style={styles.currentStatusText}>
                      Podejście: {activeAttemptNr} / Ciężar: {currentAthlete[`podejscie${activeAttemptNr}`] || '-'} kg
                    </Text>
                  </>
                ) : (
                  <Text style={styles.currentStatusText}>Wybierz zawodnika</Text>
                )}
              </View>

              {/* Przyciski Akcji */}
              <View style={styles.mainActionButtons}>
                <TouchableOpacity
                  style={[
                    styles.mainActionButton, styles.startButton,
                    (!currentAthlete || timerActive || isSaving) && styles.actionButtonDisabled
                  ]}
                  onPress={handleStartAttempt}
                  disabled={!currentAthlete || timerActive || isSaving}
                >
                  {isSaving ? <ActivityIndicator size="small" color={colors.textLight} /> : <Text style={styles.mainActionButtonText}>Rozpocznij podejście</Text>}
                </TouchableOpacity>
                 <TouchableOpacity
                  style={[
                    styles.mainActionButton, styles.stopButton,
                    (!timerActive || isSaving) && styles.actionButtonDisabled
                  ]}
                  onPress={handleStopAttempt}
                  disabled={!timerActive || isSaving}
                >
                  {isSaving ? <ActivityIndicator size="small" color={colors.textLight} /> : <Text style={styles.mainActionButtonText}>Zatrzymaj czas</Text>}
                </TouchableOpacity>
              </View>
            </View>
            {/* Możesz tu dodać inne karty zarządzania, np. szybkie przejście do następnego zawodnika */}
          </View>
        </View>
      </View>

      <Footer />
    </ScrollView>
  );
}
