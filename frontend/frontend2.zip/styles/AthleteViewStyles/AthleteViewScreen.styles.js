import { StyleSheet } from 'react-native';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme';

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.backgroundDark,
    },
    // Nagłówek dla informacji o grupie
    groupHeader: {
        backgroundColor: colors.accent, // Ciemniejszy odcień primary dla nagłówka
        paddingVertical: spacing.lg, // Zwiększony padding dla lepszej prezencji
        paddingHorizontal: spacing.xl,
        ...shadows.large, // Mocniejszy cień dla wyróżnienia
        marginBottom: spacing.lg, // Odstęp od głównej zawartości
    },
    groupHeaderTitle: {
        fontSize: font.sizes['5xl'], // Jeszcze większy tytuł kategorii
        fontWeight: font.weights.extrabold,
        color: colors.textMainTitle, // Jasny tekst na ciemnym tle
        textAlign: 'center',
        fontFamily: font.familyDisplay || font.family, // Użyj fontu display, jeśli zdefiniowany
        letterSpacing: 1,
        textShadowColor: 'rgba(0, 0, 0, 0.3)', // Subtelny cień tekstu
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 2,
        marginBottom: spacing.sm, // Dodajmy mały margines pod głównym tytułem kategorii
    },
    groupHeaderSubtitle: {
        fontSize: font.sizes['3xl'], // Większy podtytuł wagi
        fontWeight: font.weights.bold,
        color: colors.textMainTitle + 'f0', // Jeszcze mniej przezroczysty, prawie pełny kolor
        textAlign: 'center',
        marginTop: spacing.xs, // Zmniejszony margines górny, jeśli jest tło
        backgroundColor: 'rgba(0, 0, 0, 0.15)', // Subtelne, ciemniejsze tło dla podtytułu
        paddingVertical: spacing.sm, // Padding pionowy dla tła
        paddingHorizontal: spacing.lg, // Padding poziomy dla tła
        borderRadius: borderRadius.md, // Zaokrąglenie tła
        alignSelf: 'center', // Aby tło dopasowało się do szerokości tekstu
        minWidth: '60%', // Minimalna szerokość, aby nie było zbyt wąskie
        maxWidth: '90%', // Maksymalna szerokość, aby nie rozciągało się za bardzo
        borderWidth: 1, // Subtelna ramka
        borderColor: colors.textMainTitle + '50', // Kolor ramki lekko przezroczysty
    },
    mainContent: {
        flex: 1,
        paddingHorizontal: spacing.md, // Mniejszy padding, bo karty mają swój
        paddingTop: spacing.sm, // Mniejszy padding na górze, jeśli jest nagłówek
        alignItems: 'center',
    },
    placeholderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: spacing.xl,
    },
    placeholderText: {
        fontSize: font.sizes['3xl'], // Większy tekst placeholdera
        color: colors.textSecondary,
        fontStyle: 'italic',
        textAlign: 'center',
        lineHeight: font.sizes['3xl'] * 1.4, // Zwiększony interlinia
    },
    athleteInfoCard: {
        backgroundColor: colors.surface,
        borderRadius: borderRadius.xl, // Większe zaokrąglenie
        padding: spacing.xl, // Więcej paddingu
        marginBottom: spacing.xl,
        alignItems: 'center',
        width: '98%', // Prawie pełna szerokość
        ...shadows.extraLarge, // Mocniejszy cień
    },
    athleteName: {
        fontSize: font.sizes['5xl'], // Ogromna nazwa aktywnego zawodnika
        fontWeight: font.weights.bold,
        color: colors.primary,
        marginBottom: spacing.md,
        textAlign: 'center',
    },
    athleteClub: {
        fontSize: font.sizes['2xl'], // Duży klub
        color: colors.textSecondary,
        marginBottom: spacing.sm,
        textAlign: 'center',
    },
    athleteCategory: {
        fontSize: font.sizes.xl, // Duża kategoria/waga
        color: colors.textSecondary,
        textAlign: 'center',
        marginBottom: spacing.lg,
    },
    sectionTitle: { // Używane dla "Podejścia", "Czas", "Lista zawodników w grupie"
        fontSize: font.sizes['3xl'], // Duży tytuł sekcji (Podejścia, Czas)
        fontWeight: font.weights.bold, // Pogrubiony
        color: colors.text,
        marginBottom: spacing.lg, // Większy odstęp
        textAlign: 'center',
        width: '100%',
    },
    attemptsContainer: {
        width: '98%',
        marginBottom: spacing.xl,
        alignItems: 'center',
    },
    timerSection: {
        width: '98%',
        alignItems: 'center',
        marginBottom: spacing.xl,
    },
    groupViewContainer: { // Kontener dla GroupAthleteList
        width: '100%', // Pełna szerokość dla listy grup
        flex: 1,
    },
    animationOverlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.7)', // Ciemniejsza nakładka
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000,
    },
});