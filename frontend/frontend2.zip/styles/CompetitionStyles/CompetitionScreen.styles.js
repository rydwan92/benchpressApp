import { StyleSheet, Platform } from 'react-native';
import { colors, font, spacing, borderRadius, shadows, componentStyles } from '../../theme/theme';

export const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    contentContainer: { flexGrow: 1 },
    // Header styles (to match RegistrationScreen)
    headerBackground: {
        paddingTop: spacing.xl,
        paddingBottom: spacing.md, // Added to match RegScreen
        ...shadows.medium,
    },
    headerBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: '5%',
        paddingVertical: spacing.sm, // Added to match RegScreen (was marginBottom: spacing.lg)
        width: '100%',
    },
    headerSideContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
        minWidth: 100, // Keep minWidth for safety
        paddingBottom: spacing.xl, // Added to match RegScreen for vertical alignment
    },
    headerRightAlign: {
        justifyContent: 'flex-end',
    },
    headerClubLogo: {
        marginRight: spacing.sm,
        borderRadius: borderRadius.sm, // Matched RegScreen
    },
    headerLocationDate: {},
    headerLocationText: { // Matched RegScreen
        fontSize: font.sizes.lg,
        color: colors.textLight,
        fontWeight: font.weights.semibold,
    },
    headerDateText: { // Matched RegScreen
        fontSize: font.sizes.lg,
        color: colors.textLight, // Removed + 'aa' for consistency
        fontWeight: font.weights.semibold,
    },
    headerLogo: { // Matched RegScreen
        fontSize: font.sizes['3xl'],
        fontWeight: font.weights.extrabold, // Matched RegScreen
        color: colors.textMainTitle,
        fontFamily: font.family,
        letterSpacing: 1,
        textAlign: 'center',
        flex: 2, // Matched RegScreen
        marginHorizontal: spacing.sm, // Matched RegScreen
    },
    headerJudgeInfo: {
        alignItems: 'flex-end',
        marginRight: spacing.sm,
    },
    headerJudgeName: { // Matched RegScreen
        fontSize: font.sizes.lg,
        color: colors.textLight,
        fontWeight: font.weights.semibold,
    },
    headerJudgeAvatar: { // Matched RegScreen (dimensions will be applied from state)
        borderRadius: borderRadius.sm,
        resizeMode: 'cover',
    },
    // Main content area
    mainContent: {
        flex: 1,
        padding: spacing.lg,
        backgroundColor: colors.background, // Ensure background consistency
        borderTopLeftRadius: borderRadius['2xl'], // Added for consistency if header is different
        borderTopRightRadius: borderRadius['2xl'],// Added for consistency
        marginTop: -borderRadius.xl, // Added for consistency (overlap effect)
    },
    mainTitle: { // Using componentStyles.componentTitle as a base
        ...componentStyles.componentTitle,
        marginBottom: spacing.lg, // Keep existing margin
    },
    columnsContainer: {
        flexDirection: 'row',
        gap: spacing.lg,
        flex: 1, // Allow columns to take available space
    },
    leftColumn: { flex: 1, gap: spacing.lg },
    rightColumn: { flex: 1, gap: spacing.lg },
    card: { // Use commonStyles.card definition
        ...componentStyles.card, // from theme.js
        // backgroundColor: colors.surface, // Already in componentStyles.card
        // borderRadius: borderRadius.lg, // Already in componentStyles.card
        // padding: spacing.lg, // Already in componentStyles.card
        // ...shadows.small, // Already in componentStyles.card
    },
    columnTitle: { // Align with componentStyles.componentTitle
        ...componentStyles.componentTitle,
        color: colors.text, // ZMIANA: Kolor na czarny (colors.text)
        fontSize: font.sizes.xl, // Keep specific size
        fontWeight: font.weights.semibold, // Keep specific weight
        marginBottom: spacing.md, // Keep specific margin
    },
    // Styles for Timer and Management section in Right Column
    currentStatusInfo: {
        alignItems: 'center',
        marginBottom: spacing.lg,
        padding: spacing.md,
        backgroundColor: colors.surfaceVariant,
        borderRadius: borderRadius.md,
    },
    currentStatusLabel: {
        fontSize: font.sizes.sm,
        color: colors.textSecondary,
        marginBottom: spacing.xs,
    },
    currentStatusText: {
        fontSize: font.sizes.md,
        color: colors.text,
        textAlign: 'center',
    },
    mainActionButtons: {
        gap: spacing.md,
        alignItems: 'stretch', // Make buttons take full width of their container
    },
    mainActionButton: { // Base style for Start/Stop buttons
        ...componentStyles.button.base, // Use base from theme
        flexDirection: 'row', // For icon + text if needed later
        paddingVertical: spacing.md, // Larger padding for main actions
    },
    startButton: {
        backgroundColor: colors.primary, // Use theme color
    },
    stopButton: {
        backgroundColor: colors.warning, // Use theme color
    },
    mainActionButtonText: {
        ...componentStyles.button.text, // Use base text from theme
        fontSize: font.sizes.md, // Slightly larger text
    },
    actionButtonDisabled: { // Copied from CurrentAthleteManager for consistency
        backgroundColor: colors.border,
        opacity: 0.7,
    },
});