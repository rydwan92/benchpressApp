import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme';

const GroupAthleteList = ({ athletes, currentAthleteOriginalIndex }) => {
    const getStatusIcon = (status, weight) => {
        const iconSize = 28; // Zwiększony rozmiar ikon
        const iconStyle = styles.attemptStatusIcon;

        if ((status === 'passed' || status === 'failed') && (!weight || weight === '-')) {
            return <View style={[styles.attemptStatusIconPlaceholder, { width: iconSize, height: iconSize }]} />;
        }

        if (status === 'passed') return <AntDesign name="checkcircle" size={iconSize} color={colors.white} style={iconStyle} />;
        if (status === 'failed') return <AntDesign name="closecircle" size={iconSize} color={colors.white} style={iconStyle} />;
        if (weight && weight !== '-') return <AntDesign name="clockcircleo" size={iconSize} color={colors.textSecondary} style={iconStyle} />;
        return <View style={[styles.attemptStatusIconPlaceholder, { width: iconSize, height: iconSize }]} />;
    };

    const getAttemptCellStyle = (status) => {
        if (status === 'passed') return styles.attemptCellPassed;
        if (status === 'failed') return styles.attemptCellFailed;
        return styles.attemptCellDeclared;
    };

    const getAttemptWeightStyle = (status) => {
        if (status === 'passed' || status === 'failed') return styles.attemptWeightResultText;
        return styles.attemptWeightDeclaredText;
    };


    return (
        <ScrollView 
            style={styles.groupListScroll} 
            contentContainerStyle={styles.scrollContentContainer}
            showsVerticalScrollIndicator={false}
        >
            {athletes.length === 0 && (
                <View style={styles.emptyListContainer}>
                    <Text style={styles.emptyListText}>Brak zawodników w tej grupie.</Text>
                </View>
            )}
            {athletes.map((athlete, idx) => (
                <View
                    key={athlete.originalIndex}
                    style={[
                        styles.groupListItem,
                        athlete.originalIndex === currentAthleteOriginalIndex && styles.groupListItemActive,
                    ]}
                >
                    <View style={styles.athleteRankContainer}>
                        <Text style={styles.athleteRank}>{idx + 1}</Text>
                    </View>

                    <View style={styles.athleteInfoContainer}>
                        <Text style={styles.athleteName} numberOfLines={1}>
                            {athlete.imie} {athlete.nazwisko}
                        </Text>
                        <Text style={styles.athleteClub} numberOfLines={1}>
                            {athlete.klub || 'Brak klubu'}
                        </Text>
                    </View>

                    <View style={styles.attemptsRow}>
                        {[1, 2, 3].map(nr => {
                            const weightValue = athlete[`podejscie${nr}`];
                            const statusValue = athlete[`podejscie${nr}Status`];
                            return (
                                <View key={nr} style={[styles.attemptCellBase, getAttemptCellStyle(statusValue)]}>
                                    <Text style={[styles.attemptWeightBase, getAttemptWeightStyle(statusValue)]}>
                                        {weightValue || '-'}
                                    </Text>
                                    {getStatusIcon(statusValue, weightValue)}
                                </View>
                            );
                        })}
                    </View>
                    <View style={styles.completedIndicator}>
                        {athlete.isCompleted && (
                            <AntDesign name="checksquare" size={28} color={colors.successStrong || colors.success} />
                        )}
                    </View>
                </View>
            ))}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    groupListScroll: {
        flex: 1,
        width: '100%',
    },
    scrollContentContainer: {
        paddingBottom: spacing.md, 
    },
    emptyListContainer: {
        marginTop: spacing.xl,
        alignItems: 'center',
    },
    emptyListText: {
        fontSize: font.sizes.xl,
        color: colors.textLight + 'aa', // Adjusted for dark background
        fontStyle: 'italic',
    },
    groupListItem: {
        backgroundColor: colors.surface + '20', // Slightly transparent on dark bg
        borderRadius: borderRadius.md,
        paddingVertical: spacing.sm,
        paddingHorizontal: spacing.md,
        marginBottom: spacing.sm,
        flexDirection: 'row',
        alignItems: 'center',
        ...shadows.medium,
        borderLeftWidth: 6,
        borderLeftColor: colors.primary + '80', // More visible accent on dark bg
    },
    groupListItemActive: {
        backgroundColor: colors.primary + '40', // Brighter active state
        borderLeftColor: colors.accent, // Gold/Orange accent for active
    },
    athleteRankContainer: {
        width: 45,
        alignItems: 'center',
        marginRight: spacing.sm,
    },
    athleteRank: {
        fontSize: font.sizes.xl,
        fontWeight: font.weights.bold,
        color: colors.textLight, // Text on dark bg
    },
    athleteInfoContainer: {
        flex: 1,
        marginRight: spacing.sm,
    },
    athleteName: {
        fontSize: font.sizes['2xl'],
        fontWeight: font.weights.bold,
        color: colors.textLight, // Text on dark bg
        marginBottom: 2,
    },
    athleteClub: {
        fontSize: font.sizes.lg,
        color: colors.textLight + 'aa', // Lighter secondary text
    },
    attemptsRow: {
        flexDirection: 'row',
        alignItems: 'stretch',
    },
    attemptCellBase: {
        width: 100,
        minHeight: 60,
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: spacing.xs,
        paddingHorizontal: spacing.xxs,
        marginHorizontal: spacing.xs,
        borderRadius: borderRadius.md,
    },
    attemptCellDeclared: {
        backgroundColor: colors.surface + '15', // More subtle declared bg
    },
    attemptCellPassed: {
        backgroundColor: colors.success,
    },
    attemptCellFailed: {
        backgroundColor: colors.error,
    },
    attemptWeightBase: {
        fontSize: font.sizes['2xl'],
        fontWeight: font.weights.bold,
        marginBottom: spacing.xxs,
    },
    attemptWeightDeclaredText: {
        color: colors.textLight + 'dd', // Declared weight text color
    },
    attemptWeightResultText: {
        color: colors.white,
    },
    attemptStatusIcon: {
        // color is set directly in getStatusIcon
    },
    completedIndicator: {
        marginLeft: spacing.md,
        padding: spacing.xs,
        alignItems: 'center',
        justifyContent: 'center',
        width: 40,
    }
});

export default GroupAthleteList;