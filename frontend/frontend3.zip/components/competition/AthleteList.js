import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Platform, TextInput, ActivityIndicator } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme';

const AthleteList = ({
    athletes,
    currentAthleteOriginalIndex, // Używane do podświetlenia aktywnego zawodnika (z prawego panelu)
    currentRound,
    onSelectAthlete,
    onAttemptStatusChange,
    onWeightChange,
    isSaving // Globalny stan zapisywania z CompetitionScreen
}) => {
    const [hoveredAthlete, setHoveredAthlete] = useState(null);

    const getStatusIcon = (status, weight) => {
        const iconSize = 18;
        if (status === 'passed') return <AntDesign name="checkcircle" size={iconSize} color={colors.success} />;
        if (status === 'failed') return <AntDesign name="closecircle" size={iconSize} color={colors.error} />;
        if (weight && String(weight).trim() !== '' && String(weight).trim() !== '0') return <AntDesign name="clockcircleo" size={iconSize} color={colors.textSecondary} />;
        return <View style={{width: iconSize, height: iconSize}} />;
    };

    const handleWeightInput = (athleteOriginalIndex, attemptNo, text) => {
        const numericValue = text.replace(/[^0-9.]/g, '');
        if (onWeightChange) {
            onWeightChange(athleteOriginalIndex, attemptNo, numericValue);
        }
    };

    return (
        <View style={styles.athleteListContainer}>
            {athletes.length === 0 ? (
                <Text style={styles.emptyText}>Brak zawodników w tej kategorii/wadze.</Text>
            ) : (
                <ScrollView style={styles.athleteScroll}>
                    {athletes.map((athlete, index) => {
                        const isCurrentlySelectedAthlete = athlete.originalIndex === currentAthleteOriginalIndex;

                        return (
                            <View
                                key={athlete.originalIndex}
                                style={[
                                    styles.athleteListItem,
                                    isCurrentlySelectedAthlete && styles.athleteListItemActive,
                                    Platform.OS === 'web' && hoveredAthlete === athlete.originalIndex && styles.athleteListItemHover,
                                ]}
                                onMouseEnter={Platform.OS === 'web' ? () => setHoveredAthlete(athlete.originalIndex) : undefined}
                                onMouseLeave={Platform.OS === 'web' ? () => setHoveredAthlete(null) : undefined}
                            >
                                <TouchableOpacity onPress={() => {
                                    if (typeof onSelectAthlete === 'function') {
                                        onSelectAthlete(athlete.originalIndex);
                                    }
                                }}>
                                    <View style={styles.athleteInfoRow}>
                                        <Text style={styles.athleteListText}>
                                            {index + 1}. {athlete.imie} {athlete.nazwisko}
                                            <Text style={styles.athleteClubText}> ({athlete.klub || 'brak klubu'})</Text>
                                        </Text>
                                    </View>
                                </TouchableOpacity>

                                <View style={styles.attemptsGrid}>
                                    {[1, 2, 3].map((nr) => {
                                        const weight = athlete[`podejscie${nr}`];
                                        const status = athlete[`podejscie${nr}Status`];
                                        const isCurrentRoundAttempt = nr === currentRound;
                                        const canEditWeight = isCurrentRoundAttempt && !status && onWeightChange;
                                        const canSetStatus = isCurrentRoundAttempt && !status && onAttemptStatusChange;
                                        const isWeightDeclared = weight && String(weight).trim() !== '' && String(weight).trim() !== '0';

                                        return (
                                            <View key={nr} style={[styles.attemptCell, nr === 3 && { borderRightWidth: 0 }]}>
                                                <Text style={styles.attemptCellLabel}>P.{nr}</Text>
                                                {canEditWeight ? (
                                                    <TextInput
                                                        style={styles.attemptWeightInput}
                                                        value={String(weight || '')}
                                                        onChangeText={(text) => handleWeightInput(athlete.originalIndex, nr, text)}
                                                        keyboardType="numeric"
                                                        placeholder="kg"
                                                        editable={!isSaving}
                                                    />
                                                ) : (
                                                    <Text style={styles.attemptWeightText}>{weight || '-'} kg</Text>
                                                )}
                                                <View style={styles.attemptStatusIconContainer}>
                                                    {getStatusIcon(status, weight)}
                                                </View>
                                                {canSetStatus && (
                                                    <View style={styles.attemptActionButtons}>
                                                        <TouchableOpacity
                                                            style={[styles.actionButtonSmall, styles.passButtonSmall, (isSaving || !isWeightDeclared) && styles.actionButtonDisabledSmall]}
                                                            onPress={() => !isSaving && isWeightDeclared && onAttemptStatusChange(athlete.originalIndex, nr, 'passed')}
                                                            disabled={isSaving || !isWeightDeclared}
                                                        >
                                                            {(isSaving && isCurrentRoundAttempt) ? <ActivityIndicator size="small" color={colors.textLight} /> : <AntDesign name="check" size={14} color={colors.textLight} />}
                                                        </TouchableOpacity>
                                                        <TouchableOpacity
                                                            style={[styles.actionButtonSmall, styles.failButtonSmall, (isSaving || !isWeightDeclared) && styles.actionButtonDisabledSmall]}
                                                            onPress={() => !isSaving && isWeightDeclared && onAttemptStatusChange(athlete.originalIndex, nr, 'failed')}
                                                            disabled={isSaving || !isWeightDeclared}
                                                        >
                                                            {(isSaving && isCurrentRoundAttempt) ? <ActivityIndicator size="small" color={colors.textLight} /> : <AntDesign name="close" size={14} color={colors.textLight} />}
                                                        </TouchableOpacity>
                                                    </View>
                                                )}
                                            </View>
                                        );
                                    })}
                                </View>
                            </View>
                        );
                    })}
                </ScrollView>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    athleteListContainer: { marginTop: spacing.sm, flex: 1 },
    emptyText: { color: colors.textSecondary, fontStyle: 'italic', textAlign: 'center', marginTop: spacing.md },
    athleteScroll: {
        flex: 1,
        borderWidth: 1, borderColor: colors.borderLight, borderRadius: borderRadius.md,
        padding: spacing.xs,
    },
    athleteListItem: {
        padding: spacing.sm,
        marginBottom: spacing.sm,
        backgroundColor: colors.surface,
        borderRadius: borderRadius.md,
        borderWidth: 1,
        borderColor: colors.border,
        ...shadows.small,
    },
    athleteListItemActive: { // Podświetlenie zawodnika aktywnego w prawym panelu
        borderColor: colors.accent, // Użyj koloru akcentu
        backgroundColor: colors.accent + '1A',
        ...shadows.medium,
        shadowColor: colors.accent,
    },
    athleteListItemHover: { // Dla web
        borderColor: colors.primary,
        backgroundColor: colors.primary + '10',
        transform: [{ scale: 1.01 }],
    },
    athleteInfoRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: spacing.sm,
    },
    athleteListText: {
        fontSize: font.sizes.md,
        fontWeight: font.weights.semibold,
        color: colors.text,
        flex: 1,
    },
    athleteClubText: {
        fontSize: font.sizes.sm,
        fontWeight: font.weights.normal,
        color: colors.textSecondary,
    },
    attemptsGrid: {
        flexDirection: 'row',
        justifyContent: 'space-around',
    },
    attemptCell: {
        flex: 1,
        alignItems: 'center',
        paddingVertical: spacing.xs,
        paddingHorizontal: spacing.xxs,
        borderRightWidth: 1,
        borderRightColor: colors.borderLight,
    },
    attemptCellLabel: {
        fontSize: font.sizes.xs,
        color: colors.textSecondary,
        marginBottom: spacing.xxs,
        fontWeight: font.weights.medium,
    },
    attemptWeightInput: {
        fontSize: font.sizes.sm,
        fontWeight: font.weights.semibold,
        color: colors.text,
        borderBottomWidth: 1,
        borderColor: colors.primary,
        paddingVertical: Platform.OS === 'ios' ? spacing.xxs : 0,
        textAlign: 'center',
        minWidth: 40,
        maxWidth: 50,
        marginBottom: spacing.xxs,
    },
    attemptWeightText: {
        fontSize: font.sizes.sm,
        fontWeight: font.weights.semibold,
        color: colors.text,
        textAlign: 'center',
        minWidth: 40,
        maxWidth: 50,
        marginBottom: spacing.xxs,
    },
    attemptStatusIconContainer: {
        height: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: spacing.xxs,
    },
    attemptActionButtons: {
        flexDirection: 'row',
        gap: spacing.xs,
        marginTop: spacing.xxs,
    },
    actionButtonSmall: {
        padding: spacing.xs,
        borderRadius: borderRadius.sm,
        alignItems: 'center',
        justifyContent: 'center',
    },
    actionButtonDisabledSmall: {
        backgroundColor: colors.border,
        opacity: 0.7,
    },
    passButtonSmall: { backgroundColor: colors.success },
    failButtonSmall: { backgroundColor: colors.error },
});

export default AthleteList;