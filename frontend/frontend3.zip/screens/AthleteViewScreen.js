import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react'; // Dodano useCallback
import { View, Text } from 'react-native';
import { useCompetitionStore } from '../store/useCompetitionStore';
import AttemptResultAnimation from '../components/competition/AttemptResultAnimation';
import AttemptDisplay from '../components/athleteView/AttemptDisplay';
import AthleteViewTimerDisplay from '../components/athleteView/AthleteViewTimerDisplay';
import GroupAthleteList from '../components/athleteView/GroupAthleteList';
import { styles } from '../styles/AthleteViewStyles/AthleteViewScreen.styles';
import { font, spacing } from '../theme/theme';

const hasAthleteCompletedAll = (athlete) => {
  return !!(athlete.podejscie1Status && athlete.podejscie2Status && athlete.podejscie3Status);
};

export default function AthleteViewScreen() {
    const {
        zawodnicy, activeCategory, activeWeight,
        activeAthleteOriginalIndex, activeAttemptNr,
        timerActive, timerTimeLeft,
        socket,
        setTimerTimeLeft: storeSetTimerTimeLeft,
        attemptResultForAnimation,
        clearAttemptResultForAnimation
    } = useCompetitionStore(state => ({
        zawodnicy: state.zawodnicy,
        activeCategory: state.activeCategory,
        activeWeight: state.activeWeight,
        activeAthleteOriginalIndex: state.activeAthleteOriginalIndex,
        activeAttemptNr: state.activeAttemptNr,
        timerActive: state.timerActive,
        timerTimeLeft: state.timerTimeLeft,
        socket: state.socket,
        setTimerTimeLeft: state.setTimerTimeLeft,
        attemptResultForAnimation: state.attemptResultForAnimation,
        clearAttemptResultForAnimation: state.clearAttemptResultForAnimation
    }));

    const [showAnimationOverlay, setShowAnimationOverlay] = useState(false);
    const [animationSuccess, setAnimationSuccess] = useState(false);
    const animationTimeoutRef = useRef(null);

    // Funkcja wyzwalająca animację, opakowana w useCallback
    const triggerAnimation = useCallback((successStatus) => {
        console.log('[AthleteViewScreen] triggerAnimation called with success:', successStatus);
        setAnimationSuccess(successStatus);
        setShowAnimationOverlay(true);
        if (animationTimeoutRef.current) clearTimeout(animationTimeoutRef.current);
        animationTimeoutRef.current = setTimeout(() => {
            console.log('[AthleteViewScreen] Animation Timeout. Hiding overlay.');
            setShowAnimationOverlay(false);
            // Czyść stan w store niezależnie od tego, jak animacja została wyzwolona
            clearAttemptResultForAnimation();
        }, 2000); // Czas trwania animacji
    }, [clearAttemptResultForAnimation]); // Zależność od clearAttemptResultForAnimation

    useEffect(() => {
        console.log('[AthleteViewScreen] useEffect for Sockets - Socket available:', !!socket);
        if (!socket) {
            console.log('[AthleteViewScreen] Socket not available, returning from useEffect for sockets.');
            return;
        }

        const handleTimerStarted = (data) => {
            console.log('[AthleteViewScreen] Socket event: timerStarted RECEIVED. Data:', data);
            if (data && typeof data.timeLeft === 'number') {
                console.log(`[AthleteViewScreen] Socket event: timerStarted. Setting timerTimeLeft to: ${data.timeLeft}`);
                storeSetTimerTimeLeft(data.timeLeft);
            } else {
                 console.log(`[AthleteViewScreen] Socket event: timerStarted. timeLeft not in data, relying on initial store state or timerTick.`);
            }
        };

        const handleTimerStopped = (data) => {
            console.log('[AthleteViewScreen] Socket event: timerStopped RECEIVED. Data:', data);
            if (data && typeof data.finalTimeLeft === 'number') {
                console.log(`[AthleteViewScreen] Socket event: timerStopped. Setting timerTimeLeft to: ${data.finalTimeLeft}`);
                storeSetTimerTimeLeft(data.finalTimeLeft);
            } else {
                console.warn('[AthleteViewScreen] Socket event: timerStopped. finalTimeLeft not provided or invalid in data. Setting to 0.');
                storeSetTimerTimeLeft(0);
            }
        };

        const handleTimerTick = (data) => {
            if (data && typeof data.timeLeft === 'number') {
                storeSetTimerTimeLeft(data.timeLeft);
            }
        };
        
        const handleTimerReset = (data) => { // Dodano obsługę timerReset
            console.log('[AthleteViewScreen] Socket event: timerReset RECEIVED. Data:', data);
            if (data && typeof data.timeLeft === 'number') {
                storeSetTimerTimeLeft(data.timeLeft);
            } else {
                storeSetTimerTimeLeft(60); // MAX_TIMER_SECONDS
            }
        };

        // NOWY LISTENER DLA ANIMACJI
        const handleAttemptAnimationTriggered = (data) => {
            console.log('[AthleteViewScreen] Socket event: attemptAnimationTriggered RECEIVED. Data:', data);
            if (data && typeof data.success === 'boolean') {
                triggerAnimation(data.success);
            }
        };

        console.log('[AthleteViewScreen] Attaching socket listeners: timerStarted, timerStopped, timerTick, timerReset, attemptAnimationTriggered');
        socket.on('timerStarted', handleTimerStarted);
        socket.on('timerStopped', handleTimerStopped);
        socket.on('timerTick', handleTimerTick);
        socket.on('timerReset', handleTimerReset);
        socket.on('attemptAnimationTriggered', handleAttemptAnimationTriggered); // DODANO NASŁUCHIWANIE

        return () => {
            console.log('[AthleteViewScreen] Detaching socket listeners: timerStarted, timerStopped, timerTick, timerReset, attemptAnimationTriggered');
            socket.off('timerStarted', handleTimerStarted);
            socket.off('timerStopped', handleTimerStopped);
            socket.off('timerTick', handleTimerTick);
            socket.off('timerReset', handleTimerReset);
            socket.off('attemptAnimationTriggered', handleAttemptAnimationTriggered); // DODANO ODPINANIE
        };
    }, [socket, storeSetTimerTimeLeft, triggerAnimation]); // Dodano triggerAnimation do zależności

    useEffect(() => {
        // Ten efekt obsługuje animację wyzwalaną przez lokalny stan store
        // (głównie dla klienta, który zainicjował akcję, lub jako fallback)
        console.log('[AthleteViewScreen] useEffect for local store animation. attemptResultForAnimation:', attemptResultForAnimation);
        if (attemptResultForAnimation && typeof attemptResultForAnimation.success === 'boolean') {
            triggerAnimation(attemptResultForAnimation.success);
        }
        // Cleanup dla animationTimeoutRef.current i clearAttemptResultForAnimation jest obsługiwany wewnątrz triggerAnimation
    }, [attemptResultForAnimation, triggerAnimation]); // Dodano triggerAnimation do zależności

    const currentAthlete = useMemo(() => {
        if (activeAthleteOriginalIndex === null || !zawodnicy || zawodnicy.length === 0) return null;
        return zawodnicy[activeAthleteOriginalIndex];
    }, [zawodnicy, activeAthleteOriginalIndex]);

    useEffect(() => {
        console.log(`[AthleteViewScreen] Store Update: activeCategory: ${activeCategory}, activeWeight: ${activeWeight}, activeAthleteOriginalIndex: ${activeAthleteOriginalIndex}, activeAttemptNr: ${activeAttemptNr}`);
        if (currentAthlete) {
            console.log(`[AthleteViewScreen] Current Athlete: ${currentAthlete.imie} ${currentAthlete.nazwisko}, Attempt ${activeAttemptNr} Status: ${currentAthlete['podejscie' + activeAttemptNr + 'Status']}`);
        } else {
            console.log('[AthleteViewScreen] No current athlete.');
        }
    }, [activeCategory, activeWeight, activeAthleteOriginalIndex, activeAttemptNr, currentAthlete, zawodnicy]);

    const groupAthletes = useMemo(() => {
        if (!activeCategory || !activeWeight || !zawodnicy) return [];
        return zawodnicy
            .map((z, index) => ({ ...z, originalIndex: index, isCompleted: hasAthleteCompletedAll(z) }))
            .filter(z => z.kategoria === activeCategory && z.waga === activeWeight)
            .sort((a, b) => {
                if (a.isCompleted !== b.isCompleted) {
                    return a.isCompleted ? 1 : -1; // Ukończone na końcu
                }
                // Sortuj wg podejścia 1, jeśli nieukończone
                const weightA = Number(a.podejscie1) || Infinity; // Niezadeklarowane lub 0 traktuj jako nieskończoność (na końcu)
                const weightB = Number(b.podejscie1) || Infinity;
                return weightA - weightB;
            });
    }, [zawodnicy, activeCategory, activeWeight]);

    const nextAthleteData = useMemo(() => {
        if (!currentAthlete || groupAthletes.length <= 1) return null;
        const currentIndexInGroup = groupAthletes.findIndex(a => a.originalIndex === currentAthlete.originalIndex);
        if (currentIndexInGroup === -1 || currentIndexInGroup === groupAthletes.length - 1) return null;
        
        const nextAthlete = groupAthletes[currentIndexInGroup + 1];
        if (!nextAthlete || nextAthlete.isCompleted) return null; // Jeśli następny ukończył, nie pokazuj

        let nextAthleteAttemptNr = 1;
        if (!nextAthlete.podejscie1Status) nextAthleteAttemptNr = 1;
        else if (!nextAthlete.podejscie2Status) nextAthleteAttemptNr = 2;
        else if (!nextAthlete.podejscie3Status) nextAthleteAttemptNr = 3;
        else return null; // Wszystkie podejścia mają status

        const declaredWeight = nextAthlete[`podejscie${nextAthleteAttemptNr}`];
        return {
            name: `${nextAthlete.imie} ${nextAthlete.nazwisko}`,
            club: nextAthlete.klub || 'Brak klubu',
            attemptInfo: `Podejście ${nextAthleteAttemptNr}: ${declaredWeight || '?'} kg`
        };
    }, [currentAthlete, groupAthletes]);

    const renderGroupHeader = () => {
        if (activeCategory && activeWeight && activeAthleteOriginalIndex === null) {
            return (
                <View style={styles.groupHeader}>
                    <Text style={styles.groupHeaderTitle}>{activeCategory}</Text>
                    <Text style={styles.groupHeaderSubtitle}>Kategoria Wagowa: {activeWeight} kg</Text>
                </View>
            );
        }
        return null;
    };

    return (
        <View style={styles.container}>
            {renderGroupHeader()}
            <View style={styles.mainContent}> 
                {activeAthleteOriginalIndex !== null && currentAthlete ? (
                    <View style={styles.athleteDetailContainer}>
                        <View style={styles.athleteInfoCard}>
                            <Text style={styles.athleteName}>
                                <Text style={styles.athleteNameHighlight}>{currentAthlete.imie} {currentAthlete.nazwisko}</Text>
                            </Text>
                            <Text style={styles.athleteClub}>{currentAthlete.klub || 'Brak klubu'}</Text>
                            <Text style={styles.athleteCategory}>
                                Kat: <Text style={styles.categoryValueHighlight}>{currentAthlete.kategoria}</Text> / Waga: <Text style={styles.weightValueHighlight}>{currentAthlete.waga} kg</Text>
                            </Text>
                        </View>
                        <View style={styles.attemptsContainer}>
                            {[1, 2, 3].map((nr) => (
                                <AttemptDisplay
                                    key={nr}
                                    number={nr}
                                    weight={currentAthlete[`podejscie${nr}`]}
                                    status={currentAthlete[`podejscie${nr}Status`]}
                                    isActive={activeAttemptNr === nr}
                                />
                            ))}
                        </View>
                        <View style={styles.timerSection}>
                             <Text style={styles.sectionTitle}>Czas</Text>
                             <AthleteViewTimerDisplay isActive={timerActive} timeLeft={timerTimeLeft} />
                        </View>
                        {nextAthleteData && (
                            <View style={styles.nextUpContainer}>
                                <Text style={styles.nextUpTitle}>Następny Zawodnik</Text>
                                <Text style={styles.nextUpAthleteName}>{nextAthleteData.name}</Text>
                                <Text style={styles.nextUpAthleteInfo}>{nextAthleteData.club}</Text>
                                <Text style={styles.nextUpAthleteInfo}>{nextAthleteData.attemptInfo}</Text>
                            </View>
                        )}
                    </View>
                ) : activeCategory && activeWeight ? (
                     <View style={styles.groupViewContainer}>
                         <GroupAthleteList
                            athletes={groupAthletes}
                            currentAthleteOriginalIndex={activeAthleteOriginalIndex}
                         />
                    </View>
                ) : (
                    <View style={styles.placeholderContainer}>
                        <Text style={styles.placeholderText}>Wybierz kategorię i wagę w panelu sędziego, aby zobaczyć listę zawodników.</Text>
                        <Text style={[styles.placeholderText, {fontSize: font.sizes['5xl'] || 48, marginTop: spacing.lg}]}>🏆</Text>
                    </View>
                )}
            </View>
            {showAnimationOverlay && (
                <View style={styles.animationOverlay}>
                    <AttemptResultAnimation success={animationSuccess} />
                </View>
            )}
        </View>
    );
}