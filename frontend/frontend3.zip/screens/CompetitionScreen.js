import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { ScrollView, View, Text, TouchableOpacity, Alert, ActivityIndicator, Platform, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { useCompetitionStore } from '../store/useCompetitionStore';
import { saveAppData } from '../utils/api';
import NavBar from '../components/navigation/NavBar';
import Footer from '../components/navigation/Footer';
import OptionSelector from '../components/competition/OptionSelector';
import AthleteList from '../components/competition/AthleteList';
import CurrentAthleteManager from '../components/competition/CurrentAthleteManager';
import TimerDisplay from '../components/competition/TimerDisplay';
import AttemptResultAnimation from '../components/competition/AttemptResultAnimation';
import { styles } from '../styles/CompetitionStyles/CompetitionScreen.styles';
import { colors, spacing } from '../theme/theme'; // Import colors and spacing for direct use if needed

// Helper functions (should be at the top or in a separate utils file)
const MAX_TIMER_SECONDS = 60;

const getAthleteDeclaredWeightForRound = (athlete, round) => {
    if (!athlete) return 0;
    const weightStr = athlete[`podejscie${round}`];
    return parseFloat(String(weightStr).replace(',', '.')) || 0;
};

const hasAthleteCompletedAttemptInRound = (athlete, round) => {
    if (!athlete) return false;
    return !!athlete[`podejscie${round}Status`];
};

const hasAthleteCompleted = (athlete) => {
    if (!athlete) return false;
    return !!(athlete.podejscie1Status && athlete.podejscie2Status && athlete.podejscie3Status);
};


const ResetTimerButton = ({ onPress, disabled }) => {
  return (
    <TouchableOpacity
      style={[styles.secondaryActionButton, disabled && styles.actionButtonDisabled]}
      onPress={onPress}
      disabled={disabled}
    >
      <Text style={styles.secondaryActionButtonText}>Resetuj Timer</Text>
    </TouchableOpacity>
  );
};

export default function CompetitionScreen() {
  const navigation = useNavigation();
  const {
    zawody, kategorie, zawodnicy,
    activeCategory, activeWeight, activeAthleteOriginalIndex, activeAttemptNr,
    currentRound,
    updatePodejscieStatus, updatePodejscieWaga,
    setActiveGroup, setActiveAthlete,
    setCurrentRound,
    setTimerActive, setTimerTimeLeft,
    socket,
    setAttemptResultForAnimation,
    get, // Import 'get' for direct state access in callbacks
  } = useCompetitionStore(state => ({
      zawody: state.zawody,
      kategorie: state.kategorie,
      zawodnicy: state.zawodnicy,
      activeCategory: state.activeCategory,
      activeWeight: state.activeWeight,
      activeAthleteOriginalIndex: state.activeAthleteOriginalIndex,
      activeAttemptNr: state.activeAttemptNr,
      currentRound: state.currentRound,
      updatePodejscieStatus: state.updatePodejscieStatus,
      updatePodejscieWaga: state.updatePodejscieWaga,
      setActiveGroup: state.setActiveGroup,
      setActiveAthlete: state.setActiveAthlete,
      setCurrentRound: state.setCurrentRound,
      setTimerActive: state.setTimerActive,
      setTimerTimeLeft: state.setTimerTimeLeft,
      socket: state.socket,
      setAttemptResultForAnimation: state.setAttemptResultForAnimation,
      get: state.get, // Expose get for direct state access
  }));

  const timerActive = useCompetitionStore(state => state.timerActive);
  const timerTimeLeft = useCompetitionStore(state => state.timerTimeLeft);

  const [isSaving, setIsSaving] = useState(false);
  const [headerKlubAvatarDimensions, setHeaderKlubAvatarDimensions] = useState(null);
  const [headerJudgeAvatarDimensions, setHeaderJudgeAvatarDimensions] = useState(null);
  const timerIntervalRef = useRef(null);

  const [showAttemptAnimation, setShowAttemptAnimation] = useState(false);
  const [attemptAnimationSuccess, setAttemptAnimationSuccess] = useState(false);
  const animationTimeoutRef = useRef(null);

  const syncData = useCallback(async (dataToSync) => {
    setIsSaving(true);
    try {
      const currentState = useCompetitionStore.getState();
      const { socket: currentSocket, attemptResultForAnimation: currentAnimation, ...restOfState } = currentState;
      
      let dataToSend = { ...restOfState };

      if (dataToSync && typeof dataToSync === 'object') {
        dataToSend = { ...dataToSend, ...dataToSync };
      }
      
      console.log('[CompetitionScreen] Syncing data:', dataToSend);
      await saveAppData(dataToSend);
    } catch (error) {
      console.error('[CompetitionScreen] Błąd synchronizacji danych:', error);
      Alert.alert("Błąd", "Nie udało się zsynchronizować danych z serwerem.");
    } finally {
      setIsSaving(false);
    }
  }, [setIsSaving]);

  const stableSetTimerTimeLeft = useCallback((value) => setTimerTimeLeft(value), [setTimerTimeLeft]);
  const stableSetTimerActive = useCallback((value) => setTimerActive(value), [setTimerActive]);

  const handleResetTimer = useCallback(async () => {
    if (isSaving || showAttemptAnimation) {
        Alert.alert("Uwaga", "Nie można zresetować timera podczas zapisu lub animacji.");
        return;
    }
    console.log(`[CompetitionScreen] Resetting timer.`);
    stableSetTimerActive(false);
    stableSetTimerTimeLeft(MAX_TIMER_SECONDS);

    if (socket && socket.connected) {
      socket.emit('timerReset', { timeLeft: MAX_TIMER_SECONDS });
    }
    // Sync is not strictly necessary on reset, but can be added if needed
    // await syncData({ timerActive: false, timerTimeLeft: MAX_TIMER_SECONDS });
  }, [isSaving, showAttemptAnimation, stableSetTimerActive, stableSetTimerTimeLeft, socket]);

  const handleSelectAthlete = useCallback(async (selectedAthleteOriginalIndex) => {
    console.log(`[CompetitionScreen] handleSelectAthlete called for index: ${selectedAthleteOriginalIndex}`);
    if (timerActive) {
      Alert.alert("Timer Aktywny", "Nie można zmienić zawodnika podczas aktywnego czasu.");
      return;
    }
    if (isSaving) {
        console.warn('[CompetitionScreen] handleSelectAthlete: Save in progress. Skipping.');
        return;
    }
    setActiveAthlete(selectedAthleteOriginalIndex);
    // activeAttemptNr is set to currentRound by setActiveAthlete action
    await syncData({ activeAthleteOriginalIndex: selectedAthleteOriginalIndex, activeAttemptNr: get().currentRound });
  }, [setActiveAthlete, syncData, timerActive, isSaving, get]);

  const handleTimerFinish = useCallback(() => {
    console.log('[CompetitionScreen] handleTimerFinish called.');
    stableSetTimerActive(false);
    stableSetTimerTimeLeft(0); 

    if (socket && socket.connected) {
      socket.emit('stopTimer', { finalTimeLeft: 0, reason: 'natural_finish' });
    }

    const currentStoreState = useCompetitionStore.getState();
    if (currentStoreState.activeAthleteOriginalIndex !== null && currentStoreState.activeAttemptNr) {
        const athlete = currentStoreState.zawodnicy[currentStoreState.activeAthleteOriginalIndex];
        if (athlete && !athlete[`podejscie${currentStoreState.activeAttemptNr}Status`]) {
            console.log(`[CompetitionScreen] Timer finished, marking attempt ${currentStoreState.activeAttemptNr} as failed for athlete ${currentStoreState.activeAthleteOriginalIndex}`);
            // For now, let judge decide. If auto-fail is needed, call:
            // handleAttemptStatusChange(currentStoreState.activeAthleteOriginalIndex, currentStoreState.activeAttemptNr, 'failed');
        }
    }
  }, [stableSetTimerActive, stableSetTimerTimeLeft, socket]); 

  useEffect(() => {
    const currentTimerActive = useCompetitionStore.getState().timerActive;

    if (currentTimerActive) {
      console.log('[CompetitionScreen] LOG G: useEffect - timerActive TRUE. Setting up interval.');
      timerIntervalRef.current = setInterval(() => {
        const currentTimeInStore = useCompetitionStore.getState().timerTimeLeft;

        if (typeof currentTimeInStore !== 'number' || isNaN(currentTimeInStore)) {
          console.error(`[CompetitionScreen] Interval: timerTimeLeft is not a number: ${currentTimeInStore}. Resetting to MAX_TIMER_SECONDS.`);
          stableSetTimerTimeLeft(MAX_TIMER_SECONDS); 
          return; 
        }

        const newTime = currentTimeInStore - 1;
        stableSetTimerTimeLeft(newTime); 

        if (socket && socket.connected) {
          socket.emit('timerTick', { timeLeft: newTime });
        }

        if (newTime <= 0) {
          console.log('[CompetitionScreen] LOG H: useEffect - newTime <= 0. Clearing interval, calling handleTimerFinish.');
          clearInterval(timerIntervalRef.current);
          timerIntervalRef.current = null;
          handleTimerFinish(); 
        }
      }, 1000);
    } else {
      console.log('[CompetitionScreen] LOG I: useEffect - timerActive FALSE. Clearing interval if it exists.');
      if (timerIntervalRef.current) {
        console.log('[CompetitionScreen] LOG J: useEffect - interval cleared.');
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    };
  }, [timerActive, stableSetTimerActive, stableSetTimerTimeLeft, socket, handleTimerFinish]); 

  const athletesInCurrentGroup = useMemo(() => {
    if (!activeCategory || !activeWeight || !zawodnicy) return [];
    return zawodnicy
      .map((z, index) => ({ ...z, originalIndex: index }))
      .filter(z => z.kategoria === activeCategory && z.waga === activeWeight);
  }, [zawodnicy, activeCategory, activeWeight]);

  const upcomingAthletesForCurrentRound = useMemo(() => {
    if (!activeCategory || !activeWeight || currentRound > 3) return [];
    return athletesInCurrentGroup
      .filter(athlete => !hasAthleteCompletedAttemptInRound(athlete, currentRound))
      .sort((a, b) => {
        const weightA = getAthleteDeclaredWeightForRound(a, currentRound);
        const weightB = getAthleteDeclaredWeightForRound(b, currentRound);
        if (weightA === weightB) return a.originalIndex - b.originalIndex; // Maintain original order for same weights
        return weightA - weightB;
      });
  }, [athletesInCurrentGroup, currentRound, activeCategory, activeWeight]);

  const currentAthlete = useMemo(() => {
    if (activeAthleteOriginalIndex === null || !zawodnicy || zawodnicy.length === 0) return null;
    return zawodnicy[activeAthleteOriginalIndex];
  }, [zawodnicy, activeAthleteOriginalIndex]);

  const handleNextCompetitor = useCallback(async () => {
    console.log(`[CompetitionScreen] handleNextCompetitor called. Current round: ${currentRound}`);
    if (timerActive || isSaving || showAttemptAnimation) {
      Alert.alert("Uwaga", "Nie można zmienić zawodnika podczas aktywnego timera, zapisu lub animacji.");
      return;
    }
    if (!activeCategory || !activeWeight) {
      Alert.alert("Informacja", "Wybierz najpierw kategorię i wagę.");
      return;
    }

    const nextAthletesInCurrentList = upcomingAthletesForCurrentRound;

    if (nextAthletesInCurrentList.length > 0) {
      const nextAthleteToCall = nextAthletesInCurrentList[0];
      console.log(`[CompetitionScreen] Advancing to next competitor: ${nextAthleteToCall.imie} ${nextAthleteToCall.nazwisko} (Index: ${nextAthleteToCall.originalIndex})`);
      setActiveAthlete(nextAthleteToCall.originalIndex);
      await syncData({ activeAthleteOriginalIndex: nextAthleteToCall.originalIndex, activeAttemptNr: currentRound });
    } else {
      console.log('[CompetitionScreen] No more upcoming athletes in the current round for this group.');
      Alert.alert("Informacja", "Brak kolejnych zawodników w tej rundzie dla wybranej grupy.");
    }
  }, [currentRound, timerActive, isSaving, showAttemptAnimation, upcomingAthletesForCurrentRound, setActiveAthlete, syncData, activeCategory, activeWeight]);

  const handlePreviousRound = useCallback(async () => {
    if (isSaving || timerActive || showAttemptAnimation) {
      Alert.alert("Uwaga", "Nie można zmienić rundy podczas zapisu, aktywnego timera lub animacji.");
      return;
    }
    if (currentRound > 1) {
      const prevRound = currentRound - 1;
      console.log(`[CompetitionScreen] Changing to previous round: ${prevRound}`);
      setCurrentRound(prevRound); 
      await syncData({ currentRound: prevRound, activeAthleteOriginalIndex: null, activeAttemptNr: prevRound });
    } else {
      Alert.alert("Informacja", "Jesteś już na pierwszej rundzie.");
    }
  }, [currentRound, setCurrentRound, syncData, isSaving, timerActive, showAttemptAnimation]);

  const handleNextRound = useCallback(async () => {
    if (isSaving || timerActive || showAttemptAnimation) {
      Alert.alert("Uwaga", "Nie można zmienić rundy podczas zapisu, aktywnego timera lub animacji.");
      return;
    }
    if (currentRound < 3) {
      const nextRound = currentRound + 1;
      console.log(`[CompetitionScreen] Changing to next round: ${nextRound}`);
      setCurrentRound(nextRound); 
      await syncData({ currentRound: nextRound, activeAthleteOriginalIndex: null, activeAttemptNr: nextRound });
    } else {
      Alert.alert("Informacja", "Jesteś już na ostatniej, trzeciej rundzie.");
    }
  }, [currentRound, setCurrentRound, syncData, isSaving, timerActive, showAttemptAnimation]);
  
  useEffect(() => {
    if (activeAthleteOriginalIndex === null && upcomingAthletesForCurrentRound.length > 0 && !timerActive && !showAttemptAnimation && activeCategory && activeWeight) {
      console.log("[CompetitionScreen] useEffect: No active athlete, attempting to select first in current round.");
      handleNextCompetitor();
    }
  }, [activeAthleteOriginalIndex, upcomingAthletesForCurrentRound, timerActive, showAttemptAnimation, activeCategory, activeWeight, handleNextCompetitor]);

  const handleAttemptStatusChange = useCallback(async (athleteOriginalIndex, attemptNo, status) => {
    console.log(`[CompetitionScreen] handleAttemptStatusChange: AthleteIdx: ${athleteOriginalIndex}, Attempt: ${attemptNo}, Status: ${status}`);
    if (isSaving) {
      console.warn('[CompetitionScreen] handleAttemptStatusChange: Save in progress. Skipping.');
      return;
    }
    setIsSaving(true);
    setShowAttemptAnimation(true); 
    setAttemptAnimationSuccess(status === 'passed');

    updatePodejscieStatus(athleteOriginalIndex, attemptNo, status);

    const animationData = { success: status === 'passed' };
    setAttemptResultForAnimation(animationData); 
    
    if (socket && socket.connected) {
      console.log('[CompetitionScreen] Emitting triggerAttemptAnimation event:', animationData);
      socket.emit('triggerAttemptAnimation', animationData);
    }

    const currentStoreTimerActive = useCompetitionStore.getState().timerActive;
    const currentStoreTimerTimeLeft = useCompetitionStore.getState().timerTimeLeft;
    const currentStoreActiveAthleteOriginalIndex = useCompetitionStore.getState().activeAthleteOriginalIndex;
    const currentStoreActiveAttemptNr = useCompetitionStore.getState().activeAttemptNr;

    if (currentStoreTimerActive && currentStoreActiveAthleteOriginalIndex === athleteOriginalIndex && currentStoreActiveAttemptNr === attemptNo) {
        console.warn("[CompetitionScreen] handleAttemptStatusChange: Timer active for this attempt. Stopping it.");
        stableSetTimerActive(false);
        if (socket && socket.connected) {
            socket.emit('stopTimer', { finalTimeLeft: currentStoreTimerTimeLeft, reason: 'attempt_completed' });
        }
    }
    
    animationTimeoutRef.current = setTimeout(async () => {
        setShowAttemptAnimation(false); 
        await handleNextCompetitor(); 
        setIsSaving(false); 
    }, 2000);

    if (socket && socket.connected) {
      socket.emit('attemptUpdated', { athleteOriginalIndex, attemptNo, status });
    }
    
    const finalStateForSync = (({ socket: s, attemptResultForAnimation: a, ...rest }) => rest)(useCompetitionStore.getState());
    await syncData(finalStateForSync);

    console.log('[CompetitionScreen] handleAttemptStatusChange: Finished (animation triggered).');
  }, [
    isSaving, 
    stableSetTimerActive, 
    updatePodejscieStatus, 
    handleNextCompetitor, 
    socket, 
    setAttemptResultForAnimation,
    syncData 
  ]);

  const handleWeightChange = useCallback(async (athleteOriginalIndex, attemptNo, weight) => {
    if (isSaving) {
      console.warn('[CompetitionScreen] handleWeightChange: Save in progress. Skipping.');
      return;
    }
    console.log(`[CompetitionScreen] handleWeightChange: AthleteIdx: ${athleteOriginalIndex}, Attempt: ${attemptNo}, Weight: ${weight}`);
    setIsSaving(true);
    updatePodejscieWaga(athleteOriginalIndex, attemptNo, weight);

    if (socket && socket.connected) {
      socket.emit('weightUpdated', { athleteOriginalIndex, attemptNo, weight });
    }
    await syncData();
    setIsSaving(false);
    console.log('[CompetitionScreen] handleWeightChange: Finished.');
  }, [isSaving, updatePodejscieWaga, syncData, socket]);

  const handleStartOrRestartAttempt = () => {
    if (!currentAthlete || isSaving || showAttemptAnimation) {
        console.log(`[CompetitionScreen] Cannot start/restart: no current athlete, saving, or animation active.`);
        return;
    }
    const storeCurrentRound = useCompetitionStore.getState().currentRound;
    const storeActiveAttemptNr = useCompetitionStore.getState().activeAttemptNr;

    if (storeActiveAttemptNr !== storeCurrentRound) {
        Alert.alert("Uwaga", `Próbujesz uruchomić timer dla podejścia ${storeActiveAttemptNr}, ale aktualna runda to ${storeCurrentRound}. Zmień rundę lub zawodnika.`);
        return;
    }
    const newInitialTime = MAX_TIMER_SECONDS;
    stableSetTimerTimeLeft(newInitialTime);
    stableSetTimerActive(true);
    if (socket && socket.connected) {
      const storeActiveAthleteOriginalIndex = useCompetitionStore.getState().activeAthleteOriginalIndex;
      socket.emit('startTimer', { timeLeft: newInitialTime, athleteId: storeActiveAthleteOriginalIndex, attemptNr: storeActiveAttemptNr });
    }
  };
  
  const handleResumeTimer = () => {
    if (!currentAthlete || isSaving || showAttemptAnimation) {
      console.log(`[CompetitionScreen] Cannot resume: no current athlete, saving, or animation active.`);
      return;
    }
    const currentValFromStore = useCompetitionStore.getState().timerTimeLeft;
    if (currentValFromStore > 0 && currentValFromStore < MAX_TIMER_SECONDS) {
      stableSetTimerActive(true);
      if (socket && socket.connected) {
        const storeActiveAthleteOriginalIndex = useCompetitionStore.getState().activeAthleteOriginalIndex;
        const storeActiveAttemptNr = useCompetitionStore.getState().activeAttemptNr;
        console.log(`[CompetitionScreen] Resuming timer with timeLeft: ${currentValFromStore}`);
        socket.emit('startTimer', { timeLeft: currentValFromStore, athleteId: storeActiveAthleteOriginalIndex, attemptNr: storeActiveAttemptNr, isResuming: true });
      }
    } else {
      console.log(`[CompetitionScreen] Cannot resume timer, timeLeft is not in valid range: ${currentValFromStore}`);
    }
  };

  const handleSelectCategory = useCallback(async (category) => {
    console.log(`[CompetitionScreen] Category selected: ${category}`);
    setActiveGroup(category, null); 
    await syncData({ activeCategory: category, activeWeight: null, activeAthleteOriginalIndex: null, currentRound: 1, activeAttemptNr: 1 });
  }, [setActiveGroup, syncData]);

  const handleSelectWeight = useCallback(async (weight) => {
    if (!activeCategory) {
      Alert.alert("Błąd", "Najpierw wybierz kategorię.");
      return;
    }
    console.log(`[CompetitionScreen] Weight selected: ${weight} for category: ${activeCategory}`);
    setActiveGroup(activeCategory, weight);
    await syncData({ activeWeight: weight, activeAthleteOriginalIndex: null, currentRound: 1, activeAttemptNr: 1 });
  }, [activeCategory, setActiveGroup, syncData]);

  const categoryOptions = useMemo(() => kategorie.map(k => ({ label: k.nazwa, value: k.nazwa })), [kategorie]);
  const activeCategoryObject = useMemo(() => kategorie.find(k => k.nazwa === activeCategory), [kategorie, activeCategory]);
  
  const completedWeights = useMemo(() => {
    const completed = new Set();
      if (!activeCategoryObject || !zawodnicy) return completed;
      activeCategoryObject.wagi.forEach(waga => {
          const athletesInGroup = zawodnicy.filter(z => z.kategoria === activeCategory && z.waga === waga);
          if (athletesInGroup.length > 0 && athletesInGroup.every(hasAthleteCompleted)) completed.add(waga);
      });
      return completed;
  }, [activeCategoryObject, zawodnicy, activeCategory]);

  const weightOptions = useMemo(() => {
    if (!activeCategoryObject) return [];
    return [...activeCategoryObject.wagi].sort((a, b) => Number(a) - Number(b)).map(w => ({
        label: String(w), value: w, isCompleted: completedWeights.has(w)
    }));
  }, [activeCategoryObject, completedWeights]);

  const displayAthletesInGroup = useMemo(() => {
    if (!athletesInCurrentGroup) return [];
    return [...athletesInCurrentGroup].sort((a, b) => { 
        const weightA = getAthleteDeclaredWeightForRound(a, currentRound);
        const weightB = getAthleteDeclaredWeightForRound(b, currentRound);
        if (weightA === weightB) return a.originalIndex - b.originalIndex;
        return weightA - weightB;
    });
  }, [athletesInCurrentGroup, currentRound]);
  
  const ResetButtonComponent = (
    <ResetTimerButton
      onPress={handleResetTimer}
      disabled={isSaving || showAttemptAnimation}
    />
  );

  let TimerButtonComponent = null;
  const currentTimerTimeLeft = useCompetitionStore.getState().timerTimeLeft;

  if (timerActive) {
    TimerButtonComponent = (
      <TouchableOpacity
        style={[styles.mainActionButton, styles.stopButton, (isSaving || showAttemptAnimation) && styles.actionButtonDisabled]}
        onPress={() => {
          const currentValFromStore = useCompetitionStore.getState().timerTimeLeft;
          console.log('[CompetitionScreen] Stop Czas button pressed. Current timeLeft from store:', currentValFromStore);
          stableSetTimerActive(false);
          if (socket && socket.connected) {
              socket.emit('stopTimer', { finalTimeLeft: currentValFromStore, reason: 'manual_stop' });
          }
        }}
        disabled={isSaving || showAttemptAnimation}
      >
        <Text style={styles.mainActionButtonText}>Stop Timer</Text>
      </TouchableOpacity>
    );
  } else if (currentTimerTimeLeft > 0 && currentTimerTimeLeft < MAX_TIMER_SECONDS) {
    TimerButtonComponent = (
      <TouchableOpacity
        style={[styles.mainActionButton, styles.startButton, (!currentAthlete || isSaving || showAttemptAnimation) && styles.actionButtonDisabled]}
        onPress={handleResumeTimer}
        disabled={!currentAthlete || isSaving || showAttemptAnimation}
      >
        <Text style={styles.mainActionButtonText}>Wznów Timer</Text>
      </TouchableOpacity>
    );
  } else {
    TimerButtonComponent = (
      <TouchableOpacity
        style={[styles.mainActionButton, styles.startButton, (!currentAthlete || isSaving || showAttemptAnimation) && styles.actionButtonDisabled]}
        onPress={handleStartOrRestartAttempt}
        disabled={!currentAthlete || isSaving || showAttemptAnimation}
      >
        <Text style={styles.mainActionButtonText}>Start Timer</Text>
      </TouchableOpacity>
    );
  }
  
  useEffect(() => {
    if (zawody.klubAvatar) {
      Image.getSize(zawody.klubAvatar, (width, height) => {
        const aspectRatio = width / height;
        const maxWidth = Platform.OS === 'web' ? 60 : 50; 
        const maxHeight = Platform.OS === 'web' ? 60 : 50;
        let displayWidth = width;
        let displayHeight = height;

        if (width > height) { 
            displayWidth = Math.min(width, maxWidth);
            displayHeight = displayWidth / aspectRatio;
            if (displayHeight > maxHeight) {
                displayHeight = maxHeight;
                displayWidth = displayHeight * aspectRatio;
            }
        } else { 
            displayHeight = Math.min(height, maxHeight);
            displayWidth = displayHeight * aspectRatio;
            if (displayWidth > maxWidth) {
                displayWidth = maxWidth;
                displayHeight = displayWidth / aspectRatio;
            }
        }
        setHeaderKlubAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, () => setHeaderKlubAvatarDimensions(null));
    } else {
      setHeaderKlubAvatarDimensions(null);
    }
  }, [zawody.klubAvatar]);

  useEffect(() => {
    if (zawody.sedzia?.avatar) {
      Image.getSize(zawody.sedzia.avatar, (width, height) => {
        const aspectRatio = width / height;
        const targetSize = Platform.OS === 'web' ? 40 : 32; 
        let displayWidth = targetSize;
        let displayHeight = targetSize;

        if (width > height) {
            displayHeight = targetSize / aspectRatio;
        } else {
            displayWidth = targetSize * aspectRatio;
        }
        
        if (displayWidth > targetSize) {
            displayWidth = targetSize;
            displayHeight = targetSize / aspectRatio;
        }
        if (displayHeight > targetSize) {
            displayHeight = targetSize;
            displayWidth = targetSize * aspectRatio;
        }

        setHeaderJudgeAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, () => setHeaderJudgeAvatarDimensions({ width: Platform.OS === 'web' ? 40 : 32, height: Platform.OS === 'web' ? 40 : 32 }));
    } else {
      setHeaderJudgeAvatarDimensions({ width: Platform.OS === 'web' ? 40 : 32, height: Platform.OS === 'web' ? 40 : 32 });
    }
  }, [zawody.sedzia?.avatar]);


  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[colors.gradient.start, colors.gradient.end]}
        style={styles.headerBackground}
      >
        <View style={styles.headerBar}>
            <View style={[styles.headerSideContainer, styles.headerLeftAlign]}>
                {headerKlubAvatarDimensions && zawody.klubAvatar ? (
                    <Image source={{ uri: zawody.klubAvatar }} style={[styles.headerClubLogo, { width: headerKlubAvatarDimensions.width, height: headerKlubAvatarDimensions.height }]} resizeMode="contain" />
                ) : <View style={styles.headerAvatarPlaceholder} />}
                <View style={styles.headerLocationDate}>
                    <Text style={styles.headerLocationText} numberOfLines={1}>{zawody.miejsce || 'Lokalizacja'}</Text>
                    <Text style={styles.headerDateText}>{zawody.data || 'Data'}</Text>
                </View>
            </View>
            <Text style={styles.headerLogo} numberOfLines={1}>{zawody.nazwa || 'Nazwa Zawodów'}</Text>
            <View style={[styles.headerSideContainer, styles.headerRightAlign]}>
                <View style={styles.headerJudgeInfo}>
                    <Text style={styles.headerJudgeName} numberOfLines={1}>{zawody.sedzia?.imie || ''} {zawody.sedzia?.nazwisko || 'Sędzia'}</Text>
                </View>
                {headerJudgeAvatarDimensions && zawody.sedzia?.avatar ? (
                    <Image source={{ uri: zawody.sedzia.avatar }} style={[styles.headerJudgeAvatar, { width: headerJudgeAvatarDimensions.width, height: headerJudgeAvatarDimensions.height }]} resizeMode="contain" />
                ) : <View style={styles.headerAvatarPlaceholder} />}
            </View>
        </View>
        <NavBar navigation={navigation} />
      </LinearGradient>

      <ScrollView style={styles.contentContainerScrollView} contentContainerStyle={styles.contentContainer}>
        <View style={styles.mainContent}>
          <Text style={styles.mainTitle}>Zarządzaj przebiegiem zawodów (Runda {currentRound})</Text>
          <View style={styles.columnsContainer}>
            <View style={styles.leftColumn}>
              <View style={styles.card}>
                <Text style={styles.columnTitle}>Wybór grupy</Text>
                <View style={styles.optionSelectorContainerInColumn}>
                  <OptionSelector
                    label="Kategoria"
                    options={categoryOptions}
                    selectedValue={activeCategory}
                    onSelect={handleSelectCategory}
                    placeholder="Wybierz kategorię"
                    loading={isSaving}
                  />
                </View>
                <View style={styles.optionSelectorContainerInColumn}>
                  <OptionSelector
                    label="Waga"
                    options={weightOptions}
                    selectedValue={activeWeight}
                    onSelect={handleSelectWeight}
                    placeholder="Wybierz wagę"
                    loading={isSaving || !activeCategory}
                    disabled={!activeCategory}
                  />
                </View>
                {activeCategory && activeWeight && (
                  <Text style={styles.infoText}>
                    Zawodnicy w grupie: {athletesInCurrentGroup.length}.
                    Oczekujący w rundzie {currentRound}: {upcomingAthletesForCurrentRound.length}
                  </Text>
                )}
              </View>
              <View style={[styles.card, styles.athleteListCard]}>
                <Text style={styles.columnTitle}>Lista Zawodników (Grupa: {activeCategory || '-'} / {activeWeight || '-'} kg)</Text>
                {(isSaving && !showAttemptAnimation) && <ActivityIndicator size="small" color={colors.primary} style={{marginBottom: spacing.sm}} />}
                <View style={styles.athleteListContainerInColumn}>
                  <AthleteList
                      athletes={displayAthletesInGroup}
                      currentAthleteOriginalIndex={activeAthleteOriginalIndex}
                      currentRound={currentRound}
                      onSelectAthlete={handleSelectAthlete}
                      onAttemptStatusChange={handleAttemptStatusChange}
                      onWeightChange={handleWeightChange}
                      isSaving={isSaving || showAttemptAnimation} 
                  />
                </View>
              </View>
            </View>
            <View style={styles.rightColumn}>
              <View style={styles.card}>
                <Text style={styles.columnTitle}>Panel Sędziego</Text>
                <CurrentAthleteManager
                    athlete={currentAthlete}
                    athleteOriginalIndex={activeAthleteOriginalIndex}
                    currentAttemptNr={activeAttemptNr}
                    onAttemptStatusChange={handleAttemptStatusChange}
                    onWeightChange={handleWeightChange}
                    isSaving={isSaving || showAttemptAnimation} 
                    currentRoundForDisplay={currentRound}
                />
                 <TimerDisplay isActive={timerActive} timeLeft={timerTimeLeft} />
                <View style={styles.currentStatusInfo}>
                  <Text style={styles.currentStatusLabel}>Aktualnie na podeście:</Text>
                  {currentAthlete ? (
                    <Text style={styles.currentStatusText}>
                      {currentAthlete.imie} {currentAthlete.nazwisko} ({currentAthlete.klub || 'brak klubu'})
                      {'\n'}Podejście #{activeAttemptNr} ({currentAthlete[`podejscie${activeAttemptNr}`] || 'N/A'} kg)
                    </Text>
                  ) : (
                    <Text style={styles.currentStatusText}>Brak aktywnego zawodnika</Text>
                  )}
                </View>
                <View style={styles.mainActionButtons}>
                  {TimerButtonComponent}
                  {ResetButtonComponent}
                  <TouchableOpacity
                    style={[styles.secondaryActionButton, (!activeCategory || !activeWeight || upcomingAthletesForCurrentRound.length === 0 || isSaving || timerActive || showAttemptAnimation) && styles.actionButtonDisabled]}
                    onPress={handleNextCompetitor}
                    disabled={!activeCategory || !activeWeight || upcomingAthletesForCurrentRound.length === 0 || isSaving || timerActive || showAttemptAnimation}
                  >
                    <Text style={styles.secondaryActionButtonText}>Następny Zawodnik</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.secondaryActionButton, (currentRound <= 1 || isSaving || timerActive || showAttemptAnimation) && styles.actionButtonDisabled]}
                    onPress={handlePreviousRound}
                    disabled={currentRound <= 1 || isSaving || timerActive || showAttemptAnimation}
                  >
                    <Text style={styles.secondaryActionButtonText}>Poprzednia Runda</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.secondaryActionButton, (currentRound >= 3 || isSaving || timerActive || showAttemptAnimation) && styles.actionButtonDisabled]}
                    onPress={handleNextRound}
                    disabled={currentRound >= 3 || isSaving || timerActive || showAttemptAnimation}
                  >
                    <Text style={styles.secondaryActionButtonText}>Następna Runda</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
      <Footer />

      {showAttemptAnimation && (
        <View style={styles.animationOverlayContainer}>
            <AttemptResultAnimation success={attemptAnimationSuccess} />
        </View>
      )}
    </View>
  );
}
