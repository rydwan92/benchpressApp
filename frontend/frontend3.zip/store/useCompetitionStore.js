import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { Platform } from 'react-native';

let storageMechanism;

if (Platform.OS === 'web') {
  storageMechanism = {
    getItem: async (name) => localStorage.getItem(name),
    setItem: async (name, value) => localStorage.setItem(name, value),
    removeItem: async (name) => localStorage.removeItem(name),
  };
} else {
  const AsyncStorage = require('@react-native-async-storage/async-storage').default;
  storageMechanism = AsyncStorage;
}

export const useCompetitionStore = create(
  persist(
    (set, get) => ({
      zawody: {
        nazwa: 'Ławka Cup',
        miejsce: '',
        data: new Date().toISOString().slice(0, 10),
        sedzia: { imie: '', nazwisko: '', avatar: null },
        klubAvatar: null,
      },
      kategorie: [],
      zawodnicy: [],
      activeCategory: null,
      activeWeight: null,
      activeAthleteOriginalIndex: null,
      activeAttemptNr: 1,
      currentRound: 1,
      timerActive: false,
      timerTimeLeft: 60,
      socket: null,
      attemptResultForAnimation: null,

      setInitialData: (data) => {
        console.log('[Store] setInitialData called with:', data);
        set({
          zawody: data.zawody || get().zawody,
          kategorie: data.kategorie || [],
          zawodnicy: data.zawodnicy || [],
          activeCategory: data.activeCategory || null,
          activeWeight: data.activeWeight || null,
          activeAthleteOriginalIndex: data.activeAthleteOriginalIndex !== undefined ? data.activeAthleteOriginalIndex : null,
          activeAttemptNr: data.activeAttemptNr || 1,
          currentRound: data.currentRound || 1,
        }, false, 'setInitialData');
      },
      setSocket: (socketInstance) => set({ socket: socketInstance }, false, 'setSocket'),
      
      setZawody: (updatedZawodyData) => {
        set(state => ({
          zawody: { ...state.zawody, ...updatedZawodyData }
        }), false, 'setZawody');
      },

      addZawodnik: (nowyZawodnik) => {
        set(state => ({
          zawodnicy: [
            ...state.zawodnicy,
            {
              id: `athlete_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, // Proste ID
              ...nowyZawodnik,
              podejscie1: nowyZawodnik.podejscie1 || '',
              podejscie2: nowyZawodnik.podejscie2 || '',
              podejscie3: nowyZawodnik.podejscie3 || '',
              podejscie1Status: null,
              podejscie2Status: null,
              podejscie3Status: null,
            }
          ]
        }), false, 'addZawodnik');
      },
      updateZawodnik: (index, updatedData) => {
        set(state => {
          const newZawodnicy = [...state.zawodnicy];
          if (newZawodnicy[index]) {
            newZawodnicy[index] = { ...newZawodnicy[index], ...updatedData };
          }
          return { zawodnicy: newZawodnicy };
        }, false, 'updateZawodnik');
      },
      removeZawodnik: (originalIndexToRemove) => {
        set(state => {
          const newZawodnicy = state.zawodnicy.filter((_, index) => index !== originalIndexToRemove);
          let newActiveAthleteOriginalIndex = state.activeAthleteOriginalIndex;
          if (state.activeAthleteOriginalIndex === originalIndexToRemove) {
            newActiveAthleteOriginalIndex = null;
          } else if (state.activeAthleteOriginalIndex > originalIndexToRemove) {
            newActiveAthleteOriginalIndex = state.activeAthleteOriginalIndex - 1;
          }
          return { 
            zawodnicy: newZawodnicy,
            activeAthleteOriginalIndex: newActiveAthleteOriginalIndex 
          };
        }, false, 'removeZawodnik');
      },

      addKategoria: (nazwaKategorii) => {
        set(state => {
          if (state.kategorie.find(k => k.nazwa === nazwaKategorii)) {
            return state; // Kategoria już istnieje
          }
          return {
            kategorie: [...state.kategorie, { nazwa: nazwaKategorii, wagi: [] }]
          };
        }, false, 'addKategoria');
      },
      removeKategoria: (nazwaKategorii) => {
        set(state => ({
          kategorie: state.kategorie.filter(k => k.nazwa !== nazwaKategorii),
          zawodnicy: state.zawodnicy.filter(z => z.kategoria !== nazwaKategorii), // Usuń też zawodników z tej kategorii
          activeCategory: state.activeCategory === nazwaKategorii ? null : state.activeCategory,
          activeWeight: state.activeCategory === nazwaKategorii ? null : state.activeWeight,
        }), false, 'removeKategoria');
      },
      addWaga: (nazwaKategorii, waga) => {
        set(state => {
          const newKategorie = state.kategorie.map(k => {
            if (k.nazwa === nazwaKategorii) {
              if (k.wagi.includes(waga)) return k; // Waga już istnieje
              return { ...k, wagi: [...k.wagi, waga].sort((a, b) => parseFloat(a) - parseFloat(b)) };
            }
            return k;
          });
          return { kategorie: newKategorie };
        }, false, 'addWaga');
      },
      removeWaga: (nazwaKategorii, waga) => {
        set(state => {
          const newKategorie = state.kategorie.map(k => {
            if (k.nazwa === nazwaKategorii) {
              return { ...k, wagi: k.wagi.filter(w => w !== waga) };
            }
            return k;
          });
          return {
            kategorie: newKategorie,
            zawodnicy: state.zawodnicy.filter(z => !(z.kategoria === nazwaKategorii && z.waga === waga)), // Usuń zawodników z tej wagi
            activeWeight: (state.activeCategory === nazwaKategorii && state.activeWeight === waga) ? null : state.activeWeight,
          };
        }, false, 'removeWaga');
      },
      
      updatePodejscieWaga: (athleteOriginalIndex, attemptNo, weight) => {
        set(state => {
          const newZawodnicy = [...state.zawodnicy];
          if (newZawodnicy[athleteOriginalIndex]) {
            newZawodnicy[athleteOriginalIndex] = {
              ...newZawodnicy[athleteOriginalIndex],
              [`podejscie${attemptNo}`]: weight,
            };
          }
          return { zawodnicy: newZawodnicy };
        }, false, 'updatePodejscieWaga');
      },
      updatePodejscieStatus: (athleteOriginalIndex, attemptNo, status) => {
        set(state => {
          const newZawodnicy = [...state.zawodnicy];
          if (newZawodnicy[athleteOriginalIndex]) {
            newZawodnicy[athleteOriginalIndex] = {
              ...newZawodnicy[athleteOriginalIndex],
              [`podejscie${attemptNo}Status`]: status,
            };
          }
          return { zawodnicy: newZawodnicy };
        }, false, 'updatePodejscieStatus');
      },
      setActiveGroup: (category, weight) => {
        console.log(`[Store] setActiveGroup: Category=${category}, Weight=${weight}`);
        set({
          activeCategory: category,
          activeWeight: weight,
          activeAthleteOriginalIndex: null,
          currentRound: 1,
          activeAttemptNr: 1,
        }, false, 'setActiveGroup');
      },
      setActiveAthlete: (athleteOriginalIndex) => {
        console.log(`[Store] setActiveAthlete: Index=${athleteOriginalIndex}`);
        set(state => ({
          activeAthleteOriginalIndex: athleteOriginalIndex,
          activeAttemptNr: state.currentRound, // Ustaw podejście na aktualną rundę
        }), false, 'setActiveAthlete');
      },
      setCurrentRound: (round) => {
        console.log(`[Store] setCurrentRound: Round=${round}`);
        set({
          currentRound: round,
          activeAthleteOriginalIndex: null, // Resetuj aktywnego zawodnika przy zmianie rundy
          activeAttemptNr: round, // Ustaw numer podejścia na nową rundę
        }, false, 'setCurrentRound');
      },
      setTimerActive: (isActive) => set({ timerActive: isActive }, false, 'setTimerActive'),
      setTimerTimeLeft: (timeLeft) => set({ timerTimeLeft: timeLeft }, false, 'setTimerTimeLeft'),
      setAttemptResultForAnimation: (result) => {
        console.log('[Store] setAttemptResultForAnimation called with:', result); // DODANY LOG
        set({ attemptResultForAnimation: result }, false, 'setAttemptResultForAnimation');
      },
      clearAttemptResultForAnimation: () => {
        console.log('[Store] clearAttemptResultForAnimation called.'); // DODANY LOG
        set({ attemptResultForAnimation: null }, false, 'clearAttemptResultForAnimation');
      },
    }),
    {
      name: 'competition-storage',
      storage: createJSONStorage(() => storageMechanism),
      partialize: (state) => {
        const { socket, ...rest } = state; // Nie persistuj instancji socketu
        return rest;
      },
    }
  )
);