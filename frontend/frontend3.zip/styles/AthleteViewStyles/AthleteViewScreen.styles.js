import { StyleSheet, Dimensions } from 'react-native';
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme'; 

const { width, height } = Dimensions.get('window');

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.backgroundDark, 
    },
    groupHeader: {
        backgroundColor: colors.secondary, 
        paddingVertical: spacing.lg,
        paddingHorizontal: spacing.xl,
        ...shadows.large,
        marginBottom: spacing.lg, 
    },
    groupHeaderTitle: {
        fontSize: font.sizes['5xl'] < 60 ? font.sizes['5xl'] : 60, // Ograniczenie max rozmiaru
        fontWeight: font.weights.extrabold,
        color: colors.textMainTitle,
        textAlign: 'center',
        fontFamily: font.familyDisplay || font.family,
        letterSpacing: 1,
        textShadowColor: 'rgba(0, 0, 0, 0.3)',
        textShadowOffset: { width: 1, height: 2 },
        textShadowRadius: 3,
        marginBottom: spacing.sm,
    },
    groupHeaderSubtitle: {
        fontSize: font.sizes['3xl'] < 40 ? font.sizes['3xl'] : 40, // Ograniczenie max rozmiaru
        fontWeight: font.weights.bold,
        color: colors.textLight, // Zmieniono z accent dla lepszego kontrastu na ciemnym tle
        textAlign: 'center',
        marginTop: spacing.xs,
        backgroundColor: colors.accent,
        paddingVertical: spacing.sm,
        paddingHorizontal: spacing.lg,
        borderRadius: borderRadius.md,
        alignSelf: 'center',
        minWidth: '60%',
        maxWidth: '90%',
        borderWidth: 2, // Grubsza ramka
        borderColor: colors.textMainTitle + '90', // Jaśniejsza ramka
        ...shadows.medium, // Dodano cień
    },
    mainContent: { 
        flex: 1,
        paddingHorizontal: spacing.lg, 
        paddingTop: spacing.lg,
        paddingBottom: spacing.md, 
        alignItems: 'center', // Wyśrodkuj zawartość główną (karta zawodnika, podejścia)
    },
    athleteDetailContainer: { 
        flex: 1,
        width: '100%',
        alignItems: 'center', // Wyśrodkuj elementy wewnątrz tego kontenera
    },
    athleteInfoCard: {
        backgroundColor: colors.surface, // Jasne tło dla karty informacji
        borderRadius: borderRadius.xl, // Większe zaokrąglenie
        padding: spacing.xl,          // Większy padding
        marginBottom: spacing.xl,     // Większy margines dolny
        ...shadows.large,             // Mocniejszy cień
        alignItems: 'center',
        width: '100%',                // Karta zajmuje całą dostępną szerokość w mainContent
        maxWidth: 850,               // Maksymalna szerokość karty informacji, szersza niż podejścia
    },
    athleteName: {
        fontSize: font.sizes['4xl'] < 50 ? font.sizes['4xl'] : 50, // Duży rozmiar, ograniczony
        fontWeight: font.weights.bold,
        color: colors.text, 
        textAlign: 'center',
        marginBottom: spacing.sm, // Zwiększony margines
    },
    athleteNameHighlight: { 
        color: colors.primary, // Użyj koloru primary dla wyróżnienia
    },
    athleteClub: {
        fontSize: font.sizes.xl, // Większy rozmiar
        color: colors.textSecondary,
        textAlign: 'center',
        marginBottom: spacing.md, // Zwiększony margines
        fontStyle: 'italic',
    },
    athleteCategory: {
        fontSize: font.sizes.lg, // Większy rozmiar
        color: colors.textSecondary, 
        textAlign: 'center',
    },
    categoryValueHighlight: { 
        color: colors.accent, // Akcent dla wartości kategorii
        fontWeight: font.weights.bold, // Pogrubienie
    },
    weightValueHighlight: { 
        color: colors.accent, // Akcent dla wartości wagi
        fontWeight: font.weights.bold, // Pogrubienie
    },
    sectionTitle: { // Dla tytułów sekcji jak "Podejścia", "Czas"
        fontSize: font.sizes['3xl'] < 36 ? font.sizes['3xl'] : 36, // Duży, ale ograniczony rozmiar
        fontWeight: font.weights.bold,
        color: colors.textLight + 'f0', // Bardzo jasny tekst
        marginBottom: spacing.md, 
        textAlign: 'center',
        width: '100%',
        marginTop: spacing.lg, // Dodano większy margines górny
        textTransform: 'uppercase', // Wielkie litery
        letterSpacing: 1,
    },
    attemptsContainer: {
        width: '100%', 
        maxWidth: 700, // Maksymalna szerokość dla podejść (węższa niż infoCard)
        marginBottom: spacing.xl, // Większy margines
        alignItems: 'center', // Wyśrodkuj AttemptDisplay wewnątrz
    },
    timerSection: {
        width: '100%',
        alignItems: 'center',
        marginBottom: spacing.xl, 
        marginTop: spacing.md,
    },
    nextUpContainer: {
        backgroundColor: colors.surface + '2A', // Bardziej subtelne tło
        paddingVertical: spacing.md,
        paddingHorizontal: spacing.lg,
        borderRadius: borderRadius.lg,
        borderTopWidth: 2, // Grubsza górna krawędź
        borderTopColor: colors.accent + '90', // Kolor akcentu dla krawędzi
        width: '100%',
        maxWidth: 700, 
        alignSelf: 'center', 
        marginTop: 'auto', 
        marginBottom: spacing.md, // Zwiększony margines dolny
        ...shadows.medium,
    },
    nextUpTitle: {
        fontSize: font.sizes.xl, // Większy rozmiar
        fontWeight: font.weights.bold, // Pogrubiony
        color: colors.textLight + 'cc', // Jaśniejszy tekst
        textAlign: 'center',
        marginBottom: spacing.sm, // Zwiększony margines
        textTransform: 'uppercase',
    },
    nextUpAthleteName: {
        fontSize: font.sizes['3xl'] < 36 ? font.sizes['3xl'] : 36, // Duży, ale ograniczony
        fontWeight: font.weights.bold,
        color: colors.textLight,
        textAlign: 'center',
        marginBottom: spacing.xs,
    },
    nextUpAthleteInfo: {
        fontSize: font.sizes.lg, // Większy rozmiar
        color: colors.textLight + 'dd', // Jaśniejszy tekst
        textAlign: 'center',
        lineHeight: font.sizes.lg * 1.4, // Lepsza czytelność
    },
    placeholderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: spacing.xl,
    },
    placeholderText: {
        fontSize: font.sizes['3xl'] < 40 ? font.sizes['3xl'] : 40, // Duży, ale ograniczony
        color: colors.textLight + '99', // Mniej intensywny kolor
        fontStyle: 'italic',
        textAlign: 'center',
        lineHeight: (font.sizes['3xl'] < 40 ? font.sizes['3xl'] : 40) * 1.5, // Zwiększony interlinia
    },
    groupViewContainer: {
        width: '100%',
        flex: 1,
    },
    animationOverlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.9)', // Ciemniejszy overlay dla lepszego skupienia
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000,
    },
});