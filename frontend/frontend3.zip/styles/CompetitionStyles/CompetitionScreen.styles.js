import { StyleSheet, Platform } from 'react-native';
import { colors, font, spacing, borderRadius, shadows, componentStyles } from '../../theme/theme';

export const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: colors.background },
    contentContainerScrollView: {
        flex: 1,
    },
    contentContainer: { 
        flexGrow: 1,
        paddingBottom: spacing.xl, 
    },
    headerBackground: {
        paddingTop: Platform.OS === 'web' ? spacing.md : spacing.lg, 
        paddingBottom: spacing.md,
        ...shadows.medium,
    },
    headerBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: spacing.lg,
        marginBottom: spacing.sm, 
        minHeight: 50, 
    },
    headerSideContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1, 
        minWidth: Platform.OS === 'web' ? 150 : 120, 
    },
    headerLeftAlign: {
        justifyContent: 'flex-start',
    },
    headerRightAlign: {
        justifyContent: 'flex-end',
    },
    headerClubLogo: {
        marginRight: spacing.sm, 
        width: Platform.OS === 'web' ? 60 : 50, 
        height: Platform.OS === 'web' ? 60 : 50, 
    },
    headerAvatarPlaceholder: { 
        width: Platform.OS === 'web' ? 40 : 32,
        height: Platform.OS === 'web' ? 40 : 32,
        borderRadius: borderRadius.sm,
        backgroundColor: colors.textLight + '20', 
        marginHorizontal: spacing.xs,
    },
    headerLocationDate: {
        justifyContent: 'center',
        maxWidth: Platform.OS === 'web' ? 120 : 100, 
    },
    headerLocationText: {
        fontSize: font.sizes.xs, 
        color: colors.textLight + 'dd',
        fontWeight: font.weights.medium,
        flexShrink: 1, 
    },
    headerDateText: {
        fontSize: font.sizes.xs, 
        color: colors.textLight + 'bb',
        fontWeight: font.weights.regular, 
        flexShrink: 1,
    },
    headerLogo: { 
        fontSize: Platform.OS === 'web' ? font.sizes.xl : font.sizes.lg, 
        fontWeight: font.weights.bold,
        color: colors.textMainTitle,
        textAlign: 'center',
        marginHorizontal: spacing.sm, 
        flexGrow: 1, 
        flexShrink: 2, 
        minWidth: 100, 
    },
    headerJudgeInfo: {
        alignItems: 'flex-end',
        marginRight: spacing.xs, 
        maxWidth: Platform.OS === 'web' ? 120 : 100, 
    },
    headerJudgeName: {
        fontSize: font.sizes.xs, 
        color: colors.textLight + 'dd',
        fontWeight: font.weights.medium,
        textAlign: 'right',
        flexShrink: 1,
    },
    headerJudgeAvatar: {
        marginLeft: spacing.xs, 
        borderRadius: borderRadius.sm, 
        width: Platform.OS === 'web' ? 40 : 32, 
        height: Platform.OS === 'web' ? 40 : 32, 
    },
    mainContent: {
        paddingHorizontal: Platform.OS === 'web' ? spacing.xl : spacing.lg, 
        paddingTop: spacing.lg,
    },
    mainTitle: { 
        ...componentStyles.title, 
        textAlign: 'center',
        marginBottom: spacing.xl, 
        color: colors.primary, 
        fontSize: Platform.OS === 'web' ? font.sizes['2xl'] : font.sizes.xl, 
    },
    columnsContainer: {
        flexDirection: Platform.OS === 'web' ? 'row' : 'column', 
        gap: Platform.OS === 'web' ? spacing.xl : spacing.lg, 
    },
    leftColumn: {
        flex: Platform.OS === 'web' ? 1 : undefined, 
        gap: spacing.lg, 
    },
    rightColumn: {
        flex: Platform.OS === 'web' ? 1 : undefined, 
        gap: spacing.lg, 
    },
    card: {
        ...componentStyles.card, 
        padding: spacing.lg, 
    },
    athleteListCard: { 
        flex: Platform.OS === 'web' ? 1 : 0, 
        minHeight: 300, 
    },
    columnTitle: {
        ...componentStyles.componentTitle,
        fontSize: Platform.OS === 'web' ? font.sizes.xl : font.sizes.lg, 
        marginBottom: spacing.md, 
        textAlign: 'left', 
        color: colors.text,
    },
    currentStatusInfo: {
        alignItems: 'center',
        marginTop: spacing.md, 
        marginBottom: spacing.lg,
        padding: spacing.md,
        backgroundColor: colors.surfaceVariant + 'A0', 
        borderRadius: borderRadius.md,
        borderWidth: 1,
        borderColor: colors.border,
    },
    currentStatusLabel: {
        fontSize: font.sizes.sm,
        color: colors.textSecondary,
        marginBottom: spacing.xs,
    },
    currentStatusText: {
        fontSize: font.sizes.md,
        color: colors.text,
        textAlign: 'center',
        fontWeight: font.weights.medium,
    },
    mainActionButtons: {
        gap: spacing.md,
        alignItems: 'stretch', 
        marginTop: spacing.lg, 
    },
    mainActionButton: { 
        ...componentStyles.button.base,
        flexDirection: 'row', 
        justifyContent: 'center', 
        paddingVertical: spacing.md, 
    },
    startButton: {
        backgroundColor: colors.primary,
    },
    stopButton: {
        backgroundColor: colors.warning,
    },
    mainActionButtonText: {
        ...componentStyles.button.text,
        fontSize: font.sizes.md, 
    },
    actionButtonDisabled: { 
        backgroundColor: colors.button.disabled,
        opacity: 0.7,
    },
    secondaryActionButton: {
        ...componentStyles.button.base,
        backgroundColor: colors.secondary, 
        paddingVertical: spacing.sm, 
        justifyContent: 'center', 
    },
    secondaryActionButtonText: {
        ...componentStyles.button.text, 
        fontSize: font.sizes.sm, 
        color: colors.textOnSecondary, 
    },
    infoText: { 
        fontSize: font.sizes.sm,
        color: colors.textSecondary,
        marginTop: spacing.md,
        textAlign: 'center',
    },
    animationOverlayContainer: { 
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0, 0, 0, 0.7)', 
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 1000, 
    },
    optionSelectorContainerInColumn: { 
        marginBottom: spacing.lg, 
    },
    athleteListContainerInColumn: { 
        flex: 1, 
        minHeight: Platform.OS === 'web' ? 300 : 250, 
    }
});