import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, font, spacing, borderRadius } from '../../theme/theme';
import { styles } from '../../styles/AthleteViewStyles/AthleteViewScreen.styles';
import useCompetitionStore from '../../store/useCompetitionStore'; // To get the socket and active athlete

// Original styles definition - we will modify this
const timerStyles = StyleSheet.create({
  timerContainer: {
    width: '90%',
    maxWidth: 400,
    paddingVertical: spacing.lg, // 24
    paddingHorizontal: spacing.lg, // CHANGED from spacing.xl (32) to spacing.lg (24)
    backgroundColor: colors.surface,
    borderRadius: borderRadius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 4,
    borderColor: colors.border,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
  },
  timerActive: {
    backgroundColor: colors.error, // Czerwone tło gdy aktywny
    borderColor: colors.errorDark || '#C00000',
  },
  timerInactive: { // Kiedy timer nie jest aktywny, ale czas > 0 (np. "GOTOWY?")
    backgroundColor: colors.surface, // Domyślne tło
    borderColor: colors.primary, // Niebieska ramka
  },
  timerText: {
    fontFamily: font.familyMono || font.family,
    fontSize: 72, 
    fontWeight: font.weights.bold,
    color: colors.text, 
    lineHeight: 72 * 1.1, 
  },
  timerLabel: {
    fontSize: font.sizes['xl'], 
    fontWeight: font.weights.semibold,
    color: colors.textSecondary, 
    marginTop: spacing.xs,
    textTransform: 'uppercase',
  },
  timerActiveText: { // Dla tekstu na czerwonym/żółtym tle
    color: colors.textLight,
  },
  timerActiveLabel: { // Dla etykiety na czerwonym/żółtym tle
    color: colors.textLight + 'dd',
  },
  timerTimeUp: { // Kiedy czas minął (timeLeft <= 0 i !isActive)
    backgroundColor: colors.warning, // Żółte tło
    borderColor: colors.warningDark || '#B28900', 
  },
});

const FinalAthleteViewTimerDisplay = ({ isActive, timeLeft: initialTimeLeft }) => {
  const socket = useCompetitionStore(state => state.socket);
  // Get the active athlete ID from the store to ensure ticks are for the correct context
  const currentAthleteIdOnView = useCompetitionStore(state => state.activeAthleteOriginalIndex);
  
  const [displayTime, setDisplayTime] = useState(initialTimeLeft);

  // Effect to update displayTime when initialTimeLeft (from props/store) changes
  // This handles timer starts and resets.
  useEffect(() => {
      console.log(`[AthleteViewTimerDisplay] Prop initialTimeLeft changed to: ${initialTimeLeft}. isActive: ${isActive}`);
      setDisplayTime(initialTimeLeft);
  }, [initialTimeLeft, isActive]); // Re-run if isActive also changes, as it might imply a reset

  // Effect to listen for timer ticks
  useEffect(() => {
      if (socket) {
          const handleTimerTick = (data) => {
              // data typically includes { timeLeft: number, athleteOriginalIndex?: string }
              if (data && typeof data.timeLeft === 'number') {
                  // Only update if the tick is for the athlete currently displayed on this screen
                  // OR if the tick is "global" (doesn't specify an athleteId, though less common for ticks)
                  if (data.athleteOriginalIndex === currentAthleteIdOnView || !data.athleteOriginalIndex) {
                      // console.log(`[AthleteViewTimerDisplay] Tick received: ${data.timeLeft} for athlete ${data.athleteOriginalIndex}`);
                      setDisplayTime(data.timeLeft);
                  }
              }
          };

          socket.on('timerTick', handleTimerTick);
          console.log('[AthleteViewTimerDisplay] Subscribed to timerTick.');

          return () => {
              socket.off('timerTick', handleTimerTick);
              console.log('[AthleteViewTimerDisplay] Unsubscribed from timerTick.');
          };
      }
  }, [socket, currentAthleteIdOnView]); // Dependency: socket and the ID of the athlete this view is focused on

  const minutes = Math.floor(displayTime / 60);
  const seconds = displayTime % 60;

  // console.log(`[AthleteViewTimerDisplay] Rendering. isActive: ${isActive}, displayTime: ${displayTime}`);

  return (
    <View 
      style={[
        timerStyles.timerContainer, 
        isActive 
          ? timerStyles.timerActive 
          : (displayTime <= 0 && !isActive ? timerStyles.timerTimeUp : timerStyles.timerInactive)
      ]}
    >
      <Text 
        style={[
          timerStyles.timerText, 
          (isActive || displayTime <= 0 && !isActive) 
            ? timerStyles.timerActiveText 
            : { color: colors.primary } // Niebieski tekst dla "GOTOWY?"
        ]}
      >
        {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
      </Text>
      <Text 
        style={[
          timerStyles.timerLabel, 
          (isActive || displayTime <= 0 && !isActive) 
            ? timerStyles.timerActiveLabel
            : { color: colors.textSecondary } // Szary tekst dla "GOTOWY?"
        ]}
      >
        {isActive ? 'CZAS LECI' : (displayTime <= 0 && !isActive ? 'CZAS MINĄŁ' : 'GOTOWY?')}
      </Text>
    </View>
  );
};

export default FinalAthleteViewTimerDisplay;