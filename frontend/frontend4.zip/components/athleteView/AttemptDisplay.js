import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons'; // Usunięto AntDesign, jeśli nie jest już potrzebny
import { colors, font, spacing, borderRadius, shadows } from '../../theme/theme';

const AttemptDisplay = ({ number, weight, status, isActive }) => {
    let statusHeaderText = `PODEJŚCIE ${number}`;
    let headerTextStyle = null; // Dodatkowy styl dla tekstu nagłówka (np. ZALICZONE)
    let showStatusIcon = true;

    const iconSize = isActive ? 28 : 24; // Nieco mniejsze ikony dla czystszego wyglądu

    if (status === 'passed') {
        statusHeaderText = "ZALICZONE";
        headerTextStyle = styles.headerTextPassed;
        showStatusIcon = false;
    } else if (status === 'failed') {
        statusHeaderText = "SPALONE";
        headerTextStyle = styles.headerTextFailed;
        showStatusIcon = false;
    }

    const getStatusIconElement = () => {
        if (!showStatusIcon) return null;
        // Nie pokazuj ikony, jeśli nie ma zadeklarowanego ciężaru ani statusu (puste podejście)
        if (!weight && !status) return null;


        switch (status) {
            case 'pending':
                return <MaterialCommunityIcons name="dots-horizontal-circle-outline" size={iconSize} color={isActive ? colors.primaryDark : colors.textSecondary} />;
            default: // Domyślnie (np. podejście zadeklarowane, ale nie 'pending')
                if (weight) { // Pokaż zegar tylko, jeśli ciężar jest zadeklarowany
                    return <MaterialCommunityIcons name="progress-clock" size={iconSize} color={isActive ? colors.primary : colors.info} />;
                }
                return null;
        }
    };

    const containerStyles = [
        styles.attemptBoxBase,
        isActive && styles.attemptBoxActive,
        !isActive && styles.attemptBoxInactive, // Dodano dla spójności
        status === 'passed' && styles.attemptBoxPassed,
        status === 'failed' && styles.attemptBoxFailed,
    ];

    const currentHeaderTextStyles = [
        styles.headerTextBase,
        isActive ? styles.headerTextActive : styles.headerTextInactive,
        headerTextStyle, 
    ];

    const currentWeightTextStyles = [
        styles.weightTextBase,
        isActive ? styles.weightTextActive : styles.weightTextInactive,
    ];

    // ZMIANA: Dodajemy styl koloru dla wagi w stanie zaliczonym/spalonym
    if (status === 'passed' || status === 'failed') {
        currentWeightTextStyles.push(styles.weightTextResult); // Dla rozmiaru czcionki
        currentWeightTextStyles.push({ color: colors.textLight }); // Biały tekst na kolorowym tle
    }


    return (
        <View style={containerStyles}>
            <View style={styles.textContainer}>
                <Text style={currentHeaderTextStyles} numberOfLines={1}>{statusHeaderText}</Text>
                <Text style={currentWeightTextStyles} numberOfLines={1}>{weight ? `${String(weight).replace(',', '.')} kg` : '-'}</Text>
            </View>
            {showStatusIcon && ( 
                <View style={styles.iconContainer}>
                    {getStatusIconElement()}
                </View>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    attemptBoxBase: {
        borderRadius: borderRadius.lg, // Zgodnie z poprzednimi zmianami
        paddingVertical: spacing.lg,
        paddingHorizontal: spacing.md,
        flexDirection: 'row',
        justifyContent: 'center', // Główny tekst wyśrodkowany
        alignItems: 'center',
        flexGrow: 1,
        flexShrink: 1,
        flexBasis: '0%',
        borderWidth: 2,
        ...shadows.subtle, // Bardziej subtelny cień bazowy
        backgroundColor: colors.surface + 'CC', // Zgodnie z poprzednimi zmianami
        borderColor: colors.border,
        minHeight: 110, 
        position: 'relative', 
        overflow: 'hidden', 
    },
    textContainer: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: spacing.xs / 2, // Mniejszy odstęp między nagłówkiem a ciężarem
    },
    iconContainer: {
        position: 'absolute',
        right: spacing.md,
        top: 0,
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
    },
    attemptBoxInactive: {
        backgroundColor: colors.surface + '99', // Bardziej stonowane dla nieaktywnych
        borderColor: colors.border + '99',
        opacity: 0.85, // Zgodnie z poprzednimi zmianami
    },
    attemptBoxActive: {
        backgroundColor: colors.surface, 
        borderColor: colors.primary,
        ...shadows.medium, 
        transform: [{ scale: 1.15 }], // ZMIANA: Znacznie większe powiększenie
        zIndex: 10,
        paddingVertical: spacing.xl, // ZMIANA: Większy padding pionowy
        minHeight: 130, // ZMIANA: Wyższy minimalny kafelek
    },
    attemptBoxPassed: {
        backgroundColor: colors.success, // ZMIANA: Przywrócenie na główny kolor sukcesu
        borderColor: colors.successDark || '#388E3C',
        ...shadows.none, 
    },
    attemptBoxFailed: {
        backgroundColor: colors.error, // ZMIANA: Przywrócenie na główny kolor błędu
        borderColor: colors.errorDark || '#D32F2F',
        ...shadows.none, 
    },

    // Style typograficzne
    headerTextBase: {
        fontWeight: font.weights.semibold,
        textAlign: 'center',
    },
    weightTextBase: {
        fontWeight: font.weights.bold,
        textAlign: 'center',
    },

    // Stany nieaktywne
    headerTextInactive: {
        fontSize: font.sizes.lg,
        color: colors.textSecondary,
    },
    weightTextInactive: {
        fontSize: font.sizes['2xl'],
        color: colors.text,
    },

    // Stany aktywne
    headerTextActive: {
        fontSize: font.sizes['2xl'], // ZMIANA: Większy tekst nagłówka dla aktywnego
        color: colors.primary,
    },
    weightTextActive: {
        fontSize: 44, // ZMIANA: Znacznie większy tekst wagi dla aktywnego (custom size)
        color: colors.text,
    },
    headerTextPassed: {
        fontSize: font.sizes.xl, 
        color: colors.textLight, // ZMIANA: Biały tekst na zielonym tle
        fontWeight: font.weights.bold,
    },
    headerTextFailed: {
        fontSize: font.sizes.xl, 
        color: colors.textLight, // ZMIANA: Biały tekst na czerwonym tle
        fontWeight: font.weights.bold,
    },
    weightTextResult: { // Ten styl teraz głównie kontroluje rozmiar dla wyników
        fontSize: font.sizes['3xl'], 
        // Kolor będzie nadpisywany na colors.textLight w logice komponentu dla passed/failed
    },
});

export default AttemptDisplay;