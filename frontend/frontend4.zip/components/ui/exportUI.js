export { default as StyledButton } from './StyledButton';
export { default as StyledCard } from './StyledCard';
export { default as StyledText } from './StyledText';