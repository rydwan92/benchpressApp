import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react'; // Added useRef
import { View, Text, Image, TouchableOpacity, ActivityIndicator, ScrollView } from 'react-native'; // Added ScrollView
import { MaterialCommunityIcons } from '@expo/vector-icons';
import useCompetitionStore from '../store/useCompetitionStore';
import { styles } from '../styles/AthleteViewStyles/AthleteViewScreen.styles';
import { colors, font, spacing } from '../theme/theme'; // Added spacing
import AthleteViewTimerDisplay from '../components/athleteView/AthleteViewTimerDisplay';
import AttemptDisplay from '../components/athleteView/AttemptDisplay';
import GroupAthleteList from '../components/athleteView/GroupAthleteList';
import AttemptResultAnimation from '../components/competition/AttemptResultAnimation';

// Import results processing utilities and table component
import IndividualResultsTable from '../components/results/IndividualResultsTable';
import { processAthletesForResults, sortIndividualResults } from '../components/results/resultsHelper';

// Helper functions (getAthleteDeclaredWeightForRound, hasAthleteCompletedAttemptInRound, etc. remain the same)
// ... (existing helper functions: getAthleteDeclaredWeightForRound, hasAthleteCompletedAttemptInRound, hasAthleteCompletedAll, getTrophyIcon) ...
const getAthleteDeclaredWeightForRound = (athlete, round) => {
    if (!athlete) return 0;
    const weightStr = athlete[`podejscie${round}`];
    return parseFloat(String(weightStr).replace(',', '.')) || 0;
};

const hasAthleteCompletedAttemptInRound = (athlete, round) => {
    if (!athlete) return false;
    return !!athlete[`podejscie${round}Status`];
};

const hasAthleteCompletedAll = (athlete) => {
  if (!athlete) return false;
  return !!(athlete.podejscie1Status && athlete.podejscie2Status && athlete.podejscie3Status);
};

const getTrophyIcon = (rank) => {
    switch (rank) {
        case 1: return { name: 'trophy-award', color: '#FFD700' }; // Gold
        case 2: return { name: 'trophy-award', color: '#C0C0C0' }; // Silver
        case 3: return { name: 'trophy-award', color: '#CD7F32' }; // Bronze
        default: return null;
    }
};


export default function AthleteViewScreen() {
    const {
        zawodnicy,
        activeCategory,
        activeWeight,
        socket,
        activeAthleteOriginalIndex,
        activeAttemptNr,
        timerActive,
        timerTimeLeft,
        // setTimerTimeLeft, // setTimerTimeLeft nie jest używane bezpośrednio w tym komponencie
        zawody,
        attemptResultForAnimation,
        setAttemptResultForAnimation,
        clearAttemptResultForAnimation,
    } = useCompetitionStore(state => ({
        zawodnicy: state.zawodnicy,
        activeCategory: state.activeCategory,
        activeWeight: state.activeWeight,
        socket: state.socket,
        activeAthleteOriginalIndex: state.activeAthleteOriginalIndex,
        timerActive: state.timerActive,
        timerTimeLeft: state.timerTimeLeft,
        // setTimerTimeLeft: state.setTimerTimeLeft,
        activeAttemptNr: state.activeAttemptNr,
        zawody: state.zawody,
        attemptResultForAnimation: state.attemptResultForAnimation,
        setAttemptResultForAnimation: state.setAttemptResultForAnimation,
        clearAttemptResultForAnimation: state.clearAttemptResultForAnimation,
    }));

    const [showResultsForGroup, setShowResultsForGroup] = useState(null);
    const [showAnimation, setShowAnimation] = useState(false);
    const [animationSuccess, setAnimationSuccess] = useState(false); // Ta definicja jest kluczowa
    const animationTimeoutRef = useRef(null);

    // Listen for 'attemptAnimationTriggered' from CompetitionScreen (via server)
    // This effect sets the attemptResultForAnimation in the global store
    useEffect(() => {
        if (socket) {
            const handleAttemptAnimation = (data) => {
                console.log('[AthleteViewScreen] Received attemptAnimationTriggered via WebSocket:', data);
                // Warunek: animacja dla aktywnego zawodnika LUB jeśli nie ma aktywnego zawodnika (np. widok grupy, gdzie animacja może być globalna)
                // LUB jeśli dane animacji dotyczą zawodnika, który jest aktualnie aktywny na tym ekranie.
                // To jest ważne, aby uniknąć wyświetlania animacji dla zawodnika, który nie jest w centrum uwagi na tym ekranie.
                if (data && data.athleteOriginalIndex) { // Upewnij się, że dane animacji zawierają ID zawodnika
                    // Prosta logika: jeśli ekran widowni jest skupiony na konkretnym zawodniku, pokaż animację tylko dla niego.
                    // Jeśli nie ma aktywnego zawodnika (np. widok listy grupy), to nie pokazuj animacji (lub dostosuj logikę).
                    // Na potrzeby tego ekranu, animacja powinna dotyczyć `activeAthleteOriginalIndex`
                    if (data.athleteOriginalIndex === activeAthleteOriginalIndex) {
                         setAttemptResultForAnimation(data);
                    } else {
                        console.log(`[AthleteViewScreen] Animation data for ${data.athleteOriginalIndex} ignored, current active is ${activeAthleteOriginalIndex}`);
                    }
                }
            };

            socket.on('attemptAnimationTriggered', handleAttemptAnimation);

            return () => {
                socket.off('attemptAnimationTriggered', handleAttemptAnimation);
            };
        }
    }, [socket, setAttemptResultForAnimation, activeAthleteOriginalIndex]);

    // This effect reacts to changes in `attemptResultForAnimation` from the store
    // and controls the local animation display (showAnimation, animationSuccess)
    useEffect(() => {
        // Sprawdzamy, czy dane animacji istnieją i czy dotyczą aktualnie aktywnego zawodnika na tym ekranie
        if (attemptResultForAnimation && attemptResultForAnimation.athleteOriginalIndex === activeAthleteOriginalIndex) {
            console.log('[AthleteViewScreen] Store updated. Showing animation for:', attemptResultForAnimation);
            setAnimationSuccess(attemptResultForAnimation.success); // Ustawia stan lokalny na podstawie danych ze store
            setShowAnimation(true);                               // Ustawia stan lokalny na podstawie danych ze store

            if (animationTimeoutRef.current) {
                clearTimeout(animationTimeoutRef.current);
            }

            animationTimeoutRef.current = setTimeout(() => {
                setShowAnimation(false);
                // Ważne: wyczyść stan animacji w globalnym store, aby uniknąć ponownego wyzwolenia
                // jeśli komponent zostanie ponownie zrenderowany lub jeśli activeAthleteOriginalIndex się zmieni.
                clearAttemptResultForAnimation(); 
                console.log('[AthleteViewScreen] Animation finished, cleared attemptResultForAnimation from store.');
            }, 2000); // Czas trwania animacji
        } else if (!attemptResultForAnimation && showAnimation) {
            // Jeśli attemptResultForAnimation zostało wyczyszczone (np. przez timeout powyżej lub z innego miejsca),
            // a lokalny stan showAnimation jest nadal true, ukryj animację.
            setShowAnimation(false);
            console.log('[AthleteViewScreen] attemptResultForAnimation is null, hiding local animation.');
        }
        
        return () => {
            if (animationTimeoutRef.current) {
                clearTimeout(animationTimeoutRef.current);
            }
        };
    }, [attemptResultForAnimation, clearAttemptResultForAnimation, activeAthleteOriginalIndex]);


    // Listen for 'displayCategoryResults' from CompetitionScreen (via server)
    useEffect(() => {
        if (socket) {
            const handleDisplayResults = (data) => {
                console.log('[AthleteViewScreen] Received displayCategoryResults:', data);
                if (data && data.category && data.weightClass) {
                    if (useCompetitionStore.getState().activeAthleteOriginalIndex !== null) {
                        console.log("[AthleteViewScreen] Active athlete was set, but now showing group results. Active athlete context might be lost on CompetitionScreen.");
                    }
                    setShowResultsForGroup({ category: data.category, weight: data.weightClass });
                    console.log(`[AthleteViewScreen] Setting showResultsForGroup to: ${data.category} - ${data.weightClass}`);
                }
            };
            socket.on('displayCategoryResults', handleDisplayResults);
            return () => socket.off('displayCategoryResults', handleDisplayResults);
        }
    }, [socket]);

    const currentAthlete = useMemo(() => {
        if (activeAthleteOriginalIndex === null || !zawodnicy || zawodnicy.length === 0) return null;
        return zawodnicy.find(z => z.originalIndex === activeAthleteOriginalIndex);
    }, [zawodnicy, activeAthleteOriginalIndex]);

    const groupAthletes = useMemo(() => {
        if (!activeCategory || !activeWeight || !zawodnicy) return [];
        return zawodnicy
            .filter(z => z.kategoria === activeCategory && z.waga === activeWeight)
            .map(z => ({...z, isCompleted: hasAthleteCompletedAll(z) }))
            .sort((a, b) => {
                if (a.isCompleted !== b.isCompleted) return a.isCompleted ? 1 : -1;
                const weightA = parseFloat(String(a.podejscie1).replace(',', '.')) || Infinity;
                const weightB = parseFloat(String(b.podejscie1).replace(',', '.')) || Infinity;
                return weightA - weightB;
            });
    }, [zawodnicy, activeCategory, activeWeight]);

    useEffect(() => {
        if (activeCategory && activeWeight && activeAthleteOriginalIndex === null && !showResultsForGroup) {
            const allCompletedInGroup = groupAthletes.length > 0 && groupAthletes.every(a => a.isCompleted);
            if (allCompletedInGroup) {
                console.log(`[AthleteViewScreen] Auto-displaying results for just completed group: ${activeCategory} - ${activeWeight}kg.`);
                setShowResultsForGroup({ category: activeCategory, weight: activeWeight });
            }
        }
    }, [zawodnicy, activeCategory, activeWeight, groupAthletes, showResultsForGroup, activeAthleteOriginalIndex]);

    useEffect(() => {
        if (showResultsForGroup) {
            if (activeAthleteOriginalIndex !== null) {
                console.log('[AthleteViewScreen] Active athlete selected, hiding category results.');
                setShowResultsForGroup(null);
            } else if (activeCategory !== null && activeWeight !== null) {
                if (activeCategory !== showResultsForGroup.category || activeWeight !== showResultsForGroup.weight) {
                    console.log(`[AthleteViewScreen] Judge's active group changed to ${activeCategory}-${activeWeight}, hiding results for ${showResultsForGroup.category}-${showResultsForGroup.weight}.`);
                    setShowResultsForGroup(null);
                }
            } else if (activeCategory === null && activeWeight === null) {
                console.log(`[AthleteViewScreen] Judge cleared active group. Hiding results.`);
                setShowResultsForGroup(null);
            }
        }
    }, [activeAthleteOriginalIndex, activeCategory, activeWeight, showResultsForGroup]);

    // ... (reszta useMemo dla nextAthleteData, podiumAthletes, currentGroupResultsData bez zmian) ...
    const nextAthleteData = useMemo(() => {
        if (!currentAthlete || !activeCategory || !activeWeight || !zawodnicy || zawodnicy.length === 0) {
            return null;
        }
        const currentGlobalRound = activeAttemptNr;
        const athletesInCurrentGroup = zawodnicy.filter(
            z => z.kategoria === activeCategory && z.waga === activeWeight
        );
        if (athletesInCurrentGroup.length === 0) return null;
        let foundNextAthlete = null;
        let nextAthleteRound = currentGlobalRound;
        const sortedForCurrentRound = [...athletesInCurrentGroup]
            .filter(athlete => athlete.originalIndex !== currentAthlete.originalIndex && !hasAthleteCompletedAttemptInRound(athlete, currentGlobalRound))
            .sort((a, b) => {
                const weightA = getAthleteDeclaredWeightForRound(a, currentGlobalRound);
                const weightB = getAthleteDeclaredWeightForRound(b, currentGlobalRound);
                if (weightA === weightB) return String(a.originalIndex).localeCompare(String(b.originalIndex));
                return weightA - weightB;
            });

        if (sortedForCurrentRound.length > 0) {
            foundNextAthlete = sortedForCurrentRound[0];
        } else if (currentGlobalRound < 3) {
            const nextRoundNumber = currentGlobalRound + 1;
            const sortedForNextRound = [...athletesInCurrentGroup]
                .filter(athlete => !hasAthleteCompletedAttemptInRound(athlete, nextRoundNumber))
                .sort((a, b) => {
                    const weightA = getAthleteDeclaredWeightForRound(a, nextRoundNumber);
                    const weightB = getAthleteDeclaredWeightForRound(b, nextRoundNumber);
                    if (weightA === weightB) return String(a.originalIndex).localeCompare(String(b.originalIndex));
                    return weightA - weightB;
                });
            if (sortedForNextRound.length > 0) {
                foundNextAthlete = sortedForNextRound[0];
                nextAthleteRound = nextRoundNumber;
            }
        }
        if (foundNextAthlete) {
            const declaredWeight = getAthleteDeclaredWeightForRound(foundNextAthlete, nextAthleteRound);
            return {
                imie: foundNextAthlete.imie,
                nazwisko: foundNextAthlete.nazwisko,
                klub: foundNextAthlete.klub || 'Brak klubu',
                attemptInfo: `Runda ${nextAthleteRound} (${declaredWeight ? String(declaredWeight).replace(',', '.') + 'kg' : 'Brak deklaracji'})`,
            };
        }
        return null;
    }, [currentAthlete, zawodnicy, activeCategory, activeWeight, activeAttemptNr]);

    const podiumAthletes = useMemo(() => {
        if (!activeCategory || !activeWeight || !zawodnicy || zawodnicy.length === 0) {
            return [];
        }
        const athletesInCatWeight = zawodnicy.filter(
            z => z.kategoria === activeCategory && z.waga === activeWeight
        );
        if (athletesInCatWeight.length === 0) return [];
        const rankedAndFiltered = athletesInCatWeight
            .map(athlete => {
                let bestLift = 0;
                if (athlete.podejscie1Status === 'passed') bestLift = Math.max(bestLift, getAthleteDeclaredWeightForRound(athlete, 1));
                if (athlete.podejscie2Status === 'passed') bestLift = Math.max(bestLift, getAthleteDeclaredWeightForRound(athlete, 2));
                if (athlete.podejscie3Status === 'passed') bestLift = Math.max(bestLift, getAthleteDeclaredWeightForRound(athlete, 3));
                return { ...athlete, bestLift };
            })
            .sort((a, b) => {
                if (b.bestLift !== a.bestLift) return b.bestLift - a.bestLift;
                const bodyWeightA = parseFloat(String(a.wagaCiala).replace(',', '.')) || Infinity;
                const bodyWeightB = parseFloat(String(b.wagaCiala).replace(',', '.')) || Infinity;
                if (bodyWeightA !== bodyWeightB) return bodyWeightA - bodyWeightB;
                return (a.originalIndex || String(a.id)).localeCompare(String(b.originalIndex || String(b.id)));
            })
            .slice(0, 3)
            .map((athlete, index) => ({ ...athlete, rank: index + 1, }));
        return rankedAndFiltered;
    }, [zawodnicy, activeCategory, activeWeight]);

    const shouldShowNextUp = currentAthlete && nextAthleteData && !showResultsForGroup;

    const currentGroupResultsData = useMemo(() => {
        if (!showResultsForGroup || !zawodnicy) return [];
        const { category, weight } = showResultsForGroup;
        const athletesForTable = zawodnicy.filter(z => z.kategoria === category && z.waga === weight);
        if (athletesForTable.length === 0) return [];

        const processed = processAthletesForResults(athletesForTable);
        const sorted = sortIndividualResults(processed);
        return sorted.map((athlete, index) => ({ ...athlete, rank: index + 1 }));
    }, [showResultsForGroup, zawodnicy]);


    if (showResultsForGroup) {
        // ... (JSX dla widoku wyników grupy bez zmian) ...
        return (
            <View style={[styles.container, styles.resultsViewContainer]}>
                <Text style={styles.resultsTitle}>
                    Wyniki Grupy: {showResultsForGroup.category} - {showResultsForGroup.weight} kg
                </Text>
                {currentGroupResultsData.length > 0 ? (
                    <ScrollView>
                        <IndividualResultsTable data={currentGroupResultsData} />
                    </ScrollView>
                ) : (
                    <Text style={styles.placeholderText}>Brak danych do wyświetlenia dla tej grupy.</Text>
                )}
                <TouchableOpacity
                    style={styles.closeResultsButton}
                    onPress={() => {
                        setShowResultsForGroup(null);
                    }}
                >
                    <MaterialCommunityIcons name="close-circle-outline" size={24} color={colors.textLight} />
                    <Text style={styles.closeResultsButtonText}>Zamknij Wyniki</Text>
                </TouchableOpacity>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.mainContent}>
                {currentAthlete && !showResultsForGroup ? (
                    <View style={styles.athleteDetailContainer}>
                        <View style={styles.athleteInfoRow}>
                            <View style={styles.leftColumnInInfoRow}>
                                <View style={styles.currentRoundInfo}>
                                    <Text style={styles.currentRoundLabel}>Runda</Text>
                                    <Text style={styles.currentRoundNumber}>{activeAttemptNr || '1'}</Text>
                                </View>
                                <View style={styles.podiumContainer}>
                                    <Text style={styles.podiumTitle}>Top 3</Text>
                                    {podiumAthletes.length > 0 ? podiumAthletes.map(athlete => {
                                        const trophy = getTrophyIcon(athlete.rank);
                                        return (
                                            <View key={athlete.originalIndex || athlete.rank} style={styles.podiumAthlete}>
                                                {trophy && <MaterialCommunityIcons name={trophy.name} size={font.sizes.lg} color={trophy.color} style={styles.trophyIconSmall} />}
                                                <Text style={styles.podiumRank}>{athlete.rank}.</Text>
                                                <Text style={styles.podiumAthleteName} numberOfLines={1}>
                                                    {athlete.imie} {athlete.nazwisko}
                                                </Text>
                                                {athlete.bestLift > 0 && (
                                                    <Text style={styles.podiumAthleteLift}>
                                                        ({athlete.bestLift} kg)
                                                    </Text>
                                                )}
                                            </View>
                                        );
                                    }) : (
                                        <Text style={styles.podiumAthleteName}>Brak danych podium</Text>
                                    )}
                                </View>
                            </View>

                            <View style={styles.centerColumnInInfoRow}>
                                <View style={styles.athleteInfoCard}>
                                    <Text style={styles.athleteName}>
                                        <Text style={styles.athleteNameHighlight}>{currentAthlete.imie} {currentAthlete.nazwisko}</Text>
                                    </Text>
                                    <Text style={styles.athleteClub}>{currentAthlete.klub || 'Brak klubu'}</Text>
                                    <Text style={styles.athleteCategory}>
                                        Kat. wiek.: <Text style={styles.categoryValueHighlight}>{currentAthlete.kategoria}</Text>
                                    </Text>
                                    <Text style={styles.athleteCategory}>
                                        Kat. wag.: <Text style={styles.weightValueHighlight}>{currentAthlete.waga} kg</Text>
                                    </Text>
                                    {currentAthlete.wagaCiala && (
                                        <Text style={styles.athleteCategory}>
                                            Waga ciała: <Text style={styles.bodyWeightValueHighlight}>{String(currentAthlete.wagaCiala).replace(',', '.')} kg</Text>
                                        </Text>
                                    )}
                                </View>
                            </View>

                            {shouldShowNextUp && nextAthleteData ? (
                                <View style={styles.rightColumnInInfoRow}>
                                    <View style={styles.nextUpContainer}>
                                        <Text style={styles.nextUpTitle}>Następny Zawodnik</Text>
                                        <Text style={styles.nextUpAthleteName}>
                                            {nextAthleteData.imie} {nextAthleteData.nazwisko}
                                        </Text>
                                        <Text style={styles.nextUpAthleteInfo}>
                                            Klub: {nextAthleteData.klub} | {nextAthleteData.attemptInfo}
                                        </Text>
                                    </View>
                                </View>
                            ) : (
                                <View style={styles.rightColumnInInfoRow} />
                            )}
                        </View>

                        <View style={styles.attemptsContainer}>
                            {[1, 2, 3].map((nr) => (
                                <AttemptDisplay
                                    key={`${currentAthlete.originalIndex}-${nr}`}
                                    number={nr}
                                    weight={currentAthlete[`podejscie${nr}`]}
                                    status={currentAthlete[`podejscie${nr}Status`]}
                                    isActive={activeAttemptNr === nr && !currentAthlete[`podejscie${nr}Status`]}
                                />
                            ))}
                        </View>

                        <View style={styles.timerSection}>
                            <AthleteViewTimerDisplay isActive={timerActive} timeLeft={timerTimeLeft} />
                        </View>
                    </View>
                ) : activeCategory && activeWeight && !showResultsForGroup ? (
                     <View style={styles.groupViewContainer}>
                         <GroupAthleteList
                            athletes={groupAthletes}
                            currentAthleteOriginalIndex={activeAthleteOriginalIndex}
                         />
                    </View>
                ) : (
                    <View style={styles.placeholderContainer}>
                        <Text style={styles.placeholderText}>Wybierz kategorię i wagę w panelu sędziego, aby zobaczyć listę zawodników lub aktywnego zawodnika.</Text>
                        <Text style={[styles.placeholderText, {fontSize: font.sizes['5xl'] || 48, marginTop: spacing.lg}]}>🏆</Text>
                    </View>
                )}
            </View>
            {showAnimation && (
                <View style={styles.animationOverlay}>
                    {/* Dodaj ten log */}
                    {console.log('[AthleteViewScreen] Rendering AttemptResultAnimation. showAnimation:', showAnimation, 'animationSuccess:', animationSuccess)}
                    <AttemptResultAnimation success={animationSuccess} />
                </View>
            )}
            {zawody && (zawody.klubAvatar || zawody.sedzia?.avatar) && (
                <View style={styles.organizersContainer}>
                    <Text style={styles.organizersTitle}>Organizatorzy:</Text>
                    <View style={styles.organizersLogos}>
                        {zawody.klubAvatar && (
                            <Image source={{ uri: zawody.klubAvatar }} style={[styles.organizerLogo, { resizeMode: 'cover' }]} />
                        )}
                        {zawody.sedzia?.avatar && (
                            <Image source={{ uri: zawody.sedzia.avatar }} style={[styles.organizerLogo, { resizeMode: 'cover' }]} />
                        )}
                    </View>
                </View>
            )}
        </View>
    );
}