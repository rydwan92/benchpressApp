import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react'; // Ensure useRef is imported
import { ScrollView, View, Text, TouchableOpacity, Alert, ActivityIndicator, Platform, Image, Modal, Pressable } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import  useCompetitionStore  from '../store/useCompetitionStore';
import { saveAppData } from '../utils/api';
import NavBar from '../components/navigation/NavBar';
import Footer from '../components/competition/FooterComp';
import OptionSelector from '../components/competition/OptionSelector';
import AthleteList from '../components/competition/AthleteList';
import CurrentAthleteManager from '../components/competition/CurrentAthleteManager';
import TimerDisplay from '../components/competition/TimerDisplay';
import AttemptResultAnimation from '../components/competition/AttemptResultAnimation';
import { styles } from '../styles/CompetitionStyles/CompetitionScreen.styles';
import { colors, spacing, font } from '../theme/theme';
import { AntDesign, MaterialCommunityIcons } from '@expo/vector-icons';
import { sharedHeaderStyles, sharedMainContentStyles } from '../theme/sharedStyles';

const MAX_TIMER_SECONDS = 60;

const getAthleteDeclaredWeightForRound = (athlete, round) => {
    if (!athlete) return 0;
    const weightStr = athlete[`podejscie${round}`];
    return parseFloat(String(weightStr).replace(',', '.')) || 0;
};

const hasAthleteCompletedAttemptInRound = (athlete, round) => {
    if (!athlete) return false;
    return !!athlete[`podejscie${round}Status`];
};

const hasAthleteCompletedAllAttempts = (athlete) => {
    if (!athlete) return false;
    return !!(athlete.podejscie1Status && athlete.podejscie2Status && athlete.podejscie3Status);
};

export default function CompetitionScreen() {
  const navigation = useNavigation();
  const {
    zawody, kategorie, zawodnicy,
    activeCategory, activeWeight, activeAthleteOriginalIndex, activeAttemptNr,
    currentRound, timerActive: storeTimerActive, timerTimeLeft: storeTimerTimeLeft,
    updatePodejscieStatus, updatePodejscieWaga,
    setActiveAthlete,
    setActiveGroup, // DODAJ setActiveGroup TUTAJ
    setCurrentRound,
    setTimerActive: storeSetTimerActive,
    setTimerTimeLeft: storeSetTimerTimeLeft,
    socket,
    setAttemptResultForAnimation,
  } = useCompetitionStore(state => ({
      zawody: state.zawody,
      kategorie: state.kategorie,
      zawodnicy: state.zawodnicy,
      activeCategory: state.activeCategory,
      activeWeight: state.activeWeight,
      activeAthleteOriginalIndex: state.activeAthleteOriginalIndex,
      activeAttemptNr: state.activeAttemptNr,
      currentRound: state.currentRound,
      timerActive: state.timerActive,
      timerTimeLeft: state.timerTimeLeft,
      updatePodejscieStatus: state.updatePodejscieStatus,
      updatePodejscieWaga: state.updatePodejscieWaga,
      setActiveAthlete: state.setActiveAthlete,
      setActiveGroup: state.setActiveGroup, // DODAJ setActiveGroup TUTAJ
      setCurrentRound: state.setCurrentRound,
      setTimerActive: state.setTimerActive,
      setTimerTimeLeft: state.setTimerTimeLeft,
      socket: state.socket,
      setAttemptResultForAnimation: state.setAttemptResultForAnimation,
  }));

  // Use the state directly from the hook for timerActive and timerTimeLeft
  const timerActive = useCompetitionStore(state => state.timerActive);
  const timerTimeLeft = useCompetitionStore(state => state.timerTimeLeft);

  const [isSaving, setIsSaving] = useState(false);
  const [headerKlubAvatarDimensions, setHeaderKlubAvatarDimensions] = useState(null); // Punkt 9
  const [headerJudgeAvatarDimensions, setHeaderJudgeAvatarDimensions] = useState(null); // Punkt 9
  const timerIntervalRef = useRef(null);

  const [showAttemptAnimation, setShowAttemptAnimation] = useState(false);
  const [attemptAnimationSuccess, setAttemptAnimationSuccess] = useState(false);
  const animationTimeoutRef = useRef(null);

  const [isResultsModalVisible, setIsResultsModalVisible] = useState(false);
  const [modalSelectedCategory, setModalSelectedCategory] = useState(null);
  const [modalSelectedWeight, setModalSelectedWeight] = useState(null);

  const ignoreNextAthleteSelectionRef = useRef(false); // New ref

  // Inicjalizacja modala aktywną kategorią/wagą
  useEffect(() => {
    if (activeCategory) {
      setModalSelectedCategory(activeCategory);
    }
    if (activeWeight) {
      setModalSelectedWeight(activeWeight);
    }
  }, [activeCategory, activeWeight]);

  const modalCategoryOptions = useMemo(() => kategorie.map(k => ({ label: k.nazwa, value: k.nazwa })), [kategorie]);
  
  const modalWeightOptions = useMemo(() => {
    if (!modalSelectedCategory) return [];
    const categoryObj = kategorie.find(k => k.nazwa === modalSelectedCategory);
    return categoryObj ? categoryObj.wagi.map(w => ({ label: String(w), value: w })) : [];
  }, [kategorie, modalSelectedCategory]);

  const syncData = useCallback(async (dataToSync) => {
    setIsSaving(true);
    try {
      const currentState = useCompetitionStore.getState();
      const { socket: currentSocket, attemptResultForAnimation: currentAnimation, ...restOfState } = currentState;
      let dataToSend = { ...restOfState };
      if (dataToSync && typeof dataToSync === 'object') {
        dataToSend = { ...dataToSend, ...dataToSync };
      }
      await saveAppData(dataToSend);
    } catch (error) {
      console.error('[CompetitionScreen] Błąd synchronizacji danych:', error);
      Alert.alert("Błąd", "Nie udało się zsynchronizować danych z serwerem.");
    } finally {
      setIsSaving(false);
    }
  }, [setIsSaving]); // Removed useCompetitionStore from dependencies as getState is used

  const handleShowResultsOnAthleteView = async () => {
    if (socket && socket.connected && modalSelectedCategory && modalSelectedWeight) {
      console.log(`[CompetitionScreen] Requesting to show results for ${modalSelectedCategory} - ${modalSelectedWeight}kg`);
      
      ignoreNextAthleteSelectionRef.current = true; // Set flag to ignore the next automatic athlete selection

      setActiveAthlete(null); 
      
      const currentGlobalRound = useCompetitionStore.getState().currentRound;
      const dataToSyncForResults = { 
        activeAthleteOriginalIndex: null,
        activeCategory: modalSelectedCategory,
        activeWeight: modalSelectedWeight,
        activeAttemptNr: currentGlobalRound
      };
      
      console.log('[CompetitionScreen] Syncing data for results view:', dataToSyncForResults);
      await syncData(dataToSyncForResults);

      console.log(`[CompetitionScreen] Emitting showCategoryResults for ${modalSelectedCategory} - ${modalSelectedWeight}kg`);
      socket.emit('showCategoryResults', {
        category: modalSelectedCategory,
        weightClass: modalSelectedWeight,
      });
      setIsResultsModalVisible(false);
    } else {
      Alert.alert("Błąd", "Nie można wysłać żądania. Sprawdź połączenie lub wybrane opcje.");
    }
  };

  const stableSetTimerTimeLeft = useCallback((value) => storeSetTimerTimeLeft(value), [storeSetTimerTimeLeft]);
  const stableSetTimerActive = useCallback((value) => storeSetTimerActive(value), [storeSetTimerActive]);

  const handleResetTimer = useCallback(async () => {
    if (isSaving || showAttemptAnimation) {
        Alert.alert("Uwaga", "Nie można zresetować timera podczas zapisu lub animacji.");
        return;
    }
    stableSetTimerActive(false);
    stableSetTimerTimeLeft(MAX_TIMER_SECONDS);
    if (socket && socket.connected) {
      socket.emit('timerReset', { timeLeft: MAX_TIMER_SECONDS });
    }
  }, [isSaving, showAttemptAnimation, stableSetTimerActive, stableSetTimerTimeLeft, socket]);

  const handleSelectAthlete = useCallback(async (selectedAthleteOriginalIndex) => {
    if (ignoreNextAthleteSelectionRef.current) {
      ignoreNextAthleteSelectionRef.current = false; // Consume the flag
      console.log('[CompetitionScreen] Ignoring first athlete selection after requesting results view.');
      return; // Prevent this selection
    }

    // Any deliberate action should clear the "ignore" flag if it was somehow still true.
    ignoreNextAthleteSelectionRef.current = false;

    if (timerActive) {
      Alert.alert("Timer Aktywny", "Nie można zmienić zawodnika podczas aktywnego czasu.");
      return;
    }
    if (isSaving) return;
    
    console.log(`[CompetitionScreen] handleSelectAthlete called with: ${selectedAthleteOriginalIndex}.`);
    setActiveAthlete(selectedAthleteOriginalIndex);
    await syncData({ activeAthleteOriginalIndex: selectedAthleteOriginalIndex, activeAttemptNr: useCompetitionStore.getState().currentRound });
  }, [setActiveAthlete, syncData, timerActive, isSaving, /* other dependencies */]);

  const handleTimerFinish = useCallback(() => {
    stableSetTimerActive(false);
    stableSetTimerTimeLeft(0);
    if (socket && socket.connected) {
      // FIX: Add athleteOriginalIndex
      socket.emit('stopTimer', { 
        finalTimeLeft: 0, 
        reason: 'natural_finish',
        athleteOriginalIndex: useCompetitionStore.getState().activeAthleteOriginalIndex 
      });
    }
  }, [stableSetTimerActive, stableSetTimerTimeLeft, socket]);

  useEffect(() => {
    const currentTimerActive = useCompetitionStore.getState().timerActive; // Get current state
    if (currentTimerActive) {
      timerIntervalRef.current = setInterval(() => {
        const currentTimeInStore = useCompetitionStore.getState().timerTimeLeft;
        const currentActiveAthleteIndex = useCompetitionStore.getState().activeAthleteOriginalIndex; // Get current active athlete

        if (typeof currentTimeInStore !== 'number' || isNaN(currentTimeInStore)) {
          stableSetTimerTimeLeft(MAX_TIMER_SECONDS);
          return;
        }
        const newTime = currentTimeInStore - 1;
        stableSetTimerTimeLeft(newTime);
        if (socket && socket.connected) {
          // FIX: Send athleteOriginalIndex with timerTick
          socket.emit('timerTick', { 
            timeLeft: newTime, 
            athleteOriginalIndex: currentActiveAthleteIndex 
          });
        }
        if (newTime <= 0) {
          clearInterval(timerIntervalRef.current);
          timerIntervalRef.current = null;
          handleTimerFinish(); // handleTimerFinish will emit stopTimer
        }
      }, 1000);
    } else {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    }
    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    };
  }, [timerActive, stableSetTimerActive, stableSetTimerTimeLeft, socket, handleTimerFinish]);

  const athletesInCurrentGroup = useMemo(() => {
    if (!activeCategory || !activeWeight || !zawodnicy) return [];
    return zawodnicy
      .filter(z => z.kategoria === activeCategory && z.waga === activeWeight);
  }, [zawodnicy, activeCategory, activeWeight]);

  const upcomingAthletesForCurrentRound = useMemo(() => {
    if (!activeCategory || !activeWeight || currentRound > 3) return [];
    return athletesInCurrentGroup
      .filter(athlete => !hasAthleteCompletedAttemptInRound(athlete, currentRound))
      .sort((a, b) => {
        const weightA = getAthleteDeclaredWeightForRound(a, currentRound);
        const weightB = getAthleteDeclaredWeightForRound(b, currentRound);
        if (weightA === weightB) return a.originalIndex - b.originalIndex;
        return weightA - weightB;
      });
  }, [athletesInCurrentGroup, currentRound, activeCategory, activeWeight]);

  const currentAthlete = useMemo(() => {
    if (activeAthleteOriginalIndex === null || !zawodnicy || zawodnicy.length === 0) return null;
    return zawodnicy.find(z => z.originalIndex === activeAthleteOriginalIndex); // POPRAWKA: Wyszukaj po string ID
  }, [zawodnicy, activeAthleteOriginalIndex]);

  const handleNextCompetitor = useCallback(async () => {
    if (timerActive || isSaving || showAttemptAnimation) {
      Alert.alert("Uwaga", "Nie można zmienić zawodnika podczas aktywnego timera, zapisu lub animacji.");
      return;
    }
    if (!activeCategory || !activeWeight) {
      Alert.alert("Informacja", "Wybierz najpierw kategorię i wagę.");
      return;
    }
    const nextAthletesInCurrentList = upcomingAthletesForCurrentRound;
    if (nextAthletesInCurrentList.length > 0) {
      const nextAthleteToCall = nextAthletesInCurrentList[0];
      setActiveAthlete(nextAthleteToCall.originalIndex);
      await syncData({ activeAthleteOriginalIndex: nextAthleteToCall.originalIndex, activeAttemptNr: currentRound });
    } else {
      Alert.alert("Informacja", "Brak kolejnych zawodników w tej rundzie dla wybranej grupy.");
    }
  }, [currentRound, timerActive, isSaving, showAttemptAnimation, upcomingAthletesForCurrentRound, setActiveAthlete, syncData, activeCategory, activeWeight]);

  // Punkt 7: Dodanie handlePreviousCompetitor
  const handlePreviousCompetitor = useCallback(async () => {
    if (timerActive || isSaving || showAttemptAnimation) {
        Alert.alert("Uwaga", "Nie można zmienić zawodnika podczas aktywnego timera, zapisu lub animacji.");
        return;
    }
    if (!activeCategory || !activeWeight || !currentAthlete) {
        Alert.alert("Informacja", "Brak aktywnego zawodnika lub grupy do nawigacji wstecz.");
        return;
    }

    const currentIndexInGroup = displayAthletesInGroup.findIndex(a => a.originalIndex === activeAthleteOriginalIndex);
    if (currentIndexInGroup > 0) {
        const previousAthlete = displayAthletesInGroup[currentIndexInGroup - 1];
        setActiveAthlete(previousAthlete.originalIndex);
        await syncData({ activeAthleteOriginalIndex: previousAthlete.originalIndex, activeAttemptNr: currentRound });
    } else {
        Alert.alert("Informacja", "To jest pierwszy zawodnik w tej grupie.");
    }
  }, [timerActive, isSaving, showAttemptAnimation, activeCategory, activeWeight, currentAthlete, displayAthletesInGroup, setActiveAthlete, syncData, currentRound, activeAthleteOriginalIndex]);


  const handlePreviousRound = useCallback(async () => {
    if (isSaving || timerActive || showAttemptAnimation) return;
    if (currentRound > 1) {
      const prevRound = currentRound - 1;
      setCurrentRound(prevRound);
      await syncData({ currentRound: prevRound, activeAthleteOriginalIndex: null, activeAttemptNr: prevRound });
    } else {
      Alert.alert("Informacja", "Jesteś już na pierwszej rundzie.");
    }
  }, [currentRound, setCurrentRound, syncData, isSaving, timerActive, showAttemptAnimation]);

  const handleNextRound = useCallback(async () => {
    if (isSaving || timerActive || showAttemptAnimation) return;
    if (currentRound < 3) {
      const nextRound = currentRound + 1;
      setCurrentRound(nextRound);
      await syncData({ currentRound: nextRound, activeAthleteOriginalIndex: null, activeAttemptNr: nextRound });
    } else {
      Alert.alert("Informacja", "Jesteś już na ostatniej, trzeciej rundzie.");
    }
  }, [currentRound, setCurrentRound, syncData, isSaving, timerActive, showAttemptAnimation]);

  useEffect(() => {
    if (activeAthleteOriginalIndex === null && upcomingAthletesForCurrentRound.length > 0 && !timerActive && !showAttemptAnimation && activeCategory && activeWeight) {
      handleNextCompetitor();
    }
  }, [activeAthleteOriginalIndex, upcomingAthletesForCurrentRound, timerActive, showAttemptAnimation, activeCategory, activeWeight, handleNextCompetitor]);

  const handleAttemptStatusChange = useCallback(async (athleteOriginalIndex, attemptNo, status) => {
    if (isSaving) return;
    setIsSaving(true);
    setShowAttemptAnimation(true);
    setAttemptAnimationSuccess(status === 'passed');

    updatePodejscieStatus(athleteOriginalIndex, attemptNo, status);
    const animationData = { success: status === 'passed', athleteOriginalIndex: athleteOriginalIndex, attemptNo: attemptNo }; 
    if (socket && socket.connected) {
      // OLD: socket.emit('triggerAttemptAnimation', animationData); 
      // NEW: Match the listener in AthleteViewScreen.js
      socket.emit('attemptAnimationTriggered', animationData); 
    }
    setAttemptResultForAnimation(animationData);

    // Clear any existing timeout
    if (animationTimeoutRef.current) {
      clearTimeout(animationTimeoutRef.current);
    }

    animationTimeoutRef.current = setTimeout(async () => {
      setShowAttemptAnimation(false);
      const currentStoreState = useCompetitionStore.getState();
      const currentStoreActiveAthleteOriginalIndex = currentStoreState.activeAthleteOriginalIndex;
      const currentStoreActiveAttemptNr = currentStoreState.activeAttemptNr;

      // Automatyczne przejście do następnego tylko jeśli to było aktywne podejście
      // i jeśli status to 'passed' lub 'failed' (czyli podejście zakończone)
      if (status === 'passed' || status === 'failed') {
        if (athleteOriginalIndex === currentStoreActiveAthleteOriginalIndex && attemptNo === currentStoreActiveAttemptNr) {
            // Dodano opóźnienie przed próbą przejścia do następnego zawodnika, aby animacja miała czas się zakończyć
            // setTimeout(async () => {
                 await handleNextCompetitor();
            // }, 500); // Krótkie opóźnienie, np. 500ms
        }
      }
      setIsSaving(false);
    }, 2000); // Czas trwania animacji + ewentualny bufor

    if (socket && socket.connected) {
      // This event is for general data sync, not animation trigger
      socket.emit('attemptUpdated', { athleteOriginalIndex, attemptNo, status });
    }
    // Sync all data after changes
    const finalStateForSync = (({ socket: s, attemptResultForAnimation: a, ...rest }) => rest)(useCompetitionStore.getState());
    await syncData(finalStateForSync);
  }, [isSaving, stableSetTimerActive, updatePodejscieStatus, handleNextCompetitor, socket, setAttemptResultForAnimation, syncData, setShowAttemptAnimation, setAttemptAnimationSuccess, animationTimeoutRef]);

  const handleWeightChange = useCallback(async (athleteOriginalIndex, attemptNo, weight) => {
    if (isSaving) return;
    setIsSaving(true);
    updatePodejscieWaga(athleteOriginalIndex, attemptNo, weight);
    if (socket && socket.connected) {
      socket.emit('weightUpdated', { athleteOriginalIndex, attemptNo, weight });
    }
    await syncData();
    setIsSaving(false);
  }, [isSaving, updatePodejscieWaga, syncData, socket]);

  const handleStartOrRestartAttempt = useCallback(async () => {
    ignoreNextAthleteSelectionRef.current = false; // Clear flag
    if (!currentAthlete || isSaving || showAttemptAnimation) {
      // console.log('[CompetitionScreen] Start/Restart blocked: no current athlete, saving, or animation.');
      return;
    }

    const currentState = useCompetitionStore.getState(); // Get fresh state
    const currentStoreTimerTimeLeft = currentState.timerTimeLeft;
    const currentStoreTimerActive = currentState.timerActive;
    const currentStoreAthleteOriginalIndex = currentState.activeAthleteOriginalIndex;
    const currentStoreActiveAttemptNr = currentState.activeAttemptNr;
    const currentStoreCurrentRound = currentState.currentRound;

    if (currentStoreTimerActive) {
      // console.log('[CompetitionScreen] Timer is already active. No action taken by handleStartOrRestartAttempt.');
      return; // Do nothing if timer is already running
    }

    if (currentStoreActiveAttemptNr !== currentStoreCurrentRound) {
      Alert.alert("Uwaga", `Próbujesz uruchomić timer dla podejścia ${currentStoreActiveAttemptNr}, ale aktualna runda to ${currentStoreCurrentRound}. Zmień rundę lub zawodnika.`);
      return;
    }

    let timeToStartFrom = MAX_TIMER_SECONDS;
    let isResuming = false;

    // Check if we should resume from a previously stopped time
    if (currentStoreTimerTimeLeft > 0 && currentStoreTimerTimeLeft < MAX_TIMER_SECONDS) {
      timeToStartFrom = currentStoreTimerTimeLeft;
      isResuming = true;
      console.log(`[CompetitionScreen] Resuming timer from: ${timeToStartFrom}s for athlete ${currentStoreAthleteOriginalIndex}`);
    } else {
      console.log(`[CompetitionScreen] Starting timer from MAX: ${timeToStartFrom}s for athlete ${currentStoreAthleteOriginalIndex}`);
    }

    stableSetTimerTimeLeft(timeToStartFrom); // Update store state
    stableSetTimerActive(true);             // Update store state

    if (socket && socket.connected) {
      socket.emit('startTimer', {
        timeLeft: timeToStartFrom,
        athleteId: currentStoreAthleteOriginalIndex,
        attemptNr: currentStoreActiveAttemptNr,
        isResuming: isResuming // Send isResuming status
      });
      console.log(`[CompetitionScreen] 'startTimer' event emitted. Resuming: ${isResuming}, Time: ${timeToStartFrom}`);
    }
  }, [/* ... dependencies ... */]);

  const handleSelectCategory = useCallback(async (category) => {
    ignoreNextAthleteSelectionRef.current = false; // Clear flag on context change
    setActiveGroup(category, null); // Ta linia powodowała błąd
    await syncData({ activeCategory: category, activeWeight: null, activeAthleteOriginalIndex: null, currentRound: 1, activeAttemptNr: 1 });
  }, [setActiveGroup, syncData]);

  const handleSelectWeight = useCallback(async (weight) => {
    if (!activeCategory) {
      Alert.alert("Błąd", "Najpierw wybierz kategorię.");
      return;
    }
    ignoreNextAthleteSelectionRef.current = false; // Clear flag on context change
    setActiveGroup(activeCategory, weight); // Ta linia powodowała błąd
    await syncData({ activeWeight: weight, activeAthleteOriginalIndex: null, currentRound: 1, activeAttemptNr: 1 });
  }, [activeCategory, setActiveGroup, syncData]);

  const categoryOptions = useMemo(() => kategorie.map(k => ({ label: k.nazwa, value: k.nazwa })), [kategorie]);
  const activeCategoryObject = useMemo(() => kategorie.find(k => k.nazwa === activeCategory), [kategorie, activeCategory]);

  const completedWeights = useMemo(() => {
    const completed = new Set();
      if (!activeCategoryObject || !zawodnicy) return completed;
      activeCategoryObject.wagi.forEach(waga => {
          const athletesInGroup = zawodnicy.filter(z => z.kategoria === activeCategory && z.waga === waga);
          if (athletesInGroup.length > 0 && athletesInGroup.every(hasAthleteCompletedAllAttempts)) completed.add(waga);
      });
      return completed;
  }, [activeCategoryObject, zawodnicy, activeCategory]);

  const weightOptions = useMemo(() => {
    if (!activeCategoryObject) return [];
    return [...activeCategoryObject.wagi].sort((a, b) => Number(a) - Number(b)).map(w => ({
        label: String(w), value: w, isCompleted: completedWeights.has(w)
    }));
  }, [activeCategoryObject, completedWeights]);

  const displayAthletesInGroup = useMemo(() => {
    if (!athletesInCurrentGroup) return []; // athletesInCurrentGroup już powinno mieć poprawne originalIndex
    return [...athletesInCurrentGroup].sort((a, b) => {
        const weightA = getAthleteDeclaredWeightForRound(a, currentRound);
        const weightB = getAthleteDeclaredWeightForRound(b, currentRound);
        if (weightA === weightB) { // Jeśli wagi są równe, sortuj po oryginalnym indeksie (ID) dla stabilności
            if (a.originalIndex < b.originalIndex) return -1;
            if (a.originalIndex > b.originalIndex) return 1;
            return 0;
        }
        return weightA - weightB;
    });
  }, [athletesInCurrentGroup, currentRound]);

  // Punkt 11: Obliczanie sumy ciężarów dla stopki
  const totalLiftedInCategory = useMemo(() => {
    if (!activeCategory || !activeWeight) return 0;
    return athletesInCurrentGroup.reduce((sum, athlete) => {
        let athleteSum = 0;
        for (let i = 1; i <= 3; i++) {
            if (athlete[`podejscie${i}Status`] === 'passed') {
                athleteSum += getAthleteDeclaredWeightForRound(athlete, i);
            }
        }
        return sum + athleteSum;
    }, 0);
  }, [athletesInCurrentGroup, activeCategory, activeWeight]);


  // Punkt 9: Logika wymiarowania avatarów (jak w RegistrationScreen)
  useEffect(() => {
    if (zawody.klubAvatar) {
      Image.getSize(zawody.klubAvatar, (width, height) => {
        const aspectRatio = width / height;
        const targetSize = Platform.OS === 'web' ? 50 : 40; // Dopasuj do RegistrationScreen lub wspólnej wartości
        let displayWidth = targetSize;
        let displayHeight = targetSize / aspectRatio;
        if (height > width) {
            displayWidth = targetSize * aspectRatio;
            displayHeight = targetSize;
        }
        if (displayHeight > targetSize) {
            displayHeight = targetSize;
            displayWidth = displayHeight * aspectRatio;
        }
        if (displayWidth > targetSize) {
            displayWidth = targetSize;
            displayHeight = displayWidth / aspectRatio;
        }
        setHeaderKlubAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, () => setHeaderKlubAvatarDimensions({ width: Platform.OS === 'web' ? 50 : 40, height: Platform.OS === 'web' ? 50 : 40 }));
    } else {
      setHeaderKlubAvatarDimensions(null);
    }
  }, [zawody.klubAvatar]);

  useEffect(() => {
    if (zawody.sedzia?.avatar) {
      Image.getSize(zawody.sedzia.avatar, (width, height) => {
        const aspectRatio = width / height;
        const targetSize = Platform.OS === 'web' ? 40 : 32; // Dopasuj
        let displayWidth = targetSize;
        let displayHeight = targetSize / aspectRatio;
         if (height > width) {
            displayWidth = targetSize * aspectRatio;
            displayHeight = targetSize;
        }
        if (displayHeight > targetSize) {
            displayHeight = targetSize;
            displayWidth = displayHeight * aspectRatio;
        }
        if (displayWidth > targetSize) {
            displayWidth = targetSize;
            displayHeight = displayWidth / aspectRatio;
        }
        setHeaderJudgeAvatarDimensions({ width: displayWidth, height: displayHeight });
      }, () => setHeaderJudgeAvatarDimensions({ width: Platform.OS === 'web' ? 40 : 32, height: Platform.OS === 'web' ? 40 : 32 }));
    } else {
      setHeaderJudgeAvatarDimensions({ width: Platform.OS === 'web' ? 40 : 32, height: Platform.OS === 'web' ? 40 : 32 });
    }
  }, [zawody.sedzia?.avatar]);


  return (
    <View style={styles.container}> {/* Ensure this uses styles.container */}
      <LinearGradient
        colors={[colors.gradient.start, colors.gradient.end]} // CHANGED to standard blue gradient
        style={sharedHeaderStyles.headerGradient}
      >
        <View style={sharedHeaderStyles.headerContent}>
            <View style={[sharedHeaderStyles.headerSideContainer, sharedHeaderStyles.headerLeftAlign]}>
                {headerKlubAvatarDimensions && zawody.klubAvatar ? (
                    <Image source={{ uri: zawody.klubAvatar }} style={[styles.headerClubLogo, { width: headerKlubAvatarDimensions.width, height: headerKlubAvatarDimensions.height }]} resizeMode="contain" />
                ) : <View style={styles.headerAvatarPlaceholder} />}
                <View style={styles.headerLocationDate}>
                    <Text style={styles.headerLocationText} numberOfLines={1}>{zawody.miejsce || 'Lokalizacja'}</Text>
                    <Text style={styles.headerDateText}>{zawody.data || 'Data'}</Text>
                </View>
            </View>
            <Text style={styles.headerLogo} numberOfLines={1}>{zawody.nazwa || 'Nazwa Zawodów'}</Text>
            <View style={[sharedHeaderStyles.headerSideContainer, styles.headerRightAlign]}>
                <View style={styles.headerJudgeInfo}>
                    <Text style={styles.headerJudgeName} numberOfLines={1}>{`${zawody.sedzia?.imie || ''} ${zawody.sedzia?.nazwisko || 'Sędzia'}`.trim()}</Text>
                </View>
                {headerJudgeAvatarDimensions && zawody.sedzia?.avatar ? (
                    <Image source={{ uri: zawody.sedzia.avatar }} style={[styles.headerJudgeAvatar, { width: headerJudgeAvatarDimensions.width, height: headerJudgeAvatarDimensions.height }]} resizeMode="contain" />
                ) : <View style={styles.headerAvatarPlaceholder} />}
            </View>
        </View>
        <NavBar navigation={navigation} />
      </LinearGradient>

      <ScrollView style={styles.contentContainerScrollView} contentContainerStyle={styles.contentContainer}>
        <View style={styles.mainContent}>
          <View style={styles.columnsContainer}>
            <View style={styles.leftColumn}>
              {/* Karta Wybór grupy */}
              <View style={[styles.card, styles.groupSelectorCard]}>
                <Text style={styles.columnTitle}>Wybór grupy</Text>
                <View style={styles.optionSelectorContainerInColumn}>
                  <OptionSelector
                    label="Kategoria"
                    options={categoryOptions}
                    selectedValue={activeCategory}
                    onSelect={handleSelectCategory}
                    placeholder="Wszystkie kategorie"
                    loading={isSaving}
                  />
                </View>
                <View style={styles.optionSelectorContainerInColumn}>
                  <OptionSelector
                    label="Waga"
                    options={weightOptions}
                    selectedValue={activeWeight}
                    onSelect={handleSelectWeight}
                    placeholder="Wszystkie wagi"
                    loading={isSaving || !activeCategory}
                    disabled={!activeCategory}
                  />
                </View>
              </View>
              {/* Karta Lista Zawodników */}
              <View style={[styles.card, styles.athleteListCard]}>
                <Text style={styles.columnTitle}>Lista Zawodników</Text>
                {(isSaving && !showAttemptAnimation) && <ActivityIndicator size="small" color={colors.primary} style={{marginBottom: spacing.sm}} />}
                <View style={styles.athleteListContainerInColumn}>
                  <AthleteList
                      athletes={displayAthletesInGroup}
                      currentAthleteOriginalIndex={activeAthleteOriginalIndex}
                      currentRound={currentRound}
                      onSelectAthlete={handleSelectAthlete}
                      onAttemptStatusChange={handleAttemptStatusChange}
                      onWeightChange={handleWeightChange}
                      isSaving={isSaving || showAttemptAnimation}
                      athletesInGroupCount={athletesInCurrentGroup.length}
                      upcomingAthletesInRoundCount={upcomingAthletesForCurrentRound.length}
                  />
                </View>
              </View>
            </View>
            {/* Panel Sędziego */}
            <View style={styles.rightColumn}>
              <View style={styles.judgePanelCard}>
                <Text style={styles.judgePanelTitle}>Panel Sędziego</Text>
                <View style={styles.judgePanelContent}>
                    <View style={styles.currentAthleteManagerWrapper}>
                        <CurrentAthleteManager
                            athlete={currentAthlete}
                            athleteOriginalIndex={activeAthleteOriginalIndex}
                            currentAttemptNr={activeAttemptNr}
                            onAttemptStatusChange={handleAttemptStatusChange}
                            onWeightChange={handleWeightChange}
                            isSaving={isSaving || showAttemptAnimation}
                            currentRoundForDisplay={currentRound}
                        />
                    </View>
                    {currentAthlete && (
                        <View style={styles.timerSection}>
                            <TimerDisplay isActive={timerActive} timeLeft={timerTimeLeft} />
                        </View>
                    )}
                    <View style={styles.judgeButtonGroupsContainer}>
                        {/* Grupa przycisków Timera */}
                        <View style={styles.judgeButtonGroup}>
                            <Text style={styles.judgeSectionTitle}>Timer</Text>
                            <View style={styles.judgeButtonRow}>
                                {timerActive ? (
                                    <TouchableOpacity
                                        style={[styles.mainActionButton, styles.stopButton, (isSaving || showAttemptAnimation) && styles.actionButtonDisabled, {flex:1}]}
                                        onPress={() => {
                                            stableSetTimerActive(false);
                                            if (socket && socket.connected) {
                                                socket.emit('stopTimer', { 
                                                    finalTimeLeft: useCompetitionStore.getState().timerTimeLeft, 
                                                    reason: 'manual_stop',
                                                    athleteOriginalIndex: useCompetitionStore.getState().activeAthleteOriginalIndex
                                                });
                                            }
                                        }}
                                        disabled={isSaving || showAttemptAnimation}
                                    >
                                      <MaterialCommunityIcons name="timer-off-outline" size={20} color={colors.textLight} style={{marginRight: spacing.sm}}/>
                                      <Text style={styles.mainActionButtonText}>Stop</Text>
                                    </TouchableOpacity>
                                ) : (
                                    <TouchableOpacity
                                        style={[styles.mainActionButton, styles.startButton, (!currentAthlete || isSaving || showAttemptAnimation) && styles.actionButtonDisabled, {flex:1}]}
                                        onPress={handleStartOrRestartAttempt}
                                        disabled={!currentAthlete || isSaving || showAttemptAnimation}
                                    >
                                        <MaterialCommunityIcons name="timer-outline" size={20} color={colors.textLight} style={{marginRight: spacing.sm}}/>
                                        <Text style={styles.mainActionButtonText}>Start</Text>
                                    </TouchableOpacity>
                                )}
                                <TouchableOpacity
                                    style={[styles.secondaryActionButton, (isSaving || showAttemptAnimation) && styles.actionButtonDisabled, { paddingHorizontal: spacing.md }]
                                    }
                                    onPress={handleResetTimer}
                                    disabled={isSaving || showAttemptAnimation}
                                >
                                    <MaterialCommunityIcons name="backup-restore" size={20} color={colors.textOnSecondary}/>
                                </TouchableOpacity>
                            </View>
                        </View>
                        {/* Grupa przycisków Nawigacji Zawodników */}
                        <View style={styles.judgeButtonGroup}>
                            <Text style={styles.judgeSectionTitle}>Nawigacja Zawodników</Text>
                            <View style={styles.judgeButtonRow}>
                                <TouchableOpacity
                                    style={[styles.secondaryActionButton, (!activeCategory || !activeWeight || !currentAthlete || displayAthletesInGroup.findIndex(a => a.originalIndex === activeAthleteOriginalIndex) === 0 || isSaving || timerActive || showAttemptAnimation) && styles.actionButtonDisabled, {flex:1}]}
                                    onPress={handlePreviousCompetitor}
                                    disabled={!activeCategory || !activeWeight || !currentAthlete || displayAthletesInGroup.findIndex(a => a.originalIndex === activeAthleteOriginalIndex) === 0 || isSaving || timerActive || showAttemptAnimation}
                                >
                                    <AntDesign name="left" size={16} color={colors.textOnSecondary} style={{marginRight: spacing.xs}}/>
                                    <Text style={styles.secondaryActionButtonText}>Poprzedni</Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    style={[styles.secondaryActionButton, (!activeCategory || !activeWeight || upcomingAthletesForCurrentRound.length === 0 || isSaving || timerActive || showAttemptAnimation) && styles.actionButtonDisabled, {flex:1}]}
                                    onPress={handleNextCompetitor}
                                    disabled={!activeCategory || !activeWeight || upcomingAthletesForCurrentRound.length === 0 || isSaving || timerActive || showAttemptAnimation}
                                >
                                    <Text style={styles.secondaryActionButtonText}>Następny</Text>
                                    <AntDesign name="right" size={16} color={colors.textOnSecondary} style={{marginLeft: spacing.xs}}/>
                                </TouchableOpacity>
                            </View>
                        </View>
                        {/* Grupa przycisków Nawigacji Rund */}
                        <View style={styles.judgeButtonGroup}>
                            <Text style={styles.judgeSectionTitle}>Nawigacja Rund</Text>
                            <View style={styles.judgeButtonRow}>
                                <TouchableOpacity
                                    style={[styles.secondaryActionButton, (currentRound === 1 || isSaving || timerActive || showAttemptAnimation) && styles.actionButtonDisabled, {flex:1}]}
                                    onPress={handlePreviousRound}
                                    disabled={currentRound === 1 || isSaving || timerActive || showAttemptAnimation}
                                >
                                    <AntDesign name="doubleleft" size={16} color={colors.textOnSecondary} style={{marginRight: spacing.xs}}/>
                                    <Text style={styles.secondaryActionButtonText}>Poprz. Runda</Text>
                                </TouchableOpacity>
                                <TouchableOpacity
                                    style={[styles.secondaryActionButton, (currentRound === 3 || isSaving || timerActive || showAttemptAnimation) && styles.actionButtonDisabled, {flex:1}]}
                                    onPress={handleNextRound}
                                    disabled={currentRound === 3 || isSaving || timerActive || showAttemptAnimation}
                                >
                                    <Text style={styles.secondaryActionButtonText}>Nast. Runda</Text>
                                    <AntDesign name="doubleright" size={16} color={colors.textOnSecondary} style={{marginLeft: spacing.xs}}/>
                                </TouchableOpacity>
                            </View>
                        </View>
                        {/* NOWA GRUPA: Sterowanie Widownią */}
                        <View style={styles.judgeButtonGroup}>
                            <Text style={styles.judgeSectionTitle}>Sterowanie Widownią</Text>
                            <TouchableOpacity
                                style={[styles.secondaryActionButton, {backgroundColor: colors.info}]} // Inny kolor dla wyróżnienia
                                onPress={() => {
                                    // Ustaw domyślne wartości dla modala przy otwarciu
                                    setModalSelectedCategory(activeCategory || (kategorie.length > 0 ? kategorie[0].nazwa : null));
                                    setModalSelectedWeight(activeWeight || (activeCategoryObject && activeCategoryObject.wagi.length > 0 ? activeCategoryObject.wagi[0] : null));
                                    setIsResultsModalVisible(true);
                                }}
                            >
                                <MaterialCommunityIcons name="poll" size={18} color={colors.textLight} style={{marginRight: spacing.sm}}/>
                                <Text style={[styles.secondaryActionButtonText, {color: colors.textLight}]}>Pokaż Wyniki Końcowe</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
      <Footer
        competitionLocation={zawody.miejsce}
        registeredAthletesCount={zawodnicy.length}
        totalWeightInCategory={totalLiftedInCategory}
      />

      {showAttemptAnimation && (
        <View style={styles.animationOverlayContainer}>
            <AttemptResultAnimation success={attemptAnimationSuccess} />
        </View>
      )}

      {/* Modal do wyboru wyników */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={isResultsModalVisible}
        onRequestClose={() => setIsResultsModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Pokaż Wyniki na Ekranie Widowni</Text>
            <OptionSelector
              label="Wybierz Kategorię"
              options={modalCategoryOptions}
              selectedValue={modalSelectedCategory}
              onSelect={(val) => {
                setModalSelectedCategory(val);
                const catObj = kategorie.find(k => k.nazwa === val);
                setModalSelectedWeight(catObj && catObj.wagi.length > 0 ? catObj.wagi[0] : null);
              }}
              placeholder="Wybierz kategorię"
            />
            {modalSelectedCategory && (
              <OptionSelector
                label="Wybierz Wagę"
                options={modalWeightOptions}
                selectedValue={modalSelectedWeight}
                onSelect={setModalSelectedWeight}
                placeholder="Wybierz wagę"
                disabled={!modalSelectedCategory || modalWeightOptions.length === 0}
              />
            )}
            <View style={styles.modalButtonRow}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => setIsResultsModalVisible(false)}
              >
                <Text style={[styles.modalButtonText, styles.modalButtonTextCancel]}>Anuluj</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonConfirm, (!modalSelectedCategory || !modalSelectedWeight) && styles.actionButtonDisabled]}
                onPress={handleShowResultsOnAthleteView}
                disabled={!modalSelectedCategory || !modalSelectedWeight}
              >
                <Text style={styles.modalButtonText}>Pokaż</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}
